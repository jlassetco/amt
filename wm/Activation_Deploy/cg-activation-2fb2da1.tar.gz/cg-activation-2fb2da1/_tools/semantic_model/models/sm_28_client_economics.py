"""Semantic model SM-28 Client Economics. See ../CONTRACT.md and ../register.py.

Owns the certified client fee revenue family (Gross Fee Revenue, Net Fee Revenue, Effective Net Fee Rate and its client
slice Client Fee Revenue, CW-011, CW-204), defined here on DP-012 and referenced by every other model. It also defines the
cost-to-serve family of DP-498 (Total Cost to Serve, Cost to Serve Rate (bps), Cost Coverage of Certified Expense) that
SM-14 references. Client Assets, Average Client Assets and Households are SM-20's; certified operating expense, revenue
and operating income are SM-14's; fund net assets and expense ratios SM-11's; official returns SM-08's; campaign spend and
funded households acquired SM-25's.

WP2 (CW-209): SM-07 Finance & Profitability retired and its DP-012 revenue tables moved here with the client revenue record
(CW-156) added; DP-498 moved here from SM-14.

Three amounts are kept apart throughout (DP-012 notes): calculated and billed fees (47, DP-305 and DP-346, operational,
CW-214), recognized revenue (10, DP-012, certified here) and certified enterprise revenue (19, DP-191, SM-14). Billable
Assets is a derived copy of 49 Client Holding valuations: never Client Assets and never Firm AUM.
"""

# ---- Shared filter text --------------------------------------------------------------------------------------------
# Revenue and cost facts are keyed to a fiscal period: quarters and years roll up from months, so mixing period types
# would count the same money twice.
MONTHS = "the period is a fiscal month (fiscal_period_type = 'MONTH'); quarters and years roll up from months"
# The billed calculation set of DP-305: one row per billed subject and billing period, from the latest released run, so
# a Recalculation run replaces the run it corrects and is never added to it; Simulation runs never count.
BILLED_SET = ["fee_run.run_status = 'Released' and fee_run.run_type <> 'Simulation'",
              "per billed subject (calculated_assignment or calculated_billing_arrangement) and billing period only the "
              "row of the latest released run"]
# The profitability-record pins of DP-498 and DP-499: one actual version, the current hierarchy and the final run.
PROFITABILITY_PINS = ["data_version = 'Actual'",
                      "hierarchy_version = the current management hierarchy version",
                      "source_allocation_run is an allocation run with Run Status = 'Final' (one run per period)"]
# DP-008 certified client-asset rows (SM-20's certified source, read here to slice the referenced metrics).
LOCKED_MONTHS = ["period_type = 'MONTH'",
                 "data_basis = 'Actual'",
                 "snapshot in (select snapshot_id from dp_008.snapshot where snapshot_type in ('Final', 'Restated')) "
                 "(the locked snapshot)"]

# Columns that identify a client, an account, a household, an advisor or an employee. Broad roles never see them; the
# billing and revenue operations roles see them on billing and revenue rows only (Confidential - Personal Data).
CLIENT_KEYS = ["revenue_account_household", "source_calculation_record", "calculated_assignment",
               "calculated_billing_arrangement", "billed_account", "fee_paying_account", "billed_enrollment",
               "billed_advice_engagement", "assigned_fee_household", "fee_household_id", "anchor_client_household",
               "member_account", "debited_account", "invoice_bill_to_party", "bill_to_party", "authorized_account",
               "authorized_fee_paying_account", "confirmation_account", "confirmed_client_allocation",
               "service_charge_account", "customer_party", "economics_sweep_program_key"]
APPROVER_KEYS = ["run_approved_by", "waiver_approved_by", "adjustment_approved_by", "calculation_approved_by"]
# The restricted views registered in DP-518 (CW-243, CD-344): member-level household, account and advisor economics.
RESTRICTED_COLUMNS = ["served_party", "served_client_account", "valued_household", "profitability_advisor",
                      "profitability_client_account", "target_dimension_member"]

MODEL = dict(
    id="SM-28",
    status="Draft",
    description=(
        "Client fee revenue, fee schedules and billing runs, billing accuracy and custody-rule evidence, brokerage "
        "commissions and account service charges, institutional invoicing, revenue yield, cost allocation, cost to serve, "
        "lifetime value, client, offering and product profitability and intercompany charges, for client revenue finance, "
        "pricing and billing, FP&A, product and channel leadership and tax. It owns the certified client fee revenue every "
        "other model references, and keeps billed fees, recognized revenue and certified enterprise revenue apart."
    ),
    questions=[
        "Which advisory fee runs failed reconciliation this quarter, and which accounts were billed outside their fee schedule, by fee schedule type and cause?",
        "What does it cost to serve each client segment and service tier, as a rate on average client assets and per household, and what is lifetime value against acquisition cost by acquisition channel?",
        "How have gross and net fee revenue and the effective net fee rate moved by service offering, channel and business line over the last four quarters, and what is the client revenue yield on average client assets?",
        "Which service offerings, client segments and products earn negative contribution after distribution payments and allocated cost?",
        "How much was billed, reduced, refunded and disputed by fee schedule type, and how much of client fee revenue does billing explain?",
        "Which intercompany agreements booked charges outside the arm's length range, and which charges are unsettled or not flagged for elimination?",
    ],

    tables=[
        # ================================================================================================================
        # DP-012 Client Fee Revenue (foundational; the certified revenue facts)
        # ================================================================================================================
        # The client revenue record (CLREV-, CW-156): account or 47 fee household x revenue stream x fiscal period. Client
        # rows are recognized at the 47 net fee. It carries no data basis attribute, so the estimated-then-final rule of
        # the product grain is applied by the product on publication (open decision).
        dict(name="client_revenue", product="DP-012", entity="Client Revenue Record", kind="Fact",
             grain="account or fee household x client revenue stream x fiscal period (closed periods final)",
             always_filter=["client_revenue_period is a fiscal month; quarters and years roll up from months"],
             dimensions=[dict(name="revenue_account_household", attr="Revenue Account / Household",
                              note="An account (DP-093) or a 47 fee household; the household reported is always the 02 "
                                   "Client Household reached through the account or the fee household's anchor. Personal data."),
                         dict(name="client_revenue_stream", attr="Client Revenue Stream",
                              note="Fee streams (Advisory, Wrap, Planning, Subscription, Account Service, Recordkeeping, "
                                   "Trust, OCIO, Mandate Performance Fee) versus transaction and interest streams "
                                   "(Commission, Markup / Markdown, Margin Interest, Fully Paid Lending Revenue, Bank Sweep "
                                   "Fee, Order Routing Payment)."),
                         dict(name="revenue_service_offering", attr="Revenue Service Offering"),
                         dict(name="client_revenue_period", attr="Client Revenue Period"),
                         dict(name="recognizing_legal_entity", attr="Recognizing Legal Entity"),
                         dict(name="revenue_channel", attr="Revenue Channel"),
                         dict(name="revenue_business_line", attr="Revenue Business Line"),
                         dict(name="client_segment_at_period_end", attr="Client Segment at Period End"),
                         dict(name="source_calculation_record", attr="Source Calculation Record",
                              note="The 47 calculation, invoice, debit or adjustment the revenue was recognized from; "
                                   "multi-valued and multi-type (GAP-10-026), so it aligns totals only.")],
             facts=[dict(name="recognized_revenue_amount", attr="Recognized Revenue Amount")],
             hidden=[("Client Revenue Record ID", "Row key; no cross-row question needs it.")]),

        # Own-fund management fee revenue (FRR-): share class or mandate x accounting period.
        dict(name="fee_revenue", product="DP-012", entity="Fee Revenue Record", kind="Fact",
             grain="share class or mandate x revenue accounting period",
             # A period can hold an estimated and a final record; reading both double counts.
             always_filter=["one revenue_data_basis per share class or mandate and period: Final where it exists, otherwise Estimated",
                            MONTHS],
             dimensions=[dict(name="revenue_share_class_mandate", attr="Revenue Share Class / Mandate",
                              note="Holds a share class or a mandate; joins to DP-004 Share Class or DP-140 Investment Mandate."),
                         dict(name="revenue_accounting_period", attr="Revenue Accounting Period"),
                         dict(name="revenue_data_basis", attr="Revenue Data Basis",
                              note="Estimated or Final, so users see which basis a period is on."),
                         dict(name="fee_basis_source", attr="Fee Basis Source"),
                         dict(name="applied_gross_fee_rate", attr="Applied Gross Fee Rate"),
                         dict(name="sub_adviser_engagement", attr="Sub-Adviser Engagement")],
             facts=[dict(name="gross_fee_revenue", attr="Gross Fee Revenue"),
                    dict(name="waiver_reimbursement_offset", attr="Waiver and Reimbursement Offset"),
                    dict(name="net_fee_revenue", attr="Net Fee Revenue"),
                    dict(name="fee_basis_average_assets", attr="Fee Basis Average Assets",
                         note="The fund fee basis; the denominator of Fund Effective Net Fee Rate only, never Client Assets."),
                    dict(name="sub_advisory_fee_payable", attr="Sub-Advisory Fee Payable")],
             hidden=[("Effective Net Fee Rate", "The row's fund-basis rate; published as [Fund Effective Net Fee Rate], "
                                                "a ratio of sums, never an average of row rates."),
                     ("Fee Revenue Record ID", "Row key.")]),

        # 12b-1 and servicing revenue of intermediary channel share classes, by receiving legal entity.
        dict(name="distribution_revenue", product="DP-012", entity="Revenue Record", kind="Fact",
             grain="paying share class x receiving legal entity x distribution revenue type x accounting period",
             always_filter=[MONTHS],
             dimensions=[dict(name="receiving_entity", attr="Receiving Entity",
                              note="Required in every query: distribution revenue is kept by receiving legal entity."),
                         dict(name="distribution_revenue_type", attr="Distribution Revenue Type"),
                         dict(name="paying_share_class", attr="Paying Share Class"),
                         dict(name="distribution_fiscal_period", attr="Fiscal Period Key"),
                         dict(name="principal_vs_agent", attr="Principal vs Agent Conclusion"),
                         dict(name="trailing_fee_constraint", attr="Trailing Fee Constraint Indicator")],
             facts=[dict(name="gross_distribution_revenue", attr="Gross Distribution Revenue"),
                    dict(name="amount_passed_through", attr="Amount Passed Through")]),

        dict(name="fund_waiver", product="DP-012", entity="Waiver Record", kind="Fact",
             grain="supported share class x waiver type x accounting period",
             always_filter=[MONTHS],
             dimensions=[dict(name="waiver_type", attr="Waiver Type"),
                         dict(name="supported_share_class", attr="Supported Share Class"),
                         dict(name="waiver_fiscal_period", attr="Fiscal Period Key"),
                         dict(name="waiver_accounting_treatment", attr="Waiver Accounting Treatment"),
                         dict(name="recoupment_eligible", attr="Recoupment Eligible Indicator"),
                         dict(name="recoupment_expiry_date", attr="Recoupment Expiry Date")],
             facts=[dict(name="waived_fee_amount", attr="Waived Fee Amount"),
                    dict(name="reimbursed_expense_amount", attr="Reimbursed Expense Amount")]),

        dict(name="performance_fee", product="DP-012", entity="Performance Fee Record", kind="Fact",
             grain="own-fund share class x crystallization date (fulcrum fee adjustments)",
             dimensions=[dict(name="performance_fee_share_class", attr="Performance Fee Share Class / Mandate"),
                         dict(name="crystallization_date", attr="Crystallization Date"),
                         dict(name="constraint_assessment_outcome", attr="Constraint Assessment Outcome"),
                         dict(name="clawback_exposure", attr="Clawback Exposure Indicator")],
             facts=[dict(name="recognized_performance_fee_revenue", attr="Recognized Performance Fee Revenue")]),

        # Cash program economics: sweep program x program bank x period. Program Bank is SM-24's dimension (DP-431) and is
        # not yet in SM-00, so the program bank is an own column here (open decision).
        dict(name="cash_program_economics", product="DP-012", entity="Cash Program Economics", kind="Fact",
             grain="sweep program x program bank x economics period",
             always_filter=["economics_period is a fiscal month"],
             dimensions=[dict(name="economics_sweep_program_key", attr="Economics Sweep Program",
                              note="Program key; flagged personal in the logical model because a program can be named "
                                   "for a client group; shown to finance roles only."),
                         dict(name="economics_program_bank", attr="Economics Program Bank",
                              note="Own column until SM-00 publishes SM-24's Program Bank (DP-431)."),
                         dict(name="economics_period", attr="Economics Period")],
             facts=[dict(name="average_swept_balance", attr="Average Swept Balance"),
                    dict(name="program_bank_fee_earned", attr="Program Bank Fee Earned"),
                    dict(name="average_client_rate_paid", attr="Average Client Rate Paid",
                         note="A rate; read beside the fee, never summed."),
                    dict(name="net_spread", attr="Net Spread", note="A rate; read beside the fee, never summed."),
                    dict(name="money_market_sweep_fund_revenue", attr="Money Market Sweep Fund Revenue",
                         note="The sweep fund's fee revenue record; shown here, counted in Gross Fee Revenue only "
                              "through fee_revenue.")]),

        dict(name="revenue_contract", product="DP-012", entity="Revenue Contract", kind="Dimension",
             dimensions=[dict(name="revenue_contract_id", attr="Revenue Contract ID"),
                         dict(name="revenue_contract_type", attr="Revenue Contract Type"),
                         dict(name="contracting_legal_entity", attr="Contracting Legal Entity"),
                         dict(name="accounting_framework", attr="Accounting Framework"),
                         dict(name="revenue_stream", attr="Revenue Stream"),
                         dict(name="performance_obligation_type", attr="Performance Obligation Type"),
                         dict(name="stream_principal_vs_agent", attr="Stream Principal vs Agent Conclusion")],
             hidden=[("Identified Customer", "The identified customer is personal data; revenue is cut by contract "
                                             "type and stream, not by customer.")]),

        # ================================================================================================================
        # DP-305 Fee Schedules & Billing Runs (foundational; billed amounts, operational, CW-214)
        # ================================================================================================================
        dict(name="fee_schedule", product="DP-305", entity="Fee Schedule", kind="Dimension",
             grain="fee schedule version",
             dimensions=[dict(name="fee_schedule_id", attr="Fee Schedule ID"),
                         dict(name="fee_schedule_name", attr="Fee Schedule Name"),
                         dict(name="fee_schedule_type", attr="Fee Schedule Type"),
                         dict(name="schedule_version_number", attr="Schedule Version Number"),
                         dict(name="schedule_status", attr="Schedule Status"),
                         dict(name="version_effective_from", attr="Version Effective From"),
                         dict(name="version_effective_to", attr="Version Effective To"),
                         dict(name="billing_basis", attr="Billing Basis"),
                         dict(name="tier_method", attr="Tier Method"),
                         dict(name="minimum_annual_fee", attr="Minimum Annual Fee"),
                         dict(name="maximum_fee_rate", attr="Maximum Fee Rate"),
                         dict(name="own_fund_treatment", attr="Own-Fund Treatment"),
                         dict(name="schedule_performance_fee_rate", attr="Performance Fee Rate",
                              note="Flagged personal for negotiated institutional schedules; finance and billing roles only."),
                         dict(name="hurdle_type", attr="Hurdle Type"),
                         dict(name="high_water_mark", attr="High-Water Mark Indicator")]),

        dict(name="fee_schedule_assignment", product="DP-305", entity="Fee Schedule Assignment", kind="Dimension",
             grain="fee schedule assignment x effective period (SCD type 2)",
             default_filter="the assignment in force on the billing period end (Assignment Effective From <= date < Assignment Effective To)",
             dimensions=[dict(name="fee_schedule_assignment_id", attr="Fee Schedule Assignment ID"),
                         dict(name="billed_enrollment", attr="Billed Enrollment"),
                         dict(name="billed_account", attr="Billed Account"),
                         dict(name="billed_advice_engagement", attr="Billed Advice Engagement"),
                         dict(name="assigned_fee_schedule", attr="Assigned Fee Schedule"),
                         dict(name="fee_paying_account", attr="Fee-Paying Account"),
                         dict(name="fee_collection_method", attr="Fee Collection Method"),
                         dict(name="billing_frequency", attr="Billing Frequency"),
                         dict(name="assigned_fee_household", attr="Assigned Fee Household"),
                         dict(name="negotiated_rate", attr="Negotiated Rate Indicator"),
                         dict(name="assignment_effective_from", attr="Assignment Effective From"),
                         dict(name="assignment_effective_to", attr="Assignment Effective To")]),

        # The 47 fee aggregation group (FHHG-): the billing household, not the 02 Client Household (CW-027).
        dict(name="fee_household", product="DP-305", entity="Fee Household", kind="Dimension",
             grain="fee household x effective period",
             dimensions=[dict(name="fee_household_id", attr="Fee Household ID"),
                         dict(name="anchor_client_household", attr="Anchor Client Household",
                              note="The 02 Client Household the fee group is anchored on; the only route from a fee "
                                   "household to the reported household."),
                         dict(name="fee_household_formation_basis", attr="Formation Basis"),
                         dict(name="fee_household_status", attr="Fee Household Status"),
                         dict(name="fee_household_effective_from", attr="Fee Household Effective From"),
                         dict(name="fee_household_effective_to", attr="Fee Household Effective To")]),

        dict(name="fee_household_membership", product="DP-305", entity="Fee Household Membership", kind="Bridge",
             grain="fee household x member account x effective period",
             default_filter="memberships in force on the as-of date (Fee Household Membership Status = Active)",
             dimensions=[dict(name="membership_fee_household", attr="Membership Fee Household"),
                         dict(name="member_account", attr="Member Account"),
                         dict(name="inclusion_basis", attr="Inclusion Basis"),
                         dict(name="fee_household_membership_status", attr="Fee Household Membership Status"),
                         dict(name="fee_membership_effective_from", attr="Fee Household Membership Effective From"),
                         dict(name="fee_membership_effective_to", attr="Fee Household Membership Effective To")]),

        dict(name="fee_run", product="DP-305", entity="Fee Run", kind="Dimension",
             grain="fee calculation run",
             dimensions=[dict(name="fee_calculation_run_id", attr="Fee Calculation Run ID"),
                         dict(name="run_billing_period_start", attr="Run Billing Period Start"),
                         dict(name="run_billing_period_end", attr="Run Billing Period End"),
                         dict(name="run_type", attr="Run Type"),
                         dict(name="valuation_as_of_date", attr="Valuation As-Of Date"),
                         dict(name="run_status", attr="Run Status"),
                         dict(name="fee_reconciliation_status", attr="Fee Reconciliation Status"),
                         dict(name="run_approved_by", attr="Run Approved By",
                              note="Employee key; blank on a released run fails the run (DP-346).")],
             facts=[dict(name="run_net_fee_total", attr="Run Net Fee Total")]),

        dict(name="account_fee_calculation", product="DP-305", entity="Account Fee Calculation", kind="Fact",
             grain="fee calculation run x billed subject (fee schedule assignment or billing arrangement)",
             always_filter=BILLED_SET,
             dimensions=[dict(name="calculation_run", attr="Calculation Run"),
                         dict(name="calculated_assignment", attr="Calculated Assignment"),
                         dict(name="calculated_billing_arrangement", attr="Calculated Billing Arrangement"),
                         dict(name="schedule_version_applied", attr="Schedule Version Applied"),
                         dict(name="calculation_exception", attr="Exception Indicator")],
             facts=[dict(name="billable_assets", attr="Billable Assets",
                         note="A derived copy of 49 Client Holding valuations at the run's valuation date (18 for "
                              "mandates); never Client Assets or Firm AUM."),
                    dict(name="fee_household_assets", attr="Fee Household Assets"),
                    dict(name="effective_annual_rate", attr="Effective Annual Rate",
                         note="Read only weighted by billable_assets."),
                    dict(name="gross_fee", attr="Gross Fee"),
                    dict(name="discount_amount", attr="Discount Amount"),
                    dict(name="waiver_amount_applied", attr="Waiver Amount Applied"),
                    dict(name="own_fund_credit_amount", attr="Own-Fund Credit Amount"),
                    dict(name="net_fee", attr="Net Fee")],
             hidden=[("Account Valuation", "The 49 valuation the billable assets were taken from; read by DP-346's "
                                           "asset test, not by a cross-row question.")]),

        dict(name="fee_waiver", product="DP-305", entity="Fee Waiver", kind="Fact",
             grain="fee waiver",
             dimensions=[dict(name="fee_waiver_id", attr="Fee Waiver ID"),
                         dict(name="waived_assignment", attr="Waived Assignment"),
                         dict(name="waived_billing_arrangement", attr="Waived Billing Arrangement"),
                         dict(name="waiver_reason", attr="Waiver Reason"),
                         dict(name="waiver_period_start", attr="Waiver Period Start"),
                         dict(name="waiver_period_end", attr="Waiver Period End"),
                         dict(name="waiver_approved_by", attr="Waiver Approved By")],
             facts=[dict(name="waiver_percentage", attr="Waiver Percentage"),
                    dict(name="waiver_amount", attr="Waiver Amount")]),

        dict(name="fee_debit", product="DP-305", entity="Fee Debit", kind="Fact",
             grain="fee debit against an account",
             dimensions=[dict(name="fee_debit_id", attr="Fee Debit ID"),
                         dict(name="debited_calculation", attr="Debited Calculation"),
                         dict(name="charged_fee_type", attr="Charged Fee Type"),
                         dict(name="debited_account", attr="Debited Account"),
                         dict(name="debit_date", attr="Debit Date"),
                         dict(name="fee_debit_status", attr="Fee Debit Status"),
                         dict(name="debit_failure_reason", attr="Debit Failure Reason")],
             facts=[dict(name="debit_amount", attr="Debit Amount")],
             hidden=[("Debit Posting", "The 49 activity posting key; read by DP-346's debit-to-calculation test only.")]),

        dict(name="fee_invoice", product="DP-305", entity="Fee Invoice", kind="Fact",
             grain="fee invoice",
             dimensions=[dict(name="invoice_id", attr="Invoice ID"),
                         dict(name="invoice_billing_arrangement", attr="Invoice Billing Arrangement"),
                         dict(name="invoice_fee_schedule_assignment", attr="Invoice Fee Schedule Assignment"),
                         dict(name="invoice_bill_to_party", attr="Invoice Bill-To Party"),
                         dict(name="invoice_billing_period_end", attr="Billing Period End"),
                         dict(name="invoice_date", attr="Invoice Date"),
                         dict(name="payment_status", attr="Payment Status",
                              note="A derived copy of 19; the ledger view of collection is fee_receivable.")],
             facts=[dict(name="invoice_billable_assets", attr="Billable Assets"),
                    dict(name="management_fee_amount", attr="Management Fee Amount"),
                    dict(name="performance_fee_amount", attr="Performance Fee Amount"),
                    dict(name="invoice_total", attr="Invoice Total")]),

        dict(name="fee_adjustment", product="DP-305", entity="Fee Adjustment", kind="Fact",
             grain="fee adjustment",
             dimensions=[dict(name="fee_adjustment_id", attr="Fee Adjustment ID"),
                         dict(name="adjustment_type", attr="Adjustment Type"),
                         dict(name="adjusted_invoice", attr="Adjusted Invoice"),
                         dict(name="adjusted_fee_calculation", attr="Adjusted Fee Calculation"),
                         dict(name="applied_fee_waiver", attr="Applied Fee Waiver"),
                         dict(name="related_billing_dispute", attr="Related Billing Dispute"),
                         dict(name="adjustment_approved_by", attr="Adjustment Approved By")],
             facts=[dict(name="adjustment_amount_value", attr="Adjustment Amount Value")],
             hidden=[("Credit Posting", "The 49 activity posting key of the credit; no cross-row question needs it.")]),

        dict(name="billing_dispute", product="DP-305", entity="Billing Dispute", kind="Fact",
             grain="billing dispute",
             dimensions=[dict(name="billing_dispute_id", attr="Billing Dispute ID"),
                         dict(name="disputed_invoice", attr="Disputed Invoice"),
                         dict(name="disputed_fee_calculation", attr="Disputed Fee Calculation"),
                         dict(name="dispute_reason", attr="Dispute Reason"),
                         dict(name="dispute_status", attr="Dispute Status")],
             facts=[dict(name="disputed_amount", attr="Disputed Amount")],
             hidden=[("Related Complaint", "The 08 complaint key; complaints are SM-29's (DP-391), joined there.")]),

        # ================================================================================================================
        # DP-346 Fee Billing Accuracy & Custody-Rule Evidence (acceptance question 8)
        # ================================================================================================================
        # One row per account fee calculation, 1:1 with account_fee_calculation: only the re-performance columns are read
        # here, so billed amounts are never counted twice.
        dict(name="fee_billing_test", product="DP-346", entity="Fact Fee Billing Test", kind="Fact",
             grain="account fee calculation (fee calculation run x billed subject), re-tested on each recalculation run",
             always_filter=BILLED_SET,
             dimensions=[dict(name="test_calculation_run", attr="Calculation Run"),
                         dict(name="test_calculated_assignment", attr="Calculated Assignment"),
                         dict(name="test_calculated_billing_arrangement", attr="Calculated Billing Arrangement"),
                         dict(name="off_schedule_flag", attr="Off-Schedule Flag",
                              note="Y when the version applied, the annual rate (0.005 percentage points) or the net fee "
                                   "(USD 1) differs from the re-performed fee; defined in DP-346."),
                         dict(name="waivers_applied", attr="Waivers Applied")],
             facts=[dict(name="re_performed_fee", attr="Re-Performed Fee"),
                    dict(name="pro_ration_days", attr="Pro-Ration Days")]),

        dict(name="fee_calculation_exception", product="DP-346", entity="Fact Fee Calculation Exception", kind="Fact",
             grain="fee calculation x exception type x raised date",
             dimensions=[dict(name="exception_calculation", attr="Exception Calculation"),
                         dict(name="fee_exception_type", attr="Fee Exception Type"),
                         dict(name="exception_raised_date", attr="Exception Raised Date"),
                         dict(name="exception_resolution", attr="Exception Resolution"),
                         dict(name="exception_resolved_date", attr="Exception Resolved Date"),
                         dict(name="exception_supervisory_review", attr="Exception Supervisory Review")]),

        dict(name="fee_deduction_authorization", product="DP-346", entity="Fact Fee Deduction Authorization", kind="Fact",
             grain="debited account x authorizing agreement, tested per quarter (custody-rule evidence)",
             dimensions=[dict(name="authorized_account", attr="Authorized Account"),
                         dict(name="authorizing_agreement", attr="Authorizing Agreement"),
                         dict(name="fee_types_authorized", attr="Fee Types Authorized"),
                         dict(name="authorized_fee_paying_account", attr="Authorized Fee-Paying Account"),
                         dict(name="qualified_custodian", attr="Qualified Custodian"),
                         dict(name="custody_rule_basis", attr="Custody Rule Basis"),
                         dict(name="authorization_status", attr="Authorization Status"),
                         dict(name="authorization_effective_date", attr="Authorization Effective Date"),
                         dict(name="authorization_revoked_date", attr="Authorization Revoked Date")],
             hidden=[("Last Custodian Statement", "The 13 statement key of the custody-rule evidence test, which the "
                                                  "product publishes as an exception list.")]),

        # ================================================================================================================
        # DP-349 Brokerage Commissions & Account Service Charges
        # ================================================================================================================
        dict(name="commission_re_performance", product="DP-349", entity="Fact Commission Re-Performance", kind="Fact",
             grain="client trade confirmation (latest version) with its re-performed charge",
             always_filter=["latest Confirmation Version only (no later confirmation names it as Superseded Confirmation)",
                            "confirmation_type <> 'Cancel'"],
             dimensions=[dict(name="confirmation_type", attr="Confirmation Type"),
                         dict(name="confirmed_client_allocation", attr="Confirmed Client Allocation"),
                         dict(name="confirmation_account", attr="Confirmation Account"),
                         dict(name="confirmed_instrument", attr="Confirmed Instrument"),
                         dict(name="confirmed_trade_date", attr="Confirmed Trade Date"),
                         dict(name="confirmed_capacity", attr="Confirmed Capacity"),
                         dict(name="commission_fee_schedule", attr="Commission Fee Schedule"),
                         dict(name="order_flow_remuneration_statement", attr="Order Flow Remuneration Statement"),
                         dict(name="markup_disclosure_scope_condition", attr="Markup Disclosure Scope Condition"),
                         dict(name="markup_disclosure_exception", attr="Markup Disclosure Exception")],
             facts=[dict(name="confirmed_quantity", attr="Confirmed Quantity"),
                    dict(name="commission_charged", attr="Commission Charged"),
                    dict(name="expected_commission", attr="Expected Commission",
                         note="Re-performed from the account's commission schedule, channel and service tier discount (DP-349)."),
                    dict(name="regulatory_transaction_fees", attr="Regulatory Transaction Fees"),
                    dict(name="markup_markdown_amount", attr="Markup Markdown Amount"),
                    dict(name="markup_markdown_percentage", attr="Markup Markdown Percentage"),
                    dict(name="prevailing_market_price", attr="Prevailing Market Price")],
             hidden=[("Client Trade Confirmation ID", "Row key; the confirmation book is SM-24's."),
                     ("Confirmed Price", "Execution price; execution quality is SM-24's.")]),

        dict(name="account_service_charge", product="DP-349", entity="Fact Account Service Charge", kind="Fact",
             grain="fee debit of Charged Fee Type = Account Service",
             always_filter=["fee_debit_status = 'Posted'"],
             dimensions=[dict(name="service_charge_type", attr="Charged Service Type"),
                         dict(name="charged_service_fee_schedule", attr="Charged Service Fee Schedule"),
                         dict(name="service_charge_account", attr="Debited Account"),
                         dict(name="service_charge_debit_date", attr="Debit Date"),
                         dict(name="service_charge_debit_status", attr="Fee Debit Status")],
             facts=[dict(name="service_charge_amount", attr="Debit Amount")],
             hidden=[("Triggering Money Movement", "The DP-302 movement key; the trigger tests are exception lists of DP-349."),
                     ("Triggering Account Transfer", "The DP-300 transfer key; as above.")]),

        dict(name="account_service_fee_item", product="DP-349", entity="Account Service Fee Item", kind="Dimension",
             grain="service fee schedule x account service type",
             dimensions=[dict(name="service_fee_schedule", attr="Service Fee Schedule"),
                         dict(name="account_service_type", attr="Account Service Type"),
                         dict(name="service_fee_frequency", attr="Service Fee Frequency"),
                         dict(name="waivable", attr="Waivable Indicator"),
                         dict(name="waiver_service_tier", attr="Waiver Service Tier")],
             facts=[dict(name="service_fee_amount", attr="Service Fee Amount")]),

        # ================================================================================================================
        # DP-350 Institutional & Planning Fee Invoicing (invoices are read from DP-305's fee_invoice)
        # ================================================================================================================
        dict(name="billing_arrangement", product="DP-350", entity="Billing Arrangement", kind="Dimension",
             grain="institutional or separately managed billing arrangement x effective period",
             dimensions=[dict(name="billing_arrangement_id", attr="Billing Arrangement ID"),
                         dict(name="billed_mandate", attr="Billed Mandate"),
                         dict(name="bill_to_party", attr="Bill-To Party",
                              note="An institutional client or a planning client; personal data for individuals."),
                         dict(name="arrangement_fee_schedule", attr="Applied Fee Schedule"),
                         dict(name="arrangement_billing_frequency", attr="Billing Frequency"),
                         dict(name="arrangement_fee_collection_method", attr="Fee Collection Method"),
                         dict(name="billing_currency", attr="Billing Currency",
                              note="Required with any invoice amount: no FX conversion in the product."),
                         dict(name="performance_fee_eligibility_basis", attr="Performance Fee Eligibility Basis"),
                         dict(name="qualified_client_determination", attr="Qualified Client Determination"),
                         dict(name="qualified_client_determination_date", attr="Qualified Client Determination Date"),
                         dict(name="mfn_clause", attr="MFN Clause Indicator"),
                         dict(name="payment_terms_days", attr="Payment Terms Days"),
                         dict(name="billing_effective_from", attr="Billing Effective From"),
                         dict(name="billing_effective_to", attr="Billing Effective To")]),

        dict(name="performance_fee_calculation", product="DP-350", entity="Fact Performance Fee Calculation", kind="Fact",
             grain="billing arrangement x calculation period end",
             dimensions=[dict(name="performance_fee_billing_arrangement", attr="Performance Fee Billing Arrangement"),
                         dict(name="calculation_period_end", attr="Calculation Period End"),
                         dict(name="hurdle_benchmark", attr="Hurdle Benchmark"),
                         dict(name="crystallized", attr="Crystallized Indicator"),
                         dict(name="calculation_approved_by", attr="Calculation Approved By")],
             facts=[dict(name="high_water_mark_value", attr="High-Water Mark Value"),
                    dict(name="calculated_performance_fee", attr="Calculated Performance Fee")]),

        dict(name="fee_receivable", product="DP-350", entity="Fact Fee Receivable", kind="Fact",
             grain="19 receivable item raised from a fee invoice",
             default_filter="the latest as-of date",
             dimensions=[dict(name="receivable_document_number", attr="Receivable Document Number"),
                         dict(name="customer_party", attr="Customer Party"),
                         dict(name="source_fee_invoice", attr="Source Fee Invoice"),
                         dict(name="receivable_due_date", attr="Receivable Due Date"),
                         dict(name="receivable_status", attr="Receivable Status")],
             facts=[dict(name="original_receivable_amount", attr="Original Receivable Amount"),
                    dict(name="open_receivable_amount", attr="Open Receivable Amount")]),

        # ================================================================================================================
        # DP-497 Client Revenue Yield & Pricing (revenue rows are read from DP-012's client_revenue and fee_revenue)
        # ================================================================================================================
        dict(name="pricing_scenario", product="DP-497", entity="Pricing Scenario", kind="Dimension",
             grain="pricing scenario",
             dimensions=[dict(name="pricing_scenario_id", attr="Pricing Scenario ID"),
                         dict(name="pricing_scenario_type", attr="Pricing Scenario Type"),
                         dict(name="priced_subject", attr="Priced Subject",
                              note="A service offering or a fee schedule (GAP-10-027)."),
                         dict(name="proposed_schedule_version", attr="Proposed Schedule Version"),
                         dict(name="scenario_base_date", attr="Scenario Base Date")],
             facts=[dict(name="affected_client_assets", attr="Affected Client Assets",
                         note="The scenario's own estimate at its base date; not the certified Client Assets."),
                    dict(name="assumed_retention_rate", attr="Assumed Retention Rate"),
                    dict(name="assumed_flow_response", attr="Assumed Flow Response")]),

        dict(name="pricing_scenario_result", product="DP-497", entity="Fact Pricing Scenario Result", kind="Fact",
             grain="pricing scenario x projection year (projections, never actuals)",
             dimensions=[dict(name="scenario_key", attr="Pricing Scenario Key"),
                         dict(name="projection_year", attr="Projection Year")],
             facts=[dict(name="projected_revenue_under_scenario", attr="Projected Revenue Under Scenario"),
                    dict(name="projected_revenue_impact", attr="Projected Revenue Impact")]),

        # ================================================================================================================
        # DP-498 Client Cost to Serve & Lifetime Value (acceptance question 11)
        # ================================================================================================================
        # The published cut: segment, tier, offering and channel aggregates with a 10-household minimum cell. Each cut reads
        # only the records whose Dimension Grain is that cut, so grains are never added together.
        dict(name="cost_to_serve", product="DP-498", entity="Fact Cost to Serve", kind="Fact",
             grain="profitability period x served dimension (one dimension_grain per row) x data version",
             always_filter=PROFITABILITY_PINS + [
                 "dimension_grain in ('Client Segment', 'Service Tier', 'Service Offering', 'Channel', 'Business Line') "
                 "and exactly one dimension_grain per query (the cut asked for); household and account grains are "
                 "only in household_cost_to_serve",
                 MONTHS],
             default_filter="dimension_grain = 'Client Segment'",
             dimensions=[dict(name="cts_profitability_period", attr="Profitability Period"),
                         dict(name="cts_data_version", attr="Data Version"),
                         dict(name="cts_dimension_grain", attr="Dimension Grain"),
                         dict(name="cts_channel", attr="Channel"),
                         dict(name="cts_business_line", attr="Business Line"),
                         dict(name="cts_service_offering", attr="Service Offering"),
                         dict(name="cts_service_tier", attr="Service Tier"),
                         dict(name="cts_client_segment", attr="Client Segment"),
                         dict(name="cts_hierarchy_version", attr="Hierarchy Version"),
                         dict(name="cts_source_allocation_run", attr="Source Allocation Run")],
             facts=[dict(name="coverage_and_servicing_cost", attr="Coverage and Servicing Cost"),
                    dict(name="client_service_cost", attr="Client Service Cost"),
                    dict(name="platform_technology_cost", attr="Platform & Technology Cost"),
                    dict(name="clearing_custody_cost", attr="Clearing & Client Asset Custody Cost"),
                    dict(name="money_movement_cost", attr="Money Movement Cost"),
                    dict(name="communications_regulatory_cost", attr="Communications & Regulatory Cost"),
                    dict(name="total_cost_to_serve", attr="Total Cost-to-Serve")],
             hidden=[("Cost-to-Serve Rate", "The served subject's own rate; at published cuts the rate is "
                                            "[Cost to Serve Rate (bps)], a ratio of sums."),
                     ("Profitability Record ID", "Row key.")]),

        # Restricted view 'DP-498 Household Economics' (DP-518; CW-243, CD-344): household cost rows.
        dict(name="household_cost_to_serve", product="DP-498", entity="Fact Cost to Serve", kind="Fact",
             grain="profitability period x household (Dimension Grain Household) x data version; restricted",
             always_filter=PROFITABILITY_PINS + ["dimension_grain = 'Household'", MONTHS],
             dimensions=[dict(name="hh_cts_profitability_period", attr="Profitability Period"),
                         dict(name="served_party", attr="Served Party",
                              note="The 02 Client Household; released only in the DP-518 'DP-498 Household Economics' view."),
                         dict(name="served_client_account", attr="Client / Account"),
                         dict(name="hh_cts_client_segment", attr="Client Segment"),
                         dict(name="hh_cts_service_tier", attr="Service Tier")],
             facts=[dict(name="household_total_cost_to_serve", attr="Total Cost-to-Serve")]),

        # Restricted view 'DP-498 Household Economics': household lifetime value estimates. Broad roles see only the
        # aggregates of [Average Household Lifetime Value] with the 10-household minimum cell.
        dict(name="household_lifetime_value", product="DP-498", entity="Fact Household Lifetime Value (restricted)",
             kind="Fact",
             grain="household x lifetime value model version x estimate as-of date; restricted",
             always_filter=["estimate_as_of_date = the latest Estimate As-Of Date",
                            "valuation_model_version = the lifetime value model version in use"],
             dimensions=[dict(name="valued_household", attr="Valued Household"),
                         dict(name="valuation_model_version", attr="Valuation Model Version"),
                         dict(name="estimate_as_of_date", attr="Estimate As-Of Date"),
                         dict(name="household_acquisition_channel", attr="Household Acquisition Channel")],
             facts=[dict(name="expected_lifetime_revenue", attr="Expected Lifetime Revenue"),
                    dict(name="expected_lifetime_cost_to_serve", attr="Expected Lifetime Cost to Serve"),
                    dict(name="client_lifetime_value", attr="Client Lifetime Value")]),

        dict(name="lifetime_value_model", product="DP-498", entity="Lifetime Value Model", kind="Dimension",
             grain="lifetime value model x version",
             dimensions=[dict(name="lifetime_value_model_id", attr="Lifetime Value Model ID"),
                         dict(name="lifetime_value_model_version", attr="Lifetime Value Model Version"),
                         dict(name="lifetime_value_method", attr="Lifetime Value Method"),
                         dict(name="projection_horizon_years", attr="Projection Horizon Years"),
                         dict(name="discount_rate", attr="Discount Rate"),
                         dict(name="attrition_assumption_basis", attr="Attrition Assumption Basis"),
                         dict(name="margin_basis", attr="Margin Basis"),
                         dict(name="model_inventory_entry", attr="Model Inventory Entry Key")]),

        dict(name="acquisition_cost", product="DP-498", entity="Fact Acquisition Cost", kind="Fact",
             grain="acquisition channel x campaign (or ALL) x cohort month",
             dimensions=[dict(name="acquisition_channel", attr="Acquisition Channel"),
                         dict(name="acquisition_campaign", attr="Acquisition Campaign",
                              note="A 04 Campaign or ALL for non-campaign acquisition (advisor referral, workplace rollover)."),
                         dict(name="cohort_month", attr="Cohort Month")],
             facts=[dict(name="allocated_acquisition_cost", attr="Allocated Acquisition Cost"),
                    dict(name="new_households_acquired", attr="New Households Acquired",
                         note="The 04 derived count of the cost denominator; certified household counts are SM-20's.")]),

        # ================================================================================================================
        # DP-499 Client, Offering & Advisor Profitability
        # ================================================================================================================
        dict(name="profitability", product="DP-499", entity="Fact Profitability", kind="Fact",
             grain="profitability period x dimension combination (one dimension_grain per row) x data version x hierarchy version",
             always_filter=PROFITABILITY_PINS + [
                 "dimension_grain in ('Client Segment', 'Service Offering', 'Channel', 'Business Line', "
                 "'Product / Share Class', 'Partner Firm', 'Service Tier') and exactly one dimension_grain per query; "
                 "advisor and household grains are only in the restricted tables",
                 MONTHS],
             default_filter="dimension_grain = 'Business Line'",
             dimensions=[dict(name="profitability_period", attr="Profitability Period"),
                         dict(name="data_version", attr="Data Version"),
                         dict(name="dimension_grain", attr="Dimension Grain"),
                         dict(name="profitability_channel", attr="Channel"),
                         dict(name="profitability_business_line", attr="Business Line"),
                         dict(name="profitability_service_offering", attr="Service Offering"),
                         dict(name="profitability_service_tier", attr="Service Tier"),
                         dict(name="partner_firm", attr="Partner Firm"),
                         dict(name="product_share_class", attr="Product / Share Class"),
                         dict(name="profitability_client_segment", attr="Client Segment"),
                         dict(name="reporting_legal_entity", attr="Reporting Legal Entity"),
                         dict(name="hierarchy_version", attr="Hierarchy Version"),
                         dict(name="source_allocation_run", attr="Source Allocation Run"),
                         dict(name="reporting_currency", attr="Reporting Currency")],
             facts=[dict(name="gross_revenue", attr="Gross Revenue"),
                    dict(name="distribution_payments", attr="Distribution Payments"),
                    dict(name="net_revenue_after_distribution_costs", attr="Net Revenue After Distribution Costs"),
                    dict(name="direct_sales_marketing_cost", attr="Direct Sales & Marketing Cost"),
                    dict(name="contribution_margin", attr="Contribution Margin"),
                    dict(name="allocated_indirect_cost", attr="Allocated Indirect Cost"),
                    dict(name="operating_profit", attr="Operating Profit")],
             hidden=[("Net Revenue Yield", "The record's own yield on its Average AUM Reference basis, which the product "
                                           "does not use; published as [Net Revenue Yield on Client Assets (bps)]."),
                     ("Operating Margin", "A row ratio; published as [Operating Margin %], a ratio of sums."),
                     ("Total Cost-to-Serve", "The DP-498 cost-to-serve profile; published once as [Total Cost to Serve]."),
                     ("Profitability Record ID", "Row key.")]),

        # Restricted view 'DP-499 Advisor Book' (DP-518; CW-243): advisor rows carry allocated compensation cost.
        dict(name="advisor_book_profitability", product="DP-499", entity="Fact Profitability", kind="Fact",
             grain="profitability period x advisor (Dimension Grain Advisor); restricted",
             always_filter=PROFITABILITY_PINS + ["dimension_grain = 'Advisor'", MONTHS],
             dimensions=[dict(name="advisor_profitability_period", attr="Profitability Period"),
                         dict(name="profitability_advisor", attr="Advisor",
                              note="DP-009 Employee; released only in the DP-518 'DP-499 Advisor Book' view."),
                         dict(name="advisor_business_line", attr="Business Line"),
                         dict(name="advisor_channel", attr="Channel")],
             facts=[dict(name="advisor_gross_revenue", attr="Gross Revenue"),
                    dict(name="advisor_contribution_margin", attr="Contribution Margin"),
                    dict(name="advisor_operating_profit", attr="Operating Profit")]),

        # Restricted view 'DP-499 Household Profitability' (DP-518): household and account rows.
        dict(name="household_profitability", product="DP-499", entity="Fact Profitability", kind="Fact",
             grain="profitability period x household or account (Dimension Grain Household); restricted",
             always_filter=PROFITABILITY_PINS + ["dimension_grain = 'Household'", MONTHS],
             dimensions=[dict(name="household_profitability_period", attr="Profitability Period"),
                         dict(name="profitability_client_account", attr="Client / Account",
                              note="Released only in the DP-518 'DP-499 Household Profitability' view."),
                         dict(name="household_client_segment", attr="Client Segment")],
             facts=[dict(name="household_operating_profit", attr="Operating Profit")]),

        dict(name="profitability_measure_definition", product="DP-499", entity="Profitability Measure Definition",
             kind="Dimension",
             dimensions=[dict(name="profitability_measure_code", attr="Profitability Measure Code"),
                         dict(name="measure_formula", attr="Measure Formula")]),

        # ================================================================================================================
        # DP-503 Intercompany Charges & Transfer Pricing
        # ================================================================================================================
        dict(name="intercompany_charge", product="DP-503", entity="Fact Intercompany Charge", kind="Fact",
             grain="intercompany agreement x charge period (closed periods final)",
             always_filter=["charge_period is a fiscal month"],
             dimensions=[dict(name="intercompany_charge_id", attr="Intercompany Charge ID"),
                         dict(name="charging_agreement", attr="Charging Agreement"),
                         dict(name="charge_period", attr="Charge Period"),
                         dict(name="settlement_status", attr="Settlement Status"),
                         dict(name="elimination_indicator", attr="Elimination Indicator"),
                         dict(name="arms_length_flag", attr="Arm's Length Flag",
                              note="Per agreement and fiscal year; Y within the TP policy range.")],
             facts=[dict(name="charge_amount", attr="Charge Amount")]),

        dict(name="intercompany_agreement", product="DP-503", entity="Intercompany Agreement", kind="Dimension",
             dimensions=[dict(name="intercompany_agreement_id", attr="Intercompany Agreement ID"),
                         dict(name="service_provider_entity", attr="Service Provider Entity"),
                         dict(name="service_recipient_entity", attr="Service Recipient Entity"),
                         dict(name="intercompany_service_type", attr="Intercompany Service Type"),
                         dict(name="agreement_effective_from", attr="Agreement Effective From"),
                         dict(name="agreement_effective_to", attr="Agreement Effective To"),
                         dict(name="tp_method", attr="TP Method"),
                         dict(name="remuneration_basis", attr="Remuneration Basis"),
                         dict(name="remuneration_rate", attr="Remuneration Rate"),
                         dict(name="tested_party", attr="Tested Party"),
                         dict(name="arms_length_range_lower_bound", attr="Arm's Length Range Lower Bound"),
                         dict(name="arms_length_range_upper_bound", attr="Arm's Length Range Upper Bound"),
                         dict(name="tp_documentation_reference", attr="TP Documentation Reference")]),

        dict(name="tp_documentation", product="DP-503", entity="Fact TP Documentation", kind="Fact",
             grain="documented legal entity x fiscal year x documentation type",
             dimensions=[dict(name="tp_documentation_id", attr="TP Documentation ID"),
                         dict(name="documented_legal_entity", attr="Documented Legal Entity"),
                         dict(name="tp_documentation_type", attr="TP Documentation Type"),
                         dict(name="tp_documentation_fiscal_year", attr="TP Documentation Fiscal Year"),
                         dict(name="covered_intercompany_agreements", attr="Covered Intercompany Agreements"),
                         dict(name="contemporaneous", attr="Contemporaneous Indicator")],
             facts=[dict(name="covered_transaction_value", attr="Covered Transaction Value")]),

        # Restricted view 'DP-503 Member-Level Allocation Read' (DP-518): the allocation results with Target Dimension
        # Legal Entity, the cost basis of cost-based transfer pricing.
        dict(name="legal_entity_allocation", product="DP-503", entity="Fact Allocation Result (restricted)", kind="Fact",
             grain="allocation run x allocation rule x legal entity member (Target Dimension Legal Entity); restricted",
             always_filter=["allocation run with Run Status = 'Final'", "target dimension = 'Legal Entity'"],
             dimensions=[dict(name="le_allocation_run", attr="Allocation Run Key"),
                         dict(name="le_allocated_rule", attr="Allocated Rule"),
                         dict(name="le_target_member", attr="Target Dimension Member",
                              note="An Internal Legal Entity; released only in the DP-518 'DP-503 Member-Level "
                                   "Allocation Read' view.")],
             facts=[dict(name="le_allocated_amount", attr="Allocated Amount")]),

        dict(name="entity_distribution_role", product="DP-503", entity="Entity Distribution Role", kind="Dimension",
             dimensions=[dict(name="role_entity", attr="Role Entity"),
                         dict(name="distribution_role", attr="Distribution Role"),
                         dict(name="default_contracting_entity", attr="Default Contracting Entity Indicator"),
                         dict(name="role_effective_from", attr="Role Effective From")]),

        # ================================================================================================================
        # DP-480 Cost Allocation & Management Hierarchies
        # ================================================================================================================
        dict(name="cost_pool", product="DP-480", entity="Cost Pool", kind="Dimension",
             grain="cost pool x effective period",
             dimensions=[dict(name="cost_pool_id", attr="Cost Pool ID"),
                         dict(name="cost_pool_type", attr="Cost Pool Type"),
                         dict(name="cost_to_serve_component", attr="Cost-to-Serve Component"),
                         dict(name="contributing_cost_centers", attr="Contributing Cost Centers",
                              note="A cost center contributes to one pool only (DQ2)."),
                         dict(name="included_expense_categories", attr="Included Expense Categories")]),

        dict(name="allocation_method", product="DP-480", entity="Allocation Method", kind="Dimension",
             dimensions=[dict(name="allocation_method_id", attr="Allocation Method ID"),
                         dict(name="allocation_method_name", attr="Allocation Method Name"),
                         dict(name="allocation_method_type", attr="Allocation Method Type")]),

        dict(name="allocation_rule", product="DP-480", entity="Allocation Rule", kind="Dimension",
             grain="source cost pool x method x driver x target dimension x rule effective period",
             dimensions=[dict(name="allocation_rule_id", attr="Allocation Rule ID"),
                         dict(name="source_cost_pool", attr="Source Cost Pool"),
                         dict(name="applied_allocation_method", attr="Applied Allocation Method"),
                         dict(name="applied_driver", attr="Applied Driver"),
                         dict(name="target_dimension", attr="Target Dimension"),
                         dict(name="allocation_sequence", attr="Allocation Sequence"),
                         dict(name="rule_effective_from", attr="Rule Effective From"),
                         dict(name="rule_effective_to", attr="Rule Effective To")]),

        dict(name="allocation_run", product="DP-480", entity="Allocation Run", kind="Dimension",
             grain="allocation run (run period x run data version)",
             default_filter="run_status = 'Final'",
             dimensions=[dict(name="allocation_run_id", attr="Allocation Run ID"),
                         dict(name="run_period", attr="Run Period"),
                         dict(name="run_data_version", attr="Run Data Version"),
                         dict(name="allocation_run_status", attr="Run Status")],
             facts=[dict(name="unallocated_residual", attr="Unallocated Residual")]),

        # Allocation results. Rows whose Target Dimension is Household, Account, Client or Advisor are published summed over
        # members (member suppressed, CW-243); the member column is released only to the allocation owner.
        dict(name="allocation_result", product="DP-480", entity="Allocation Result", kind="Fact",
             grain="allocation run x allocation rule x target dimension member",
             always_filter=["allocation run with Run Status = 'Final' (one per run period); Superseded runs are history"],
             dimensions=[dict(name="result_allocation_run", attr="Allocation Run Key"),
                         dict(name="allocated_rule", attr="Allocated Rule"),
                         dict(name="target_dimension_member", attr="Target Dimension Member",
                              note="A cost pool (pool-to-pool transfer) or a final target member; household, account, "
                                   "client and advisor members are personal data.")],
             facts=[dict(name="driver_share", attr="Driver Share"),
                    dict(name="allocated_amount", attr="Allocated Amount")]),

        dict(name="management_hierarchy", product="DP-480", entity="Management Hierarchy", kind="Dimension",
             grain="management hierarchy version",
             dimensions=[dict(name="management_hierarchy_id", attr="Management Hierarchy ID"),
                         dict(name="hierarchy_type", attr="Hierarchy Type"),
                         dict(name="hierarchy_status", attr="Hierarchy Status"),
                         dict(name="hierarchy_effective_from", attr="Hierarchy Effective From"),
                         dict(name="hierarchy_effective_to", attr="Hierarchy Effective To")]),

        dict(name="management_hierarchy_node", product="DP-480", entity="Management Hierarchy Node", kind="Dimension",
             grain="hierarchy version x node",
             dimensions=[dict(name="node_hierarchy", attr="Management Hierarchy Key"),
                         dict(name="node_id", attr="Node ID"),
                         dict(name="parent_node", attr="Parent Node"),
                         dict(name="leaf_member", attr="Leaf Member"),
                         dict(name="operating_segment_mapping", attr="Operating Segment Mapping")]),

        dict(name="hierarchy_restatement", product="DP-480", entity="Hierarchy Restatement", kind="Fact",
             grain="hierarchy restatement event",
             dimensions=[dict(name="restatement_id", attr="Restatement ID"),
                         dict(name="restatement_trigger", attr="Restatement Trigger"),
                         dict(name="restatement_method", attr="Restatement Method"),
                         dict(name="restated_from_period", attr="Restated From Period"),
                         dict(name="restated_to_period", attr="Restated To Period"),
                         dict(name="prior_hierarchy_version", attr="Prior Hierarchy Version")]),

        # ================================================================================================================
        # DP-242 Fund 360 (cross-area view; every number in it is read from its owning product)
        # ================================================================================================================
        dict(name="fund_360", product="DP-242", entity="Fact Fund 360", kind="Fact",
             grain="share class x month-end, with a fund-level row per month-end rolling up its classes",
             always_filter=["share class rows only (Share Class Key populated); fund rows repeat their classes"],
             dimensions=[dict(name="fund_360_fiscal_period", attr="Fiscal Period Key"),
                         dict(name="fund_360_month_end", attr="Calendar Date Key"),
                         dict(name="fund_360_product", attr="Investment Product Key"),
                         dict(name="fund_360_share_class", attr="Share Class Key"),
                         dict(name="lifecycle_status", attr="Lifecycle Status",
                              note="Share Class Status and the latest Lifecycle Event (from DP-004)."),
                         dict(name="watch_list_flag", attr="Watch List Flag",
                              note="Y when 3-year excess return, trailing 12-month operating profit or net flows are "
                                   "below zero (with assets below minimum viable size), or an advisory agreement "
                                   "approval expires within 90 days.")],
             hidden=[("Fact Fund 360 Key", "Row key.")]),

        # ================================================================================================================
        # DP-008 certified client assets (SM-20's certified source), read only to slice the referenced Average Client
        # Assets and Households by the cuts of the yield and cost-to-serve ratios.
        # ================================================================================================================
        dict(name="client_assets", product="DP-008", entity="Measure Value", kind="Fact",
             grain="dimension type x dimension key x month (locked snapshot)",
             always_filter=["dimension_type = the cut asked for: one of 'Total', 'Channel', 'Segment', 'Business Line', "
                            "'Service Offering'; never summed across dimension types"] + LOCKED_MONTHS,
             dimensions=[dict(name="assets_period_end_date", attr="Period End Date"),
                         dict(name="assets_dimension_type", attr="Dimension Type"),
                         dict(name="assets_dimension_key", attr="Dimension Key",
                              note="The channel, segment, business line or offering code on rows of that type.")],
             facts=[dict(name="average_client_assets", attr="Average Client Assets"),
                    dict(name="households", attr="Households")]),
    ],

    shared=[
        "DP-240/Party",                     # Household (Party Type Household), client and bill-to party
        "DP-240/Household Membership",
        "DP-240/Segment Assignment",
        "DP-093/Account",                   # Client Account
        "DP-093/Account Party Role",
        "DP-093/Program Enrollment",
        "DP-009/Employee",                  # Advisor
        "DP-004/Service Offering",          # Program / offering
        "DP-004/Share Class",
        "DP-004/Investment Product",
        "DP-004/Service Tier",
        "DP-140/Investment Mandate",
        "DP-001/Distributor Firm",          # partner firm of the intermediary profitability cut
        "DP-190/GL Account",
        "DP-190/Cost Center",
        "DP-013/Calendar Date",
        "DP-013/Fiscal Period",
        "DP-013/Internal Legal Entity",
        "DP-212/Model",                     # model inventory of the lifetime value model
    ],

    relationships=[
        # --- client revenue ---------------------------------------------------------------------------------------------
        dict(frm="client_revenue", to="DP-093/Account", on="revenue_account_household = account_id (account rows)",
             type="many-to-one"),
        dict(frm="client_revenue", to="fee_household", on="revenue_account_household = fee_household_id (fee household rows)",
             type="many-to-one"),
        dict(frm="client_revenue", to="DP-004/Service Offering", on="revenue_service_offering = offering_id", type="many-to-one"),
        dict(frm="client_revenue", to="DP-013/Fiscal Period", on="client_revenue_period = fiscal_period_id", type="many-to-one"),
        dict(frm="client_revenue", to="DP-013/Internal Legal Entity", on="recognizing_legal_entity = legal_entity_id",
             type="many-to-one"),
        dict(frm="DP-093/Account", to="DP-093/Account Party Role",
             on="account_id = role_account and account_role_type = owner, effective at the fiscal period end",
             type="many-to-many",
             warning="An account can have several owners: revenue rolled to clients or households through this join is "
                     "counted once per owner unless the primary owner is chosen or Role Allocation Percentage is applied. "
                     "Pin the role effective at the period end."),
        dict(frm="DP-093/Account Party Role", to="DP-240/Household Membership",
             on="role_party = household_member, membership effective at the fiscal period end",
             type="many-to-many",
             warning="Household membership is many-to-many and effective dated: pin the membership in force at the period "
                     "end, or a member in two households counts twice (Client Fee Revenue by Household)."),
        dict(frm="DP-240/Household Membership", to="DP-240/Party", on="household = party_id (Party Type Household)",
             type="many-to-one"),
        dict(frm="DP-240/Party", to="DP-240/Segment Assignment",
             on="party_id = segmented_party, segment in force at the period end, one segmentation scheme",
             type="many-to-many",
             warning="A party has one segment per scheme and period; filter one Segmentation Scheme or revenue counts once "
                     "per scheme."),
        dict(frm="fee_household", to="DP-240/Party", on="anchor_client_household = party_id", type="many-to-one"),
        # --- own-fund revenue -------------------------------------------------------------------------------------------
        dict(frm="fee_revenue", to="DP-004/Share Class", on="revenue_share_class_mandate = share_class_id (share class rows)",
             type="many-to-one"),
        dict(frm="fee_revenue", to="DP-140/Investment Mandate", on="revenue_share_class_mandate = mandate_id (mandate rows)",
             type="many-to-one"),
        dict(frm="fee_revenue", to="DP-013/Fiscal Period", on="revenue_accounting_period = fiscal_period_id", type="many-to-one"),
        dict(frm="distribution_revenue", to="DP-004/Share Class", on="paying_share_class = share_class_id", type="many-to-one"),
        dict(frm="distribution_revenue", to="DP-013/Internal Legal Entity", on="receiving_entity = legal_entity_id",
             type="many-to-one"),
        dict(frm="distribution_revenue", to="DP-013/Fiscal Period", on="distribution_fiscal_period = fiscal_period_id",
             type="many-to-one"),
        dict(frm="fund_waiver", to="DP-004/Share Class", on="supported_share_class = share_class_id", type="many-to-one"),
        dict(frm="fund_waiver", to="DP-013/Fiscal Period", on="waiver_fiscal_period = fiscal_period_id", type="many-to-one"),
        dict(frm="performance_fee", to="DP-004/Share Class", on="performance_fee_share_class = share_class_id",
             type="many-to-one"),
        dict(frm="cash_program_economics", to="DP-013/Fiscal Period", on="economics_period = fiscal_period_id",
             type="many-to-one"),
        # --- billing (DP-305, DP-346) -----------------------------------------------------------------------------------
        dict(frm="account_fee_calculation", to="fee_run", on="calculation_run = fee_calculation_run_id", type="many-to-one"),
        dict(frm="account_fee_calculation", to="fee_schedule_assignment",
             on="calculated_assignment = fee_schedule_assignment_id, assignment in force at run_billing_period_end",
             type="many-to-one"),
        dict(frm="account_fee_calculation", to="billing_arrangement",
             on="calculated_billing_arrangement = billing_arrangement_id", type="many-to-one"),
        dict(frm="account_fee_calculation", to="fee_schedule", on="schedule_version_applied = fee_schedule_id (version)",
             type="many-to-one"),
        dict(frm="fee_billing_test", to="account_fee_calculation",
             on="(test_calculation_run, test_calculated_assignment, test_calculated_billing_arrangement) = "
                "(calculation_run, calculated_assignment, calculated_billing_arrangement)",
             type="one-to-one"),
        dict(frm="fee_calculation_exception", to="account_fee_calculation", on="exception_calculation = the calculation key",
             type="many-to-one"),
        dict(frm="fee_run", to="DP-013/Calendar Date", on="run_billing_period_end = calendar_date", type="many-to-one"),
        dict(frm="fee_schedule_assignment", to="fee_schedule", on="assigned_fee_schedule = fee_schedule_id", type="many-to-one"),
        dict(frm="fee_schedule_assignment", to="DP-093/Account", on="billed_account = account_id", type="many-to-one"),
        dict(frm="fee_schedule_assignment", to="DP-093/Program Enrollment", on="billed_enrollment = program_enrollment_id",
             type="many-to-one"),
        dict(frm="fee_schedule_assignment", to="fee_household", on="assigned_fee_household = fee_household_id",
             type="many-to-one"),
        dict(frm="fee_household_membership", to="fee_household", on="membership_fee_household = fee_household_id",
             type="many-to-one"),
        dict(frm="fee_household_membership", to="DP-093/Account", on="member_account = account_id", type="many-to-one"),
        dict(frm="fee_waiver", to="fee_schedule_assignment", on="waived_assignment = fee_schedule_assignment_id",
             type="many-to-one"),
        dict(frm="fee_debit", to="account_fee_calculation", on="debited_calculation = the calculation key", type="many-to-one"),
        dict(frm="fee_debit", to="DP-093/Account", on="debited_account = account_id", type="many-to-one"),
        dict(frm="fee_invoice", to="billing_arrangement", on="invoice_billing_arrangement = billing_arrangement_id",
             type="many-to-one"),
        dict(frm="fee_invoice", to="fee_schedule_assignment",
             on="invoice_fee_schedule_assignment = fee_schedule_assignment_id", type="many-to-one"),
        dict(frm="fee_invoice", to="DP-240/Party", on="invoice_bill_to_party = party_id", type="many-to-one"),
        dict(frm="fee_adjustment", to="fee_invoice", on="adjusted_invoice = invoice_id", type="many-to-one"),
        dict(frm="fee_adjustment", to="account_fee_calculation", on="adjusted_fee_calculation = the calculation key",
             type="many-to-one"),
        dict(frm="fee_adjustment", to="billing_dispute", on="related_billing_dispute = billing_dispute_id", type="many-to-one"),
        dict(frm="billing_dispute", to="fee_invoice", on="disputed_invoice = invoice_id", type="many-to-one"),
        dict(frm="billing_dispute", to="account_fee_calculation", on="disputed_fee_calculation = the calculation key",
             type="many-to-one"),
        dict(frm="fee_deduction_authorization", to="DP-093/Account", on="authorized_account = account_id", type="many-to-one"),
        # --- commissions and service charges (DP-349) -------------------------------------------------------------------
        dict(frm="commission_re_performance", to="DP-093/Account", on="confirmation_account = account_id", type="many-to-one"),
        dict(frm="commission_re_performance", to="fee_schedule", on="commission_fee_schedule = fee_schedule_id",
             type="many-to-one"),
        dict(frm="commission_re_performance", to="DP-013/Calendar Date", on="confirmed_trade_date = calendar_date",
             type="many-to-one"),
        dict(frm="account_service_charge", to="account_service_fee_item",
             on="(charged_service_fee_schedule, service_charge_type) = (service_fee_schedule, account_service_type), item in force on the debit date",
             type="many-to-one"),
        dict(frm="account_service_charge", to="DP-093/Account", on="service_charge_account = account_id", type="many-to-one"),
        # --- institutional invoicing (DP-350) ---------------------------------------------------------------------------
        dict(frm="billing_arrangement", to="fee_schedule", on="arrangement_fee_schedule = fee_schedule_id", type="many-to-one"),
        dict(frm="billing_arrangement", to="DP-140/Investment Mandate", on="billed_mandate = mandate_id", type="many-to-one"),
        dict(frm="billing_arrangement", to="DP-240/Party", on="bill_to_party = party_id", type="many-to-one"),
        dict(frm="performance_fee_calculation", to="billing_arrangement",
             on="performance_fee_billing_arrangement = billing_arrangement_id", type="many-to-one"),
        dict(frm="fee_receivable", to="fee_invoice", on="source_fee_invoice = invoice_id", type="many-to-one"),
        # --- pricing, cost to serve, lifetime value, profitability ------------------------------------------------------
        dict(frm="pricing_scenario_result", to="pricing_scenario", on="scenario_key = pricing_scenario_id", type="many-to-one"),
        dict(frm="cost_to_serve", to="allocation_run", on="cts_source_allocation_run = allocation_run_id", type="many-to-one"),
        dict(frm="cost_to_serve", to="DP-004/Service Offering", on="cts_service_offering = offering_id", type="many-to-one"),
        dict(frm="cost_to_serve", to="DP-004/Service Tier", on="cts_service_tier = service_tier_code", type="many-to-one"),
        dict(frm="household_cost_to_serve", to="DP-240/Party", on="served_party = party_id (Party Type Household)",
             type="many-to-one"),
        dict(frm="household_lifetime_value", to="DP-240/Party", on="valued_household = party_id (Party Type Household)",
             type="many-to-one"),
        dict(frm="household_lifetime_value", to="lifetime_value_model",
             on="valuation_model_version = (lifetime_value_model_id, lifetime_value_model_version)", type="many-to-one"),
        dict(frm="lifetime_value_model", to="DP-212/Model", on="model_inventory_entry = (model_id, model_version)",
             type="many-to-one"),
        dict(frm="profitability", to="allocation_run", on="source_allocation_run = allocation_run_id", type="many-to-one"),
        dict(frm="profitability", to="DP-004/Service Offering", on="profitability_service_offering = offering_id",
             type="many-to-one"),
        dict(frm="profitability", to="DP-004/Share Class", on="product_share_class = share_class_id", type="many-to-one"),
        dict(frm="profitability", to="DP-001/Distributor Firm", on="partner_firm = distributor_firm_party", type="many-to-one"),
        dict(frm="profitability", to="DP-013/Internal Legal Entity", on="reporting_legal_entity = legal_entity_id",
             type="many-to-one"),
        dict(frm="advisor_book_profitability", to="DP-009/Employee", on="profitability_advisor = employee_id",
             type="many-to-one"),
        dict(frm="household_profitability", to="DP-240/Party", on="profitability_client_account = party_id (household rows)",
             type="many-to-one"),
        # --- intercompany and allocation --------------------------------------------------------------------------------
        dict(frm="intercompany_charge", to="intercompany_agreement", on="charging_agreement = intercompany_agreement_id",
             type="many-to-one"),
        dict(frm="intercompany_agreement", to="DP-013/Internal Legal Entity", on="service_provider_entity = legal_entity_id",
             type="many-to-one"),
        dict(frm="tp_documentation", to="DP-013/Internal Legal Entity", on="documented_legal_entity = legal_entity_id",
             type="many-to-one"),
        dict(frm="legal_entity_allocation", to="allocation_run", on="le_allocation_run = allocation_run_id", type="many-to-one"),
        dict(frm="legal_entity_allocation", to="allocation_rule", on="le_allocated_rule = allocation_rule_id",
             type="many-to-one"),
        dict(frm="entity_distribution_role", to="DP-013/Internal Legal Entity", on="role_entity = legal_entity_id",
             type="many-to-one"),
        dict(frm="allocation_result", to="allocation_run", on="result_allocation_run = allocation_run_id", type="many-to-one"),
        dict(frm="allocation_result", to="allocation_rule", on="allocated_rule = allocation_rule_id", type="many-to-one"),
        dict(frm="allocation_rule", to="cost_pool", on="source_cost_pool = cost_pool_id", type="many-to-one"),
        dict(frm="allocation_rule", to="allocation_method", on="applied_allocation_method = allocation_method_id",
             type="many-to-one"),
        dict(frm="cost_pool", to="DP-190/Cost Center", on="contributing_cost_centers contains segment_value_code",
             type="many-to-many",
             warning="A pool lists several cost centers; a cost center contributes to one pool only (DQ2), so summing "
                     "pool source cost over pools is safe, but joining cost center attributes to allocated rows "
                     "repeats each row per contributing cost center."),
        dict(frm="management_hierarchy_node", to="management_hierarchy", on="node_hierarchy = management_hierarchy_id",
             type="many-to-one"),
        dict(frm="hierarchy_restatement", to="management_hierarchy", on="prior_hierarchy_version = management_hierarchy_id",
             type="many-to-one"),
        # --- Fund 360 and certified client assets -----------------------------------------------------------------------
        dict(frm="fund_360", to="DP-004/Share Class", on="fund_360_share_class = share_class_id", type="many-to-one"),
        dict(frm="fund_360", to="DP-004/Investment Product", on="fund_360_product = product_id", type="many-to-one"),
        dict(frm="fund_360", to="DP-013/Fiscal Period", on="fund_360_fiscal_period = fiscal_period_id", type="many-to-one"),
        dict(frm="client_assets", to="DP-013/Calendar Date", on="assets_period_end_date = calendar_date", type="many-to-one"),
    ],

    hierarchies=[
        dict(name="Client revenue by business line", levels=["client_revenue.revenue_business_line",
                                                             "client_revenue.revenue_channel",
                                                             "client_revenue.revenue_service_offering",
                                                             "client_revenue.client_revenue_stream"]),
        dict(name="Fee schedule", levels=["fee_schedule.fee_schedule_type", "fee_schedule.fee_schedule_name",
                                          "fee_schedule.schedule_version_number"]),
        dict(name="Cost allocation chain", levels=["cost_pool.cost_to_serve_component", "cost_pool.cost_pool_type",
                                                   "cost_pool.cost_pool_id"]),
        dict(name="Management hierarchy", levels=["management_hierarchy.hierarchy_type",
                                                  "management_hierarchy_node.operating_segment_mapping",
                                                  "management_hierarchy_node.parent_node",
                                                  "management_hierarchy_node.node_id"]),
    ],

    metrics=[
        # ================================================================================================================
        # Certified client fee revenue (CW-011, CW-204): defined here only; every other model uses ref="SM-28/<name>"
        # ================================================================================================================
        dict(name="Gross Fee Revenue", aggregation="additive",
             expr="sum(client_revenue.recognized_revenue_amount) where client_revenue_stream in ('Advisory Fee', 'Wrap Fee', "
                  "'Planning Fee', 'Subscription Fee', 'Account Service Fee', 'Recordkeeping Fee', 'Trust Fee', 'OCIO Fee', "
                  "'Mandate Performance Fee') + sum(fee_revenue.gross_fee_revenue)",
             source=("DP-012", "Gross Fee Revenue"),
             description="Fee revenue recognized in the period: client fees at the billed net fee plus own-fund management "
                         "fees before fund-level waivers.",
             note="= [Client Fee Revenue] + own-fund Gross Fee Revenue. Offering, channel and business line slice the client "
                  "rows; fund rows carry a share class or mandate only and show under their share class (open decision). "
                  "Never computed from Client Assets or Firm AUM."),
        dict(name="Client Fee Revenue", aggregation="additive",
             expr="sum(client_revenue.recognized_revenue_amount) where client_revenue_stream in ('Advisory Fee', 'Wrap Fee', "
                  "'Planning Fee', 'Subscription Fee', 'Account Service Fee', 'Recordkeeping Fee', 'Trust Fee', 'OCIO Fee', "
                  "'Mandate Performance Fee')",
             source=("DP-012", "Client Fee Revenue"),
             description="The client fee slice of Gross Fee Revenue: fees recognized from client accounts and fee households, "
                         "without own-fund management fees.",
             note="A slice of [Gross Fee Revenue], not a second revenue number (CW-265); DP-598 and DP-346 tie billing to it."),
        dict(name="Net Fee Revenue", aggregation="additive",
             expr="[Gross Fee Revenue] - sum(fee_revenue.waiver_reimbursement_offset)",
             source=("DP-012", "Net Fee Revenue"),
             description="Gross fee revenue less own-fund fee waivers and expense reimbursements: the fee revenue the firm keeps.",
             note="Client fee streams enter as recognized (already net of 47 discounts, waivers and own-fund credits); the "
                  "fund rows enter at their Net Fee Revenue."),
        dict(name="Effective Net Fee Rate", aggregation="ratio",
             numerator="annualized sum(client_revenue.recognized_revenue_amount) of the asset-based client fee streams "
                       "('Advisory Fee', 'Wrap Fee', 'OCIO Fee', 'Trust Fee', 'Recordkeeping Fee') for the selected offerings, "
                       "channels, business lines and fiscal periods",
             denominator="average of account_fee_calculation.billable_assets of the calculations named in those records' "
                         "source_calculation_record whose fee_run billing period falls in the same fiscal periods (from DP-305)",
             source=("DP-012", "Effective Net Fee Rate"),
             description="Client fee revenue earned per dollar of billable client assets, as an annual rate.",
             note="One denominator, a row and its roll-ups always on this basis; never blended with [Fund Effective Net Fee "
                  "Rate] and never computed over Client Assets or Firm AUM."),

        # ================================================================================================================
        # DP-012 other revenue facts
        # ================================================================================================================
        dict(name="Fund Effective Net Fee Rate", aggregation="ratio",
             numerator="annualized sum(fee_revenue.net_fee_revenue) for the selected share classes and months",
             denominator="sum(fee_revenue.fee_basis_average_assets) averaged over the same months",
             source=("DP-012", "Fund Effective Net Fee Rate"),
             description="Own-fund net management fee revenue per dollar of fee basis average assets, as an annual rate.",
             note="Share class rows only; a ratio of sums, never an average of share class rates; never blended with the "
                  "client rate."),
        dict(name="Client Transaction and Interest Revenue", aggregation="additive",
             expr="sum(client_revenue.recognized_revenue_amount) where client_revenue_stream in ('Commission', "
                  "'Markup / Markdown', 'Margin Interest', 'Fully Paid Lending Revenue', 'Bank Sweep Fee', 'Order Routing Payment')",
             source=("DP-012", "Client Transaction and Interest Revenue"),
             description="Client revenue that is not fee revenue: commissions, markups, margin interest, lending, bank sweep "
                         "fees and order routing payments, by stream and recognizing legal entity."),
        dict(name="Client Fee Revenue by Household", aggregation="additive",
             expr="[Client Fee Revenue] rolled to the 02 Client Household: account rows through the owner Account Party Role "
                  "and the Household Membership in force at the period end; fee household rows through "
                  "fee_household.anchor_client_household; by client_segment_at_period_end",
             source=("DP-012", "Client Fee Revenue by Household"),
             description="Client fee revenue by client household and client segment, the revenue side of household economics.",
             note="Broad roles see it by segment only (10-household minimum cell); household rows are for the revenue "
                  "finance and household economics roles. The 47 fee household is only the route for fee-household rows."),
        dict(name="Waiver Cost", aggregation="additive",
             expr="sum(fund_waiver.waived_fee_amount + fund_waiver.reimbursed_expense_amount)",
             source=("DP-012", "Waiver Cost"),
             description="Own-fund fees waived and fund expenses reimbursed by the firm, by waiver type and share class."),
        dict(name="Gross Distribution Revenue", aggregation="additive",
             expr="sum(distribution_revenue.gross_distribution_revenue), grouped by distribution_revenue.receiving_entity",
             source=("DP-012", "Gross Distribution Revenue"),
             description="12b-1 and servicing fees of intermediary channel share classes booked by each receiving legal "
                         "entity before paying intermediaries.",
             note="Required dimension: receiving_entity; no total across receiving legal entities."),
        dict(name="Net Distribution Revenue Retained", aggregation="additive",
             expr="sum(distribution_revenue.gross_distribution_revenue - distribution_revenue.amount_passed_through), "
                  "grouped by distribution_revenue.receiving_entity",
             source=("DP-012", "Net Distribution Revenue Retained"),
             description="Distribution revenue each receiving legal entity keeps after passing fees through to intermediaries."),
        dict(name="Cash Program Revenue", aggregation="additive",
             expr="sum(cash_program_economics.program_bank_fee_earned), by economics_sweep_program, economics_program_bank "
                  "and economics_period, shown with average_swept_balance, average_client_rate_paid and net_spread",
             source=("DP-012", "Cash Program Revenue"),
             description="Fees earned from program banks on swept client cash, by sweep program, program bank and period.",
             note="Average Swept Balance is a period average: never summed over periods. Net Spread and Average Client Rate "
                  "Paid are rates read per row."),
        dict(name="Bank Sweep Fee Allocation Tie-Out", aggregation="additive",
             expr="sum(client_revenue.recognized_revenue_amount) where client_revenue_stream = 'Bank Sweep Fee' - [Cash "
                  "Program Revenue], for the same fiscal period",
             source=("DP-012", "Bank Sweep Fee Allocation Tie-Out"),
             description="Whether the bank sweep fees allocated to client revenue add up to the fees the program banks paid; "
                         "zero expected.",
             note="Empty when the bank sweep lever is off (reference default: money market sweep fund)."),
        dict(name="Performance Fee Revenue Recognized", aggregation="additive",
             expr="sum(performance_fee.recognized_performance_fee_revenue) where constraint_assessment_outcome in "
                  "('Unconstrained', 'Partially Constrained')",
             source=("DP-012", "Performance Fee Revenue Recognized"),
             description="Fulcrum fee adjustments of own funds recognized in the period, with the clawback exposure flag.",
             note="Institutional performance fees are client revenue records (Mandate Performance Fee) and are in [Client "
                  "Fee Revenue], not here."),

        # ================================================================================================================
        # DP-305 billing runs (billed amounts are operational, never revenue, CW-214)
        # ================================================================================================================
        dict(name="Active Fee Schedule Versions", aggregation="count_distinct",
             expr="count distinct (fee_schedule.fee_schedule_id, fee_schedule.schedule_version_number) where schedule_status "
                  "= 'Active' and version_effective_from <= as-of date < version_effective_to (or open)",
             source=("DP-305", "Active Fee Schedule Versions"),
             description="Fee schedule versions in force on the as-of date, by schedule type, billing basis and tier method."),
        dict(name="Active Fee Schedule Assignments", aggregation="count_distinct",
             expr="count distinct fee_schedule_assignment.fee_schedule_assignment_id in force on the as-of date",
             source=("DP-305", "Active Fee Schedule Assignments"),
             description="Accounts, enrollments and engagements assigned a fee schedule, by schedule type, collection method "
                         "and negotiated rate."),
        dict(name="Fee Household Member Accounts", aggregation="count_distinct",
             expr="count distinct fee_household_membership.member_account where membership and fee household are active on "
                  "the as-of date",
             source=("DP-305", "Fee Household Member Accounts"),
             description="Accounts grouped into fee households for breakpoints, by formation basis."),
        dict(name="Active Fee Waivers", aggregation="count_distinct",
             expr="count distinct fee_waiver.fee_waiver_id where waiver_period_start <= as-of date <= waiver_period_end (or "
                  "open), with the count where waiver_approved_by is blank",
             source=("DP-305", "Active Fee Waivers"),
             description="Fee waivers in force, by waiver reason, and how many lack an approver."),
        dict(name="Fee Calculation Runs", aggregation="count_distinct",
             expr="count distinct fee_run.fee_calculation_run_id where run_billing_period_end is in the period",
             source=("DP-305", "Fee Calculation Runs"),
             description="Fee calculation runs of the period, by run type, run status and reconciliation status."),
        dict(name="Run Control Total Variance", aggregation="non_additive",
             expr="per fee_run with run_status in ('Approved', 'Released'): fee_run.run_net_fee_total - "
                  "sum(account_fee_calculation.net_fee of the run)",
             source=("DP-305", "Run Control Total Variance"),
             description="How far a run's control total differs from the sum of its account calculations, in USD; zero expected.",
             note="Read per run (listed by run); DP-346 reads it by name to fail runs (Failed Fee Runs)."),
        dict(name="Billable Assets Billed", aggregation="semi_additive",
             expr="sum(account_fee_calculation.billable_assets) over the billed calculation set",
             time_rule="last billing period in the selected range (each run values assets at its Valuation As-Of Date)",
             source=("DP-305", "Billable Assets Billed"),
             description="Client assets fees were billed on, by fee schedule type and billing period.",
             note="A derived copy of 49 Client Holding valuations (18 for mandates); never Client Assets or Firm AUM and "
                  "never added to them."),
        dict(name="Gross Billed Fees", aggregation="additive",
             expr="sum(account_fee_calculation.gross_fee) over the billed calculation set",
             source=("DP-305", "Gross Billed Fees"),
             description="Fees billed before discounts, waivers and own-fund credits, by fee schedule type and collection "
                         "method; billed, not recognized revenue."),
        dict(name="Fee Reductions Applied", aggregation="additive",
             expr="sum(account_fee_calculation.discount_amount + waiver_amount_applied + own_fund_credit_amount) over the "
                  "billed calculation set, by component",
             source=("DP-305", "Fee Reductions Applied"),
             description="Discounts, waivers and own-fund credits taken off billed fees, by component."),
        dict(name="Net Billed Fees", aggregation="additive",
             expr="sum(account_fee_calculation.net_fee) over the billed calculation set",
             source=("DP-305", "Net Billed Fees"),
             description="Fees billed after reductions, by fee schedule type, collection method and billing period.",
             note="DP-012 reads it to tie certified client fee revenue, never the reverse."),
        dict(name="Average Effective Annual Rate", aggregation="ratio",
             numerator="sum(account_fee_calculation.effective_annual_rate x account_fee_calculation.billable_assets) over the "
                       "billed calculation set",
             denominator="sum(account_fee_calculation.billable_assets) over the same rows",
             source=("DP-305", "Average Effective Annual Rate"),
             description="The billed annual fee rate weighted by billable assets, by fee schedule type and household asset band.",
             note="An operational billed rate, neither the certified [Effective Net Fee Rate] nor DP-346's off-schedule test."),
        dict(name="Failed Fee Debits", aggregation="additive",
             expr="count and sum(fee_debit.debit_amount) where fee_debit_status = 'Failed' and debit_date in the period",
             source=("DP-305", "Failed Fee Debits"),
             description="Fee debits that failed to collect, by failure reason and fee type."),
        dict(name="Outstanding Fee Invoice Amount", aggregation="semi_additive",
             expr="sum(fee_invoice.invoice_total) where payment_status in ('Issued', 'Partially Paid', 'Overdue', 'Disputed')",
             time_rule="as of the latest date in the selected range",
             source=("DP-305", "Outstanding Fee Invoice Amount"),
             description="Fee invoices not yet paid, by payment status and invoice age band."),
        dict(name="Performance Fees Invoiced", aggregation="additive",
             expr="sum(fee_invoice.performance_fee_amount) where invoice_date in the period",
             source=("DP-305", "Performance Fees Invoiced"),
             description="Performance fees invoiced to mandates, by hurdle type and high-water mark of the applied schedule.",
             note="Billing currency of the arrangement; no FX conversion."),
        dict(name="Fee Adjustment Amount", aggregation="additive",
             expr="sum(fee_adjustment.adjustment_amount_value), dated by the adjusted invoice's billing period end or the "
                  "adjusted calculation's run billing period end",
             source=("DP-305", "Fee Adjustment Amount"),
             description="Fee adjustments made after billing, by adjustment type."),
        dict(name="Open Billing Disputes", aggregation="semi_additive",
             expr="count and sum(billing_dispute.disputed_amount) where dispute_status not in ('Resolved / Completed', "
                  "'Closed', 'Rejected', 'Canceled')",
             time_rule="as of the latest date in the selected range",
             source=("DP-305", "Open Billing Disputes"),
             description="Billing disputes still open, by dispute reason."),
        dict(name="Active Fee Deduction Authorizations", aggregation="count_distinct",
             expr="count distinct (fee_deduction_authorization.authorized_account, authorizing_agreement) where "
                  "authorization_status = 'Active', authorization_effective_date <= as-of date and authorization_revoked_date "
                  "is blank",
             source=("DP-305", "Active Fee Deduction Authorizations"),
             description="Accounts that authorize fee deduction from their assets, by custody rule basis.",
             note="Read from DP-346's custody-rule fact, which carries the same authorization rows; the disclosure "
                  "delivery count of the spec is DP-346's exception list."),

        # ================================================================================================================
        # DP-346 billing accuracy (acceptance question 8)
        # ================================================================================================================
        dict(name="Fee Runs Tested", aggregation="count_distinct",
             expr="count distinct fee_run.fee_calculation_run_id where run_status in ('Approved', 'Released'), run_type <> "
                  "'Simulation' and run_billing_period_end in the period",
             source=("DP-346", "Fee Runs Tested"),
             description="Fee runs tested for billing accuracy in the period, by run type."),
        dict(name="Failed Fee Runs", aggregation="count_distinct",
             expr="count distinct fee_run.fee_calculation_run_id of [Fee Runs Tested] where fee_reconciliation_status in "
                  "('Break Open', 'Not Reconciled') or abs([Run Control Total Variance]) > 0.01 or (run_status = 'Released' "
                  "and run_approved_by is blank)",
             source=("DP-346", "Failed Fee Runs"),
             description="Acceptance question 8, first half: advisory fee runs that failed reconciliation or were released "
                         "without approval, by run type and reconciliation status."),
        dict(name="Accounts Billed Off Schedule", aggregation="count_distinct",
             expr="count distinct fee_schedule_assignment.billed_account (Account Status Open or closed in the period) of "
                  "fee_billing_test rows with off_schedule_flag = 'Y' in the billing period",
             source=("DP-346", "Accounts Billed Off Schedule"),
             description="Acceptance question 8, second half: accounts billed outside their fee schedule, by fee schedule "
                         "type and cause (version, tier or breakpoint, override, waiver)."),
        dict(name="Billing Variance", aggregation="additive",
             expr="sum(account_fee_calculation.net_fee - fee_billing_test.re_performed_fee) where off_schedule_flag = 'Y'; "
                  "overbilled (positive) and underbilled (negative) shown separately",
             source=("DP-346", "Billing Variance"),
             description="How much off-schedule calculations over- or underbilled against the re-performed fee, in USD."),
        dict(name="Household Breakpoint Not Applied", aggregation="count_distinct",
             expr="count distinct calculations of accounts that are active members of a fee household with more than one "
                  "active member account whose account_fee_calculation.fee_household_assets is blank or equal to "
                  "billable_assets",
             source=("DP-346", "Household Breakpoint Not Applied"),
             description="Calculations that missed the fee household breakpoint they were entitled to."),
        dict(name="Open Calculation Exceptions", aggregation="semi_additive",
             expr="count of fee_calculation_exception rows with exception_resolved_date blank, by fee_exception_type and "
                  "age from exception_raised_date; with the count of 'Billed Outside Schedule' exceptions closed without "
                  "exception_supervisory_review",
             time_rule="as of the latest date in the selected range",
             source=("DP-346", "Open Calculation Exceptions"),
             description="Fee calculation exceptions still open, by type and age, and outside-schedule exceptions closed "
                         "without supervisory review."),
        dict(name="Debits Without Authorization", aggregation="additive",
             expr="count and sum(fee_debit.debit_amount) of debits with fee_debit_status = 'Posted' in the period with no "
                  "fee_deduction_authorization of the debited account active on the debit date covering charged_fee_type, "
                  "or whose debited_account differs from authorized_fee_paying_account",
             source=("DP-346", "Debits Without Authorization"),
             description="Fees deducted from client accounts without a written authorization in force (custody rule).",
             note="The agreement-type test on the 15 Account Agreement is applied by the product; the model counts its result."),
        dict(name="Billing Error Refunds", aggregation="additive",
             expr="count and sum(fee_adjustment.adjustment_amount_value) where adjustment_type in ('Error Correction', "
                  "'Overbilling Refund') and the adjusted calculation's run ended in the period; with the share linked to a "
                  "billing dispute and the count lacking adjustment_approved_by",
             source=("DP-346", "Billing Error Refunds"),
             description="Refunds and corrections of billing errors, how many came from client disputes and how many lack "
                         "approval."),
        dict(name="Disputes Citing Billing Errors", aggregation="additive",
             expr="count and sum(billing_dispute.disputed_amount) of disputes on account calculations with dispute_reason in "
                  "('Asset Value Disagreement', 'Rate Applied Incorrectly', 'Period Error', 'Household Breakpoint Not "
                  "Applied', 'Fee Not Disclosed'); with the share whose calculation has off_schedule_flag = 'Y'",
             source=("DP-346", "Disputes Citing Billing Errors"),
             description="Client disputes that cite a billing error, and how many the off-schedule test also caught."),
        dict(name="Billed to Client Fee Revenue Variance", aggregation="additive",
             expr="sum(account_fee_calculation.net_fee) of the released runs' calculations aligned to a client revenue "
                  "stream and fiscal month through client_revenue.source_calculation_record - [Client Fee Revenue] of the "
                  "same stream and month",
             source=("DP-346", "Billed to Client Fee Revenue Variance (from DP-012)"),
             description="How far billed fees differ from recognized client fee revenue, by fee stream and month; an "
                         "operational tie-out, not a certified number.",
             note="Totals per stream and month only: the source calculation link is multi-valued (GAP-10-026)."),

        # ================================================================================================================
        # DP-349 commissions and account service charges
        # ================================================================================================================
        dict(name="Commissionable Confirmations", aggregation="count_distinct",
             expr="count distinct confirmations in commission_re_performance with confirmed_trade_date in the period",
             source=("DP-349", "Commissionable Confirmations"),
             description="Client trade confirmations that carry a commission or charge, by schedule, capacity and channel."),
        dict(name="Mischarged Confirmations", aggregation="additive",
             expr="count and sum(commission_charged - expected_commission) of confirmations where abs(commission_charged - "
                  "expected_commission) > 0.01",
             source=("DP-349", "Mischarged Confirmations"),
             description="Confirmations charged a different commission than the schedule gives, with the total difference."),
        dict(name="Commission Overcharged", aggregation="additive",
             expr="sum(max(0, commission_re_performance.commission_charged - expected_commission)) over mischarged "
                  "confirmations in the period",
             source=("DP-349", "Commission Overcharged"),
             description="Commission charged above the schedule: the refund exposure, in USD."),
        dict(name="Discount Value Realized", aggregation="additive",
             expr="sum(undiscounted expected charge - commission_re_performance.expected_commission) over commissionable "
                  "confirmations, by discount basis and qualifying service tier",
             source=("DP-349", "Discount Value Realized"),
             description="The value of commission discounts given to clients, by discount basis and service tier.",
             note="The undiscounted charge is re-performed by the product from the rate table; the model sums it."),
        dict(name="Confirmations Without Schedule", aggregation="count_distinct",
             expr="count distinct confirmations with commission_charged > 0 and commission_fee_schedule blank or not the "
                  "schedule assigned to the account on the trade date",
             source=("DP-349", "Confirmations Without Schedule"),
             description="Charged confirmations that cannot be traced to the account's commission schedule."),
        dict(name="Markup Disclosure Gaps", aggregation="count_distinct",
             expr="count distinct confirmations with confirmed_capacity in ('Principal', 'Riskless Principal'), "
                  "markup_disclosure_scope_condition met and (markup_markdown_amount or markup_markdown_percentage blank "
                  "without markup_disclosure_exception, or prevailing_market_price blank)",
             source=("DP-349", "Markup Disclosure Gaps"),
             description="Principal confirmations missing the markup disclosure FINRA Rule 2232 and MSRB Rule G-15 require."),
        dict(name="Average Markup %", aggregation="non_additive",
             expr="avg(commission_re_performance.markup_markdown_percentage) of principal confirmations in the period, "
                  "recomputed from detail rows, with the share above 2%",
             source=("DP-349", "Average Markup %"),
             description="The average markup or markdown on principal trades, by instrument charge category."),
        dict(name="Agency Confirmations Without Remuneration Statement", aggregation="count_distinct",
             expr="count distinct confirmations with confirmed_capacity = 'Agency' of equity and option orders with "
                  "order_flow_remuneration_statement blank",
             source=("DP-349", "Agency Confirmations Without Remuneration Statement"),
             description="Agency confirmations missing the order flow remuneration statement of SEC Rule 10b-10."),
        dict(name="Service Charges Debited", aggregation="additive",
             expr="count and sum(account_service_charge.service_charge_amount) in the period, by service_charge_type",
             source=("DP-349", "Service Charges Debited"),
             description="Account service charges collected (wires, transfers out, paper delivery and others), by type."),
        dict(name="Service Charge Amount Variance", aggregation="additive",
             expr="count and sum(account_service_charge.service_charge_amount - account_service_fee_item.service_fee_amount) "
                  "where they differ, item in force on the debit date",
             source=("DP-349", "Service Charge Amount Variance"),
             description="Service charges debited at a different amount than the fee schedule sets."),

        # ================================================================================================================
        # DP-350 institutional and planning invoicing
        # ================================================================================================================
        dict(name="Active Billing Arrangements", aggregation="count_distinct",
             expr="count distinct billing_arrangement.billing_arrangement_id in force on the as-of date",
             source=("DP-350", "Active Billing Arrangements"),
             description="Institutional and separately managed billing arrangements in force, by schedule type, frequency "
                         "and collection method."),
        dict(name="Invoiced Management Fees", aggregation="additive",
             expr="sum(fee_invoice.management_fee_amount) where invoice_billing_period_end in the period, grouped by "
                  "billing_arrangement.billing_currency",
             source=("DP-350", "Invoiced Management Fees"),
             description="Management fees invoiced to mandates, by mandate and mandate type.",
             note="Required dimension: billing_currency (no FX conversion)."),
        dict(name="Performance Fees Crystallized", aggregation="additive",
             expr="sum(performance_fee_calculation.calculated_performance_fee) where crystallized = 'Y' and "
                  "calculation_period_end in the period",
             source=("DP-350", "Performance Fees Crystallized"),
             description="Mandate performance fees crystallized in the period, by hurdle type and high-water mark."),
        dict(name="Unapproved Performance Fee Calculations", aggregation="count_distinct",
             expr="count distinct performance_fee_calculation rows with calculated_performance_fee > 0 and "
                  "calculation_approved_by blank whose arrangement has an invoice with performance_fee_amount > 0 for the period",
             source=("DP-350", "Unapproved Performance Fee Calculations"),
             description="Performance fees invoiced without an approved calculation."),
        dict(name="Arrangements Without Qualified-Client Determination", aggregation="count_distinct",
             expr="count distinct active billing arrangements whose fee schedule has schedule_performance_fee_rate > 0 and "
                  "whose performance_fee_eligibility_basis is blank or 'Not Applicable', qualified_client_determination is "
                  "blank, or qualified_client_determination_date is after billing_effective_from",
             source=("DP-350", "Arrangements Without Qualified-Client Determination"),
             description="Performance-fee arrangements without the qualified client evidence Rule 205-3 requires."),
        dict(name="Invoice Arithmetic Breaks", aggregation="count_distinct",
             expr="count distinct fee_invoice rows where abs(invoice_total - management_fee_amount - performance_fee_amount) "
                  "> 0.01, or the annualized management fee is below the schedule's minimum_annual_fee",
             source=("DP-350", "Invoice Arithmetic Breaks"),
             description="Invoices whose total does not add up or that fall below the schedule's minimum fee."),
        dict(name="Open Fee Receivables", aggregation="semi_additive",
             expr="sum(fee_receivable.open_receivable_amount) where source_fee_invoice is a fee invoice, by age band of "
                  "receivable_due_date (current, 1-30, 31-90, over 90 days) and receivable_status",
             time_rule="as of the latest date in the selected range",
             source=("DP-350", "Open Fee Receivables"),
             description="Fee invoices still owed in the ledger, by age band; the ledger view beside Outstanding Fee "
                         "Invoice Amount."),
        dict(name="Invoices Past Payment Terms", aggregation="semi_additive",
             expr="count and sum of open amount of invoices with open_receivable_amount > 0 (or, before the receivable "
                  "posts, payment_status in ('Issued', 'Partially Paid', 'Overdue', 'Disputed')) whose invoice_date + "
                  "billing_arrangement.payment_terms_days is before the as-of date",
             time_rule="as of the latest date in the selected range",
             source=("DP-350", "Invoices Past Payment Terms"),
             description="Fee invoices unpaid beyond the arrangement's payment terms."),
        dict(name="Invoice to Receivable Breaks", aggregation="count_distinct",
             expr="count distinct fee invoices dated in the period with fee collection method 'Invoice' that have no "
                  "fee_receivable with source_fee_invoice = invoice_id, or whose original_receivable_amount differs from "
                  "invoice_total by more than 0.01",
             source=("DP-350", "Invoice to Receivable Breaks"),
             description="Invoices not booked, or booked at a different amount, as a ledger receivable."),
        dict(name="Disputed Invoice Share %", aggregation="ratio",
             numerator="sum(billing_dispute.disputed_amount) of disputes whose disputed_invoice is dated in the period",
             denominator="sum(fee_invoice.invoice_total) of invoices dated in the period",
             source=("DP-350", "Disputed Invoice Share %"),
             description="Share of invoiced fees under dispute, by dispute reason."),
        dict(name="MFN True-Up Cost", aggregation="additive",
             expr="sum(fee_adjustment.adjustment_amount_value) where adjustment_type = 'MFN True-Up' and the adjusted "
                  "invoice's arrangement has mfn_clause = 'Y'",
             source=("DP-350", "MFN True-Up Cost"),
             description="Fees given back under most-favored-nation clauses, by mandate and billing period."),
        dict(name="Planning Engagement Invoices", aggregation="additive",
             expr="count and sum(fee_invoice.invoice_total) where the invoice's fee_schedule_assignment has "
                  "billed_advice_engagement populated, by fee_collection_method",
             source=("DP-350", "Planning Engagement Invoices"),
             description="Fees invoiced for financial planning engagements, by collection method.",
             note="The Engagement Type cut needs DP-303's Advice Engagement (SM-22); open decision."),

        # ================================================================================================================
        # DP-497 client revenue yield and pricing
        # ================================================================================================================
        dict(name="Client Revenue by Stream", aggregation="additive",
             expr="sum(client_revenue.recognized_revenue_amount), by client_revenue_stream, revenue_service_offering, "
                  "revenue_channel, revenue_business_line, client_segment_at_period_end and recognizing_legal_entity",
             source=("DP-497", "Client Revenue by Stream"),
             description="All client revenue, fee and non-fee, by stream, offering, channel, business line, segment and entity.",
             note="Fee streams sum to [Client Fee Revenue]; the rest to [Client Transaction and Interest Revenue]."),
        dict(name="Client Revenue Yield (bps)", aggregation="ratio",
             numerator="annualized [Client Revenue by Stream] over all client streams for the selected channels or segments "
                       "x 10,000",
             denominator="[Average Client Assets] (client_assets, Dimension Type Channel or Segment) for the same cut and period",
             source=("DP-497", "Client Revenue Yield (bps)"),
             description="Client revenue earned per dollar of average client assets, in basis points, by channel and segment.",
             note="Revenue Client Segment at Period End is matched to the DP-008 Segment dimension; own-fund revenue is "
                  "never divided by Client Assets."),
        dict(name="Fee Revenue Yield (bps)", aggregation="ratio",
             numerator="annualized [Client Revenue by Stream] of the fee streams (Advisory, Wrap, Planning, Subscription, "
                       "Account Service, Recordkeeping, Trust, OCIO Fee) x 10,000",
             denominator="[Average Client Assets] for the same channel or segment and period",
             source=("DP-497", "Fee Revenue Yield (bps)"),
             description="Client fee revenue per dollar of average client assets, in basis points.",
             note="The yield on Client Assets; the certified [Effective Net Fee Rate] uses billable assets instead."),
        dict(name="Yield Drift (bps)", aggregation="non_additive",
             expr="[Client Revenue Yield (bps)] of the period - that of the same period a year earlier, split into rate "
                  "(yield change at constant mix) and mix (change in stream and segment weights of average client assets)",
             source=("DP-497", "Yield Drift (bps)"),
             description="How the revenue yield moved year on year, and how much of it is pricing versus mix.",
             note="Computed at the cut asked for; the rate and mix parts do not add across cuts."),
        dict(name="Billed Fee Realization %", aggregation="ratio",
             numerator="sum(account_fee_calculation.net_fee) of runs whose billing period falls in the fiscal period",
             denominator="sum(account_fee_calculation.gross_fee) of the same calculations",
             source=("DP-497", "Billed Fee Realization % (from DP-305)"),
             description="Share of the scheduled fee actually billed after discounts, waivers and credits, by offering."),
        dict(name="Revenue by Client Segment Scheme", aggregation="additive",
             expr="[Client Revenue by Stream] regrouped by DP-240 Segment Assignment (one segmentation scheme, segment in "
                  "force at the period end) of the record's 02 household, through the owner Account Party Role and the "
                  "Household Membership in force at the period end",
             source=("DP-497", "Revenue by Client Segment Scheme"),
             description="Client revenue under any segmentation scheme in force, not only the segment stamped on the record.",
             note="Through the many-to-many household joins: pin the role, membership and one scheme."),
        dict(name="Commission Revenue per Confirmation", aggregation="ratio",
             numerator="sum(commission_re_performance.commission_charged) of confirmations with confirmed_trade_date in the period",
             denominator="count distinct confirmations of the same rows",
             source=("DP-497", "Commission Revenue per Confirmation (from DP-301)"),
             description="Average commission charged per client trade, shown against commission revenue recognized.",
             note="Confirmations are read from DP-349's re-performance fact (latest version, cancels excluded); the trade "
                  "book itself is SM-24's (DP-301)."),
        dict(name="Pricing Scenario Revenue Impact", aggregation="additive",
             expr="sum(pricing_scenario_result.projected_revenue_impact) and sum(projected_revenue_under_scenario), by "
                  "pricing scenario, projection year and scenario type",
             source=("DP-497", "Pricing Scenario Revenue Impact"),
             description="The projected revenue effect of a proposed fee change; a projection, labeled as such and never "
                         "certified.",
             note="Summed within one scenario only; scenarios are alternatives and are never added together."),

        # ================================================================================================================
        # DP-498 cost to serve and lifetime value (acceptance question 11); SM-14 references the first three
        # ================================================================================================================
        dict(name="Total Cost to Serve", aggregation="additive",
             expr="sum(cost_to_serve.total_cost_to_serve) for the profitability period, at the one dimension_grain asked for",
             source=("DP-498", "Total Cost to Serve"),
             description="The full cost of serving clients in a segment, service tier, offering or channel: coverage, "
                         "service, platform, custody, money movement and communications.",
             note="Required dimension: cts_dimension_grain; each cut reads only its own records, so grains are never "
                  "added. Household rows only in the restricted household_cost_to_serve table."),
        dict(name="Cost to Serve by Component", aggregation="additive",
             expr="sum of coverage_and_servicing_cost, client_service_cost, platform_technology_cost, clearing_custody_cost, "
                  "money_movement_cost and communications_regulatory_cost, by cut",
             source=("DP-498", "Cost to Serve by Component"),
             description="Cost to serve split into its six components; the components sum to Total Cost to Serve."),
        dict(name="Cost to Serve Rate (bps)", aggregation="ratio",
             numerator="annualized [Total Cost to Serve] for the selected segment, channel or business line x 10,000",
             denominator="[Average Client Assets] (client_assets, Dimension Type Segment, Channel or Business Line) for the "
                         "same cut and period",
             source=("DP-498", "Cost to Serve Rate (bps)"),
             description="What it costs to serve each dollar of client assets, in basis points.",
             note="Service tier and offering cuts have no certified asset base in DP-008 at those grains; the rate is "
                  "published for segment, channel and business line."),
        dict(name="Cost to Serve per Household", aggregation="ratio",
             numerator="annualized [Total Cost to Serve] for the selected segment or channel",
             denominator="[Households] (client_assets, Dimension Type Segment or Channel) at the period end",
             source=("DP-498", "Cost to Serve per Household"),
             description="What it costs to serve one household a year, by client segment and channel.",
             note="DP-008 publishes Households by segment and channel only; no service tier cut (see cannot_answer)."),
        dict(name="Allocated Cost Tie-Out", aggregation="additive",
             expr="[Allocated Cost by Cost-to-Serve Component] of the source allocation run - [Cost to Serve by Component] "
                  "of the same run, per component",
             source=("DP-498", "Allocated Cost Tie-Out (from DP-480)"),
             description="Whether cost to serve accounts for all the cost DP-480 allocated to clients; zero expected."),
        dict(name="Cost Coverage of Certified Expense", aggregation="ratio",
             numerator="([Total Cost to Serve] summed at one grain over the firm + sum(acquisition_cost.allocated_acquisition_cost) "
                       "of the period) x 100",
             denominator="[Certified Operating Expense] of the fiscal period (SM-14, DP-191)",
             source=("DP-498", "Cost Coverage of Certified Expense"),
             description="Share of certified operating expense the cost-to-serve and acquisition views explain; the rest is "
                         "corporate overhead not allocated to clients.",
             note="Firm total only; a reconciling ratio against certified expense, never a second expense number."),
        dict(name="Revenue to Cost to Serve Ratio", aggregation="ratio",
             numerator="sum(client_revenue.recognized_revenue_amount) for the period by client_segment_at_period_end",
             denominator="[Total Cost to Serve] at dimension_grain 'Client Segment' for the same segment",
             source=("DP-498", "Revenue to Cost to Serve Ratio"),
             description="How many dollars of client revenue each dollar of cost to serve brings in, by client segment."),
        dict(name="Acquisition Cost per Funded Household", aggregation="ratio",
             numerator="sum(acquisition_cost.allocated_acquisition_cost)",
             denominator="sum(acquisition_cost.new_households_acquired)",
             source=("DP-498", "Acquisition Cost per Funded Household"),
             description="What it costs to acquire one funded household, by acquisition channel, campaign and cohort month."),
        dict(name="Acquisition Cost Tie-Out to Campaign Spend", aggregation="additive",
             expr="sum(acquisition_cost.allocated_acquisition_cost) of campaign rows of the period - [Campaign Spend] of the "
                  "same campaigns; non-campaign acquisition cost shown separately",
             source=("DP-498", "Acquisition Cost Tie-Out to Campaign Spend"),
             description="Whether acquisition cost charged to campaigns matches what the campaigns spent."),
        dict(name="Average Household Lifetime Value", aggregation="ratio",
             numerator="sum(household_lifetime_value.client_lifetime_value) at the latest estimate date under the model "
                       "version in use",
             denominator="count distinct household_lifetime_value.valued_household of the same rows",
             source=("DP-498", "Average Household Lifetime Value"),
             description="The average expected lifetime value of a household, by acquisition channel, cohort and segment.",
             note="Household estimates enter only as these aggregates (10-household minimum cell); the rows are the "
                  "restricted 'DP-498 Household Economics' view."),
        dict(name="Lifetime Value to Acquisition Cost Ratio", aggregation="non_additive",
             expr="[Average Household Lifetime Value] / [Acquisition Cost per Funded Household] for the same acquisition "
                  "channel and cohort month",
             source=("DP-498", "Lifetime Value to Acquisition Cost Ratio"),
             description="Acceptance question 11, second half: lifetime value earned per dollar of acquisition cost, by "
                         "acquisition channel.",
             note="A ratio of two ratios, computed at the channel and cohort asked for; not re-aggregated."),
        dict(name="Estimates on Unapproved Model Version", aggregation="count_distinct",
             expr="count distinct household_lifetime_value rows whose valuation_model_version is not a DP-212 Model of Model "
                  "Type 'Lifetime Value' with Model Use Status 'Approved for Use'",
             source=("DP-498", "Estimates on Unapproved Model Version"),
             description="Lifetime value estimates produced by a model version not approved for use (CD-294); zero expected."),

        # ================================================================================================================
        # DP-499 profitability
        # ================================================================================================================
        dict(name="Gross Revenue", aggregation="additive",
             expr="sum(profitability.gross_revenue) at the one dimension_grain asked for",
             source=("DP-499", "Gross Revenue"),
             description="Management gross revenue by client segment, offering, channel, business line, product or partner firm.",
             note="An allocated management view, not certified revenue; the tie-out to DP-012 is [Revenue Tie-Out to "
                  "Client Fee Revenue]."),
        dict(name="Revenue Tie-Out to Client Fee Revenue", aggregation="additive",
             expr="[Gross Revenue] at dimension_grain 'Business Line' - (sum(client_revenue.recognized_revenue_amount) + "
                  "sum(fee_revenue.gross_fee_revenue)) for the same fiscal period and business line",
             source=("DP-499", "Revenue Tie-Out to DP-012"),
             description="Whether management revenue agrees with the revenue DP-012 recognized, by business line; zero expected."),
        dict(name="Distribution Payments in Profitability", aggregation="additive",
             expr="sum(profitability.distribution_payments) at the dimension_grain asked for",
             source=("DP-499", "Distribution Payments (from DP-487)"),
             description="Payments to intermediaries charged against revenue in the profitability view.",
             note="At Partner Firm grain tied to DP-487's accruals (SM-27); the accrual itself is SM-27's metric."),
        dict(name="Net Revenue After Distribution Costs", aggregation="additive",
             expr="sum(profitability.net_revenue_after_distribution_costs)",
             source=("DP-499", "Net Revenue After Distribution Costs"),
             description="Gross revenue less distribution payments, by cut."),
        dict(name="Direct Sales & Marketing Cost", aggregation="additive",
             expr="sum(profitability.direct_sales_marketing_cost)",
             source=("DP-499", "Direct Sales & Marketing Cost"),
             description="Sales and marketing cost charged directly to the cut."),
        dict(name="Contribution Margin", aggregation="additive",
             expr="sum(profitability.contribution_margin)",
             source=("DP-499", "Contribution Margin"),
             description="Net revenue after distribution, direct sales and marketing cost, by cut."),
        dict(name="Contribution Margin %", aggregation="ratio",
             numerator="sum(profitability.contribution_margin) x 100",
             denominator="sum(profitability.gross_revenue) of the same rows",
             source=("DP-499", "Contribution Margin"),
             description="Contribution margin as a share of gross revenue.",
             note="The percentage form the Contribution Margin measure publishes beside the amount."),
        dict(name="Allocated Indirect Cost", aggregation="additive",
             expr="sum(profitability.allocated_indirect_cost)",
             source=("DP-499", "Allocated Indirect Cost (from DP-480)"),
             description="Indirect cost allocated to the cut by the final DP-480 allocation run."),
        dict(name="Operating Profit", aggregation="additive",
             expr="sum(profitability.operating_profit), by cut or by management hierarchy node rolled up to the operating "
                  "segment mapping",
             source=("DP-499", "Operating Profit"),
             description="Contribution margin less allocated indirect cost: the management operating profit of the cut."),
        dict(name="Operating Margin %", aggregation="ratio",
             numerator="sum(profitability.operating_profit) x 100",
             denominator="sum(profitability.gross_revenue) of the same rows",
             source=("DP-499", "Operating Profit"),
             description="Operating profit as a share of gross revenue.",
             note="A ratio of sums, never an average of the record's Operating Margin."),
        dict(name="Net Revenue Yield on Client Assets (bps)", aggregation="ratio",
             numerator="annualized [Net Revenue After Distribution Costs] for the selected segment, channel or business line x 10,000",
             denominator="[Average Client Assets] for the same cut and period",
             source=("DP-499", "Net Revenue Yield on Client Assets (bps)"),
             description="Net revenue after distribution per dollar of average client assets, in basis points."),
        dict(name="Offerings and Segments With Negative Contribution", aggregation="non_additive",
             expr="count and [Gross Revenue] of service offering and client segment cuts whose [Contribution Margin] over the "
                  "trailing four quarters is below zero",
             source=("DP-499", "Offerings and Segments With Negative Contribution"),
             description="Offerings and client segments that lose money after direct costs over the last year."),
        dict(name="Advisor Book Profitability", aggregation="additive",
             expr="sum(advisor_book_profitability.advisor_gross_revenue), sum(advisor_contribution_margin) and "
                  "sum(advisor_operating_profit) by profitability_advisor, for active advisors and their business lines",
             source=("DP-499", "Advisor Book Profitability (restricted)"),
             description="Revenue, contribution and operating profit of each advisor's book.",
             note="Released only in the DP-518 'DP-499 Advisor Book' view (allocated compensation cost, CD-344 tier)."),
        dict(name="Household Profitability Distribution", aggregation="non_additive",
             expr="deciles of household_profitability.household_operating_profit within each household_client_segment: "
                  "decile boundaries and household counts only",
             source=("DP-499", "Household Profitability Distribution"),
             description="How operating profit spreads across households in each segment, as deciles.",
             note="Household rows only in the DP-518 'DP-499 Household Profitability' view."),
        dict(name="Operating Profit Tie-Out to Certified Operating Income", aggregation="additive",
             expr="[Operating Profit] at dimension_grain 'Business Line' summed over the firm - [Certified Operating Income] "
                  "of the fiscal period, by reporting_legal_entity",
             source=("DP-499", "Operating Profit Tie-Out to Certified Operating Income (from DP-191)"),
             description="Whether management operating profit agrees with certified operating income; the difference is a "
                         "reconciling item.",
             note="DP-191's value is read through SM-14, never recomputed."),

        # ================================================================================================================
        # DP-503 intercompany charges and transfer pricing
        # ================================================================================================================
        dict(name="Booked Intercompany Charges", aggregation="additive",
             expr="sum(intercompany_charge.charge_amount) whose charge_period is in the fiscal period, by agreement, service "
                  "type, provider and recipient entity",
             source=("DP-503", "Booked Intercompany Charges"),
             description="Charges booked between the firm's legal entities for services, by agreement and entity pair.",
             note="Summing across entities nets to zero at the consolidated level; read by entity pair."),
        dict(name="Charge Basis", aggregation="additive",
             expr="per agreement and period: for cost-based TP methods sum(legal_entity_allocation.le_allocated_amount) "
                  "where le_target_member = the service provider entity; for revenue-based remuneration the provider's "
                  "recognized client revenue (client_revenue by recognizing_legal_entity)",
             source=("DP-503", "Charge Basis"),
             description="The cost or revenue base a transfer price is set on, by agreement and period.",
             note="Reads the restricted 'DP-503 Member-Level Allocation Read'; released to transfer pricing and tax roles."),
        dict(name="Expected Intercompany Charge", aggregation="additive",
             expr="per agreement and period [Charge Basis] x intercompany_agreement.remuneration_rate of the TP policy in "
                  "force, then summed",
             source=("DP-503", "Expected Intercompany Charge"),
             description="What each agreement should have charged under its transfer pricing policy."),
        dict(name="Expected vs Booked Variance", aggregation="additive",
             expr="[Booked Intercompany Charges] - [Expected Intercompany Charge] per agreement and period, and as a "
                  "percentage of the expected charge",
             source=("DP-503", "Expected vs Booked Variance"),
             description="How far booked charges differ from the policy charge."),
        dict(name="Tested Party Return", aggregation="ratio",
             numerator="[Booked Intercompany Charges] of the agreement for the fiscal year",
             denominator="[Charge Basis] of the same agreement and year (result minus 1, x 100, for cost-based methods)",
             source=("DP-503", "Tested Party Return"),
             description="The markup or return the tested party earned, per agreement and fiscal year."),
        dict(name="Charges Outside Arm's Length Range", aggregation="additive",
             expr="count distinct agreements with arms_length_flag = 'N' for the fiscal year and sum of their [Booked "
                  "Intercompany Charges], with the adjustment needed to reach the nearest bound",
             source=("DP-503", "Charges Outside Arm's Length Range"),
             description="Agreements whose return fell outside the arm's length range, and the adjustment needed.",
             note="SM-14 excludes DP-196's copy of this measure and points here."),
        dict(name="Unsettled Intercompany Charges", aggregation="semi_additive",
             expr="sum(intercompany_charge.charge_amount) where settlement_status in ('Pending', 'Invoiced') more than 60 "
                  "days after the end of the charge period, by entity pair",
             time_rule="as of the latest date in the selected range",
             source=("DP-503", "Unsettled Intercompany Charges"),
             description="Intercompany charges not settled 60 days after their period."),
        dict(name="Charges Not Flagged for Elimination", aggregation="additive",
             expr="count and sum(intercompany_charge.charge_amount) of charges between two active consolidated entities "
                  "whose elimination_indicator is not 'Y'",
             source=("DP-503", "Charges Not Flagged for Elimination"),
             description="Charges between consolidated entities that would not be eliminated on consolidation."),
        dict(name="Agreements Without TP Documentation", aggregation="count_distinct",
             expr="count distinct agreements in force in the fiscal year that no tp_documentation with contemporaneous = 'Y' "
                  "lists in covered_intercompany_agreements for that year, or whose tp_documentation_reference is empty",
             source=("DP-503", "Agreements Without TP Documentation"),
             description="Intercompany agreements without contemporaneous transfer pricing documentation."),
        dict(name="Documented Transaction Value Coverage %", aggregation="ratio",
             numerator="sum(tp_documentation.covered_transaction_value) of the fiscal year x 100",
             denominator="[Booked Intercompany Charges] of the covered agreements for the year",
             source=("DP-503", "Documented Transaction Value Coverage %"),
             description="Share of intercompany charges the year's documentation covers, by documented entity."),
        dict(name="Distribution Services Charges", aggregation="additive",
             expr="[Booked Intercompany Charges] of agreements with intercompany_service_type = 'Distribution Services' "
                  "whose service provider holds the entity_distribution_role of principal underwriter in force",
             source=("DP-503", "Distribution Services Charges"),
             description="Charges for distribution services provided by the principal underwriter entity."),
        dict(name="Net Intercompany Position by Entity", aggregation="non_additive",
             expr="per internal legal entity: [Booked Intercompany Charges] as service provider - those as service recipient "
                  "for the fiscal period, beside its recognized client revenue (client_revenue by recognizing_legal_entity)",
             source=("DP-503", "Net Intercompany Position by Entity"),
             description="Each legal entity's net intercompany income or cost, beside the client revenue it recognizes.",
             note="Shown per entity; the firm total is zero by construction."),

        # ================================================================================================================
        # DP-480 cost allocation and management hierarchies
        # ================================================================================================================
        dict(name="Pool Source Cost", aggregation="additive",
             expr="per cost pool and run: [Certified Operating Expense] of the pool's contributing_cost_centers for the run period",
             source=("DP-480", "Pool Source Cost"),
             description="The certified expense each cost pool starts from, before allocation.",
             note="A cost center contributes to one pool only, so pools do not double count."),
        dict(name="Pool-to-Pool Transfers", aggregation="additive",
             expr="sum(allocation_result.allocated_amount) where target_dimension_member is a cost pool (step-down and "
                  "reciprocal methods)",
             source=("DP-480", "Pool-to-Pool Transfers"),
             description="Cost moved between pools before reaching its final targets."),
        dict(name="Allocated Cost", aggregation="additive",
             expr="sum(allocation_result.allocated_amount) to final targets, excluding the rows of [Pool-to-Pool Transfers], "
                  "by run, rule, target dimension and source cost pool",
             source=("DP-480", "Allocated Cost"),
             description="Cost allocated to its final targets, counting each step-down chain once.",
             note="Household, account, client and advisor targets are summed over members for every role but the "
                  "allocation owner (CW-243)."),
        dict(name="Unallocated Residual Amount", aggregation="additive",
             expr="sum(allocation_run.unallocated_residual) of the final run of each run period",
             source=("DP-480", "Unallocated Residual Amount"),
             description="Cost the allocation run could not assign to a target, by period."),
        dict(name="Allocation Completeness %", aggregation="ratio",
             numerator="[Allocated Cost] x 100",
             denominator="[Allocated Cost] + [Unallocated Residual Amount] of the same run",
             source=("DP-480", "Allocation Completeness %"),
             description="Share of pooled cost the run allocated to final targets."),
        dict(name="Allocation to Ledger Difference", aggregation="additive",
             expr="([Allocated Cost] + [Unallocated Residual Amount]) of a final run - [Pool Source Cost] of the pools that "
                  "receive ledger cost, for the run period",
             source=("DP-480", "Allocation to Ledger Difference"),
             description="Whether the allocation chain accounts for all certified expense it started from; zero expected."),
        dict(name="Allocated Cost by Cost-to-Serve Component", aggregation="additive",
             expr="[Allocated Cost] grouped by cost_pool.cost_to_serve_component and cost_pool_type of the rule's source "
                  "pool and by allocation_rule.target_dimension",
             source=("DP-480", "Allocated Cost by Cost-to-Serve Component"),
             description="Allocated cost by cost-to-serve component and target dimension: the input to cost to serve."),
        dict(name="Active Allocation Rules", aggregation="count_distinct",
             expr="count distinct allocation_rule.allocation_rule_id with rule_effective_from <= as-of date and "
                  "rule_effective_to blank or later, by target dimension and allocation method type",
             source=("DP-480", "Active Allocation Rules"),
             description="Allocation rules in force, by target dimension and method."),
        dict(name="Active Hierarchy Nodes", aggregation="count_distinct",
             expr="count distinct management_hierarchy_node.node_id of hierarchy versions with hierarchy_status = 'Active' "
                  "effective on the as-of date, by hierarchy_type",
             source=("DP-480", "Active Hierarchy Nodes"),
             description="Nodes of the management hierarchies in force, by hierarchy type."),
        dict(name="Restatements in Period", aggregation="count_distinct",
             expr="count distinct hierarchy_restatement.restatement_id whose restated_from_period falls in the reporting year",
             source=("DP-480", "Restatements in Period"),
             description="Management hierarchy restatements of the year, by method and trigger."),

        # ================================================================================================================
        # DP-242 Fund 360
        # ================================================================================================================
        dict(name="Watch List Share Classes", aggregation="count_distinct",
             expr="count distinct fund_360.fund_360_share_class with watch_list_flag = 'Y' at the latest month-end",
             source=("DP-242", "Watch List Flag"),
             description="Active share classes on the product watch list, by fund and lifecycle status."),
        dict(name="Fund Certified Revenue Tie-Out", aggregation="additive",
             expr="per fund and fiscal period: [Net Fee Revenue] of the fund's share classes (fee_revenue) - [Certified "
                  "Revenue] on actual balances of revenue GL accounts whose product segment value (DP-190 Cost Center, "
                  "Represented Product) represents the fund",
             source=("DP-242", "Certified Revenue Tie-Out (from DP-191)"),
             description="Whether a fund's fee revenue agrees with certified revenue booked to it; a difference is a "
                         "reconciling item.",
             note="Funds without a product segment value cannot be tied (DP-242 taxonomy gap)."),

        # ================================================================================================================
        # Certified and other metrics owned elsewhere
        # ================================================================================================================
        dict(name="Average Client Assets", ref="SM-20/Average Client Assets",
             note="Read from client_assets at the dimension type of the cut; the denominator of the yields and of Cost to "
                  "Serve Rate (bps)."),
        dict(name="Households", ref="SM-20/Households",
             note="Read from client_assets at Dimension Type Segment or Channel; the denominator of Cost to Serve per Household."),
        dict(name="Client Assets", ref="SM-20/Client Assets",
             note="Shown beside revenue; never a denominator of the certified Effective Net Fee Rate."),
        dict(name="Net Flows", ref="SM-20/Net Flows", note="Fund 360: trailing 12-month net flows of the watch list rule."),
        dict(name="Client Organic Growth Rate", ref="SM-20/Client Organic Growth Rate", note="Fund 360."),
        dict(name="Certified Operating Expense", ref="SM-14/Certified Operating Expense",
             note="Denominator of Cost Coverage of Certified Expense and the source of Pool Source Cost."),
        dict(name="Certified Operating Income", ref="SM-14/Certified Operating Income",
             note="The certified side of Operating Profit Tie-Out to Certified Operating Income."),
        dict(name="Certified Revenue", ref="SM-14/Certified Revenue",
             note="The certified side of Fund Certified Revenue Tie-Out."),
        dict(name="Class Net Assets", ref="SM-11/Class Net Assets", note="Fund 360, by share class (CD-330)."),
        dict(name="NAV per Share", ref="SM-11/NAV per Share", note="Fund 360."),
        dict(name="Fund Total Net Assets", ref="SM-11/Fund Total Net Assets", note="Fund 360, fund rows."),
        dict(name="Net and Gross Expense Ratio (Trailing)", ref="SM-11/Net and Gross Expense Ratio (Trailing)",
             note="Fund 360, beside the prospectus ratio of the DP-004 Cost Disclosure."),
        dict(name="Official Return", ref="SM-08/Official Return", note="Fund 360: 1, 3, 5 years and since inception."),
        dict(name="Benchmark Return", ref="SM-08/Benchmark Return", note="Fund 360: the primary benchmark."),
        dict(name="Campaign Spend", ref="SM-25/Campaign Spend",
             note="The campaign side of Acquisition Cost Tie-Out to Campaign Spend (DP-410)."),
        dict(name="Funded Households Acquired", ref="SM-25/Funded Households Acquired",
             note="The funnel count beside New Households Acquired of the acquisition cost records."),
    ],

    excluded=[
        # ---- DP-012 -----------------------------------------------------------------------------------------------------
        ("DP-012", "Fee Revenue as Presented",
         "A presentation view for the revenue accounting team: client revenue records carry no revenue contract (GAP-10-004), "
         "so principal-or-agent presentation cannot be sliced beside client revenue; the product publishes it per stream."),
        ("DP-012", "Billed to Recognized Variance",
         "A per-row tie-out of recognized to billed amounts for revenue accounting; across rows it is published as [Billed to "
         "Client Fee Revenue Variance] from DP-346."),
        ("DP-012", "Client Fee Reductions Billed (from DP-305)",
         "DP-305's reductions read by name; published once as [Fee Reductions Applied]."),
        ("DP-012", "Fee Basis Variance",
         "A per share class check of the fund fee basis against DP-165's NAV of record (Class Net Assets is SM-11's); the "
         "product publishes the exceptions for fund revenue accounting."),
        ("DP-012", "Ledger Tie-Out Variance",
         "The ledger tie-out of recognized revenue to GL postings belongs to DP-598 and to SM-14's certified revenue; the "
         "product publishes the per-entity breaks."),
        ("DP-012", "Reconciliation Control Completion %",
         "Close control evidence for the revenue control owner; Control has no legal entity or reconciled scope "
         "(GAP-10-003), so it cannot be sliced beside revenue."),
        # ---- DP-305 -----------------------------------------------------------------------------------------------------
        ("DP-305", "Active Enrollments Without Fee Schedule Assignment",
         "A master-data control for billing operations; the product publishes the enrollments as an exception list."),
        ("DP-305", "Assignments Off Offering Schedule",
         "A master-data check of assignments against the offering's linked schedule; billing outside schedule is answered "
         "by DP-346's [Accounts Billed Off Schedule], which re-performs the billed rate."),
        ("DP-305", "Active Rate Overrides",
         "A pricing master-data count for billing operations; overrides that affect billing accuracy are tested by DP-346."),
        # ---- DP-346 -----------------------------------------------------------------------------------------------------
        ("DP-346", "Run Control Total Variance (from DP-305)",
         "DP-305's measure read by name; published once as [Run Control Total Variance]."),
        ("DP-346", "Billable Asset Variance %",
         "A per-calculation test against 49 Client Holdings (SM-24's book, DP-300); the product lists the calculations "
         "beyond 0.5%."),
        ("DP-346", "Own-Fund Holdings Billed",
         "A per-calculation test against own-fund holdings in 49 (SM-24's book); the product lists the double charges."),
        ("DP-346", "Unapproved Overrides and Waivers Applied",
         "Per-calculation control evidence for the billing supervisor; the product publishes the exception list."),
        ("DP-346", "Debit to Calculation Breaks",
         "A per-debit test against 49 Client Account Activity postings (SM-24's book); the product lists the breaks."),
        ("DP-346", "Custody Rule Evidence Gaps",
         "Custody-rule evidence per account and quarter against 13 statements and 38 surprise examinations; the product "
         "publishes it as a regulatory exception list for compliance."),
        ("DP-346", "Fee Changes Without Advance Notice",
         "A per-calculation comparison with the prior period's schedule and the 13 disclosure deliveries; the product "
         "publishes the exception list."),
        # ---- DP-349 -----------------------------------------------------------------------------------------------------
        ("DP-349", "Service Charges Without Triggering Event",
         "A per-debit test against DP-302 money movements and DP-300 transfers (SM-24's books); the product lists the exceptions."),
        ("DP-349", "Missed Service Charges",
         "A test of settled wires and transfers (SM-24's books) without a debit; the product lists the foregone charges."),
        ("DP-349", "Waivable Charges Not Waived",
         "A per-debit test through the owner's service tier assignment (DP-240); the product lists the exceptions."),
        ("DP-349", "Paper Fees on E-Delivery Accounts",
         "A per-debit test against DP-382 delivery elections (SM-25's); the product lists the exceptions."),
        # ---- DP-350 -----------------------------------------------------------------------------------------------------
        ("DP-350", "Performance Fee Re-Performance Variance",
         "A per-calculation re-performance against DP-145 returns and DP-142 portfolio values; the product lists the variances."),
        ("DP-350", "Invoice Billable Assets Variance %",
         "A per-invoice test against the 18 portfolio valuation (DP-142); the product lists invoices beyond 0.5%."),
        # ---- DP-497 -----------------------------------------------------------------------------------------------------
        ("DP-497", "Gross Fee Revenue (from DP-012)", "Certified; published once as [Gross Fee Revenue]."),
        ("DP-497", "Net Fee Revenue (from DP-012)", "Certified; published once as [Net Fee Revenue]."),
        ("DP-497", "Effective Net Fee Rate (from DP-012)", "Certified; published once as [Effective Net Fee Rate]."),
        ("DP-497", "Average Client Assets (from DP-008)", "Certified by SM-20; referenced as SM-20/Average Client Assets."),
        ("DP-497", "Own-Fund Management Fee Revenue (from DP-012)",
         "DP-012's fund revenue read by name; published as [Net Fee Revenue] on fee_revenue rows and [Waiver Cost]."),
        ("DP-497", "Fee Reductions by Type (from DP-305)",
         "DP-305's reductions and waivers read by name; published as [Fee Reductions Applied] and [Active Fee Waivers]."),
        ("DP-497", "Billed Effective Annual Rate (from DP-305)",
         "DP-305's billed rate read by name; published as [Average Effective Annual Rate]."),
        ("DP-497", "Fully Paid Lending Revenue Check (from DP-300)",
         "A tie-out of the DP-300 loan book (SM-24's) to recognized lending revenue; empty when the lending lever is off."),
        ("DP-497", "Cash Program Net Spread (from DP-012)",
         "DP-012's cash program economics read by name; published as [Cash Program Revenue] with its net spread and "
         "balance columns."),
        ("DP-497", "Scenario Affected Assets Share %",
         "A single-scenario figure reviewed one proposal at a time; pricing scenarios are alternatives, not rows to compare "
         "across."),
        # ---- DP-498 -----------------------------------------------------------------------------------------------------
        ("DP-498", "Average Client Assets (from DP-008)", "Certified by SM-20; referenced as SM-20/Average Client Assets."),
        ("DP-498", "Households (from DP-008)", "Certified by SM-20; referenced as SM-20/Households."),
        ("DP-498", "Certified Operating Expense (from DP-191)",
         "Certified by SM-14; referenced as SM-14/Certified Operating Expense."),
        ("DP-498", "Service Requests per Household (from DP-381)",
         "Service requests are SM-25's (DP-381); the household roll-up needs the account-to-household path at period end "
         "and is asked in SM-25."),
        ("DP-498", "Campaign Spend (from DP-410)", "SM-25's campaign measure; referenced as SM-25/Campaign Spend."),
        ("DP-498", "Funded Accounts by Original Campaign (from DP-392)",
         "SM-25's funnel measure (DP-392); not restated here."),
        ("DP-498", "Funded Households by Acquisition Cohort (from DP-492)",
         "The funded household funnel count is referenced as SM-25/Funded Households Acquired; DP-492's cohort count is "
         "SM-20's."),
        ("DP-498", "Twelve-Month NNA per Acquired Household (from DP-492)",
         "DP-492's measure (SM-20), built on certified Net New Assets attribution; not restated here."),
        # ---- DP-499 -----------------------------------------------------------------------------------------------------
        ("DP-499", "Cost to Serve (from DP-498)", "DP-498's cost to serve read by name; published once as [Total Cost to Serve]."),
        ("DP-499", "Average Client Assets (from DP-008)", "Certified by SM-20; referenced as SM-20/Average Client Assets."),
        ("DP-499", "Partner Firm Profitability",
         "A ranked view of [Net Revenue After Distribution Costs], [Operating Profit] and [Distribution Payments in "
         "Profitability] at dimension_grain 'Partner Firm'; no separate number."),
        ("DP-499", "Measure Formula Conformance",
         "A governance control on the profitability measure formulas for the profitability owner; the product publishes "
         "the exceptions."),
        # ---- DP-503 -----------------------------------------------------------------------------------------------------
        ("DP-503", "Ledger Booking Tie-Out (from DP-191)",
         "A per-charge tie-out to DP-191 journals (SM-14's ledger); the product publishes the breaks."),
        # ---- DP-480 -----------------------------------------------------------------------------------------------------
        ("DP-480", "Certified Operating Expense by Cost Center (from DP-191)",
         "Certified by SM-14; referenced as SM-14/Certified Operating Expense, sliced by DP-190 Cost Center."),
        ("DP-480", "Driver Share Variance",
         "A per-rule allocation data-quality control for the allocation owner; the product lists rules whose shares do not "
         "sum to 100."),
        ("DP-480", "Driver Unit Cost",
         "A per-driver rate (capacity cost rate x unit time); it does not aggregate across drivers."),
        ("DP-480", "Rules Without Driver", "An allocation master-data control; the product lists the rules."),
        ("DP-480", "Superseded Runs", "Run history for the allocation owner; every table pins the final run."),
        ("DP-480", "Orphan Hierarchy Nodes", "A hierarchy data-quality control; the product lists the nodes."),
        ("DP-480", "Operating Segment Mapping Coverage %", "A hierarchy data-quality control for the hierarchy owner."),
        ("DP-480", "Account Mapping Coverage %", "A ledger mapping data-quality control for the allocation owner."),
        # ---- DP-242 -----------------------------------------------------------------------------------------------------
        ("DP-242", "Projected vs Realized at Year 3 (from DP-105)", "DP-105's measure, published by SM-30."),
        ("DP-242", "Open Product Changes (from DP-106, DP-108)", "DP-106 and DP-108 measures, published by SM-30."),
        ("DP-242", "Launch Readiness (from DP-107)", "DP-107's measure, published by SM-30."),
        ("DP-242", "Latest Review Outcome (from DP-109)", "DP-109's measure, published by SM-30."),
        ("DP-242", "Net Assets and NAV (from DP-165)",
         "Certified by SM-11 (CD-330); referenced as SM-11/Class Net Assets, NAV per Share and Fund Total Net Assets."),
        ("DP-242", "Expense Ratios (from DP-165)",
         "Certified by SM-11; referenced as SM-11/Net and Gross Expense Ratio (Trailing)."),
        ("DP-242", "Flows and Client Assets (from DP-008)",
         "Certified by SM-20; referenced as SM-20/Net Flows, Client Assets, Average Client Assets and Client Organic Growth Rate."),
        ("DP-242", "Official Returns (from DP-145)", "Certified by SM-08; referenced as SM-08/Official Return and Benchmark Return."),
        ("DP-242", "Fee Revenue (from DP-012)",
         "Certified here; published as [Gross Fee Revenue], [Net Fee Revenue], [Fund Effective Net Fee Rate] and [Waiver "
         "Cost] by share class."),
        ("DP-242", "Product P&L (from DP-499)",
         "Published from DP-499 at dimension_grain 'Product / Share Class' as [Gross Revenue], [Contribution Margin], "
         "[Operating Profit] and their margins."),
        ("DP-242", "Board Approval Status (from DP-182)", "DP-182's measure, published by SM-11 (fund boards)."),
    ],

    access=dict(
        classification="Confidential - Personal Data (client revenue, billing, household and advisor economics); DP-480, "
                       "DP-497, DP-503 and DP-242 aggregates are Confidential",
        # Restricted views registered in DP-518 (CW-243, CD-344): 'DP-498 Household Economics', 'DP-499 Advisor Book',
        # 'DP-499 Household Profitability' and 'DP-503 Member-Level Allocation Read'. A role sees a restricted table only
        # under an Active 21 Data Contract naming its consumer org unit (DP-518 Named Restricted Views Registered).
        roles=[
            dict(role="client_revenue_finance",
                 rows="all revenue, billing, cost-to-serve, profitability, allocation and intercompany rows at the published "
                      "cuts; account and fee household revenue rows; no rows of the restricted tables",
                 columns="all except approver keys and the restricted member columns",
                 hidden=APPROVER_KEYS + RESTRICTED_COLUMNS),
            dict(role="pricing_billing_operations",
                 rows="fee schedules, assignments, fee households, runs, calculations, billing tests, debits, invoices, "
                      "adjustments, disputes, authorizations, commission and service charge rows; revenue at published cuts only",
                 columns="all billing columns including account keys and approvers; no restricted member columns",
                 hidden=["revenue_account_household", "source_calculation_record"] + RESTRICTED_COLUMNS),
            dict(role="billing_supervision_compliance",
                 rows="fee runs, billing tests, calculation exceptions, debits, authorizations, disputes, commission "
                      "re-performance and markup disclosure rows (acceptance question 8 and custody-rule evidence)",
                 columns="all billing control columns; no revenue, cost or profitability member columns",
                 hidden=["revenue_account_household", "source_calculation_record"] + RESTRICTED_COLUMNS),
            dict(role="household_economics_view",       # DP-518 'DP-498 Household Economics'
                 rows="household_cost_to_serve and household_lifetime_value rows, plus every published cut",
                 columns="household keys, segment, tier and acquisition channel; no account, advisor or approver keys",
                 hidden=[c for c in CLIENT_KEYS if c not in ("anchor_client_household",)] + APPROVER_KEYS
                        + ["profitability_advisor", "profitability_client_account", "target_dimension_member"]),
            dict(role="advisor_book_view",              # DP-518 'DP-499 Advisor Book'
                 rows="advisor_book_profitability rows of the advisors the viewer manages or supervises, plus every "
                      "published cut",
                 columns="advisor key and the advisor's business lines and channels; no client or household keys",
                 hidden=CLIENT_KEYS + APPROVER_KEYS + ["served_party", "served_client_account", "valued_household",
                                                       "profitability_client_account", "target_dimension_member"]),
            dict(role="household_profitability_view",   # DP-518 'DP-499 Household Profitability'
                 rows="household_profitability rows, plus every published cut",
                 columns="household or account key and segment; no advisor or approver keys",
                 hidden=APPROVER_KEYS + ["profitability_advisor", "target_dimension_member", "valued_household"]),
            dict(role="transfer_pricing_tax",           # DP-518 'DP-503 Member-Level Allocation Read'
                 rows="intercompany charges, agreements, TP documentation, legal_entity_allocation and allocation results "
                      "with Target Dimension Legal Entity; client revenue summed by recognizing legal entity",
                 columns="legal entity members; no client, household or advisor keys",
                 hidden=CLIENT_KEYS + APPROVER_KEYS + ["served_party", "served_client_account", "valued_household",
                                                       "profitability_advisor", "profitability_client_account",
                                                       "target_dimension_member"]),
            dict(role="allocation_owner",
                 rows="allocation pools, rules, runs, results (members included) and management hierarchies",
                 columns="all allocation columns; client, household and advisor members of allocation results only",
                 hidden=CLIENT_KEYS + APPROVER_KEYS + ["served_party", "served_client_account", "valued_household",
                                                       "profitability_advisor", "profitability_client_account"]),
            dict(role="broad_internal",                 # FP&A, product, channel, marketing leadership and executives
                 rows="published cuts only: revenue by offering, channel, business line, segment, stream and share class; "
                      "billing counts and totals by schedule type; cost to serve, lifetime value and profitability "
                      "aggregates with the 10-household minimum cell; no restricted table rows and no member-level "
                      "allocation rows",
                 columns="aggregates only",
                 hidden=CLIENT_KEYS + APPROVER_KEYS + RESTRICTED_COLUMNS
                        + ["invoice_id", "fee_debit_id", "fee_waiver_id", "fee_adjustment_id", "billing_dispute_id",
                           "fee_schedule_assignment_id", "billed_mandate", "receivable_document_number",
                           "schedule_performance_fee_rate", "economics_sweep_program_key", "identified_customer"]),
        ]),

    verified_questions=[
        dict(question="Which advisory fee runs failed reconciliation this quarter, and which accounts were billed outside "
                      "their schedule? (acceptance question 8)",
             answer="[Failed Fee Runs] by fee_run.run_type and fee_reconciliation_status for runs with run_billing_period_end "
                    "in the quarter (run_type <> 'Simulation', run_status Approved or Released), listing "
                    "fee_calculation_run_id with [Run Control Total Variance]; then [Accounts Billed Off Schedule] from "
                    "fee_billing_test (off_schedule_flag = 'Y') joined 1:1 to account_fee_calculation and through "
                    "fee_schedule_assignment.billed_account, by fee_schedule.fee_schedule_type, with [Billing Variance]. "
                    "Account lists for the billing roles only.",
             sql="select r.run_type, r.fee_reconciliation_status, count(distinct r.fee_calculation_run_id) as failed_runs "
                 "from dp_305.fee_run r where r.run_status in ('Approved','Released') and r.run_type <> 'Simulation' "
                 "and r.run_billing_period_end between :quarter_start and :quarter_end "
                 "and (r.fee_reconciliation_status in ('Break Open','Not Reconciled') or (r.run_status = 'Released' and "
                 "r.run_approved_by is null) or abs(r.run_net_fee_total - (select sum(c.net_fee) from "
                 "dp_305.account_fee_calculation c where c.calculation_run = r.fee_calculation_run_id)) > 0.01) "
                 "group by r.run_type, r.fee_reconciliation_status"),
        dict(question="What does it cost to serve each client segment, and what is lifetime value against acquisition cost by "
                      "acquisition channel? (acceptance question 11)",
             answer="[Total Cost to Serve], [Cost to Serve Rate (bps)] (over [Average Client Assets] from client_assets at "
                    "Dimension Type Segment) and [Cost to Serve per Household] (over [Households]) from cost_to_serve with "
                    "cts_dimension_grain = 'Client Segment' for the latest final run; then [Average Household Lifetime "
                    "Value], [Acquisition Cost per Funded Household] and [Lifetime Value to Acquisition Cost Ratio] by "
                    "household_acquisition_channel and acquisition_cost.acquisition_channel for the same cohort months, as "
                    "aggregates with the 10-household minimum cell."),
        dict(question="How have gross and net fee revenue and the effective net fee rate moved by offering over the last "
                      "four quarters?",
             answer="[Gross Fee Revenue], [Net Fee Revenue] and [Effective Net Fee Rate] by client_revenue."
                    "revenue_service_offering and fiscal quarter (months rolled up through DP-013 Fiscal Period), with "
                    "own-fund rows from fee_revenue under their share class; final data basis where it exists."),
        dict(question="What is the client revenue yield by channel this year, and how much of the change is price versus mix?",
             answer="[Client Revenue Yield (bps)] by client_revenue.revenue_channel over [Average Client Assets] from "
                    "client_assets (Dimension Type Channel, locked monthly snapshots), with [Yield Drift (bps)] against the "
                    "same months a year earlier."),
        dict(question="Which service offerings and client segments have negative contribution over the last four quarters?",
             answer="[Offerings and Segments With Negative Contribution] from profitability at dimension_grain 'Service "
                    "Offering' and then 'Client Segment' (actual version, final run, current hierarchy), listing "
                    "[Contribution Margin], [Contribution Margin %] and [Operating Profit]."),
        dict(question="Which intercompany agreements were outside the arm's length range last fiscal year?",
             answer="[Charges Outside Arm's Length Range] by intercompany_agreement.intercompany_agreement_id, "
                    "service_provider_entity and service_recipient_entity, with [Tested Party Return] against the range "
                    "bounds; transfer pricing and tax roles only for the charge basis."),
    ],

    cannot_answer=[
        dict(question="What is the cost to serve per household by service tier?",
             why="DP-008 publishes Households at Dimension Type Segment and Channel only, so there is no certified household "
                 "count for a service tier denominator (DP-498 taxonomy gap).", gap=""),
        dict(question="How much client fee revenue is presented gross versus net of a third-party manager's share?",
             why="Client revenue records carry no revenue contract (GAP-10-004) and no attribute holds the pass-through "
                 "amount of an agent client stream (DP-012 taxonomy gap).", gap="GAP-10-004"),
        dict(question="Which billed amount does each recognized client revenue row come from, account by account?",
             why="Source Calculation Record is multi-valued and spans several 47 record types without an amount split, so "
                 "the billed-to-recognized tie-out holds only as totals per stream and month.", gap="GAP-10-026"),
        dict(question="What markup does each intercompany charge carry on the cost it recovers?",
             why="Intercompany Charge holds no charge basis, markup or allocation run (GAP-10-017); the expected charge is "
                 "rebuilt per agreement and period from the allocation results.", gap="GAP-10-017"),
        dict(question="Which program bank earns the most on swept cash for each sweep program, beside its FDIC coverage and "
                      "deposit caps?",
             why="Program Bank and its participation and coverage are SM-24's (DP-431), not yet a shared dimension; cash "
                 "program revenue here carries the program bank as its own column only.", gap=""),
    ],

    open_decisions=[
        "Certified revenue slicing (CW-204): Gross and Net Fee Revenue add client revenue records (offering, channel, "
        "business line) to own-fund fee revenue records (share class or mandate only). Confirm that fund rows show under "
        "their share class with offering, channel and business line blank, or have DP-012 publish a channel and business "
        "line on the Fee Revenue Record so the certified total slices completely.",
        "Client Revenue Record has no data basis attribute: the product grain says closed periods are final and estimated "
        "versions are kept until superseded, but the semantic layer cannot pin one basis. Add Revenue Data Basis to 10 "
        "Client Revenue Record (DP-012) or confirm only final rows are published.",
        "Effective Net Fee Rate denominator: the average Billable Assets is reached through Source Calculation Record, "
        "which is multi-valued and multi-type (GAP-10-026). Confirm DP-012 publishes the denominator per record so the "
        "certified rate does not depend on a many-to-many alignment at query time.",
        "Program Bank (DP-497 cash program cut): Economics Program Bank is an own column of cash_program_economics. When "
        "SM-00 publishes SM-24's Program Bank (DP-431), join it as a shared dimension and drop the own column.",
        "Restricted views: DP-518 evidences the four views by Active Data Contracts naming a consumer org unit but has no "
        "object for row entitlement (DP-518 taxonomy gap). The roles household_economics_view, advisor_book_view, "
        "household_profitability_view and transfer_pricing_tax stand for those contracts; the data office confirms the org "
        "units and who may see advisor book rows (the advisor's own manager or supervision only).",
        "Profitability and cost-to-serve grains: cost_to_serve and profitability require one dimension_grain per query and "
        "default to Client Segment and Business Line. Confirm the tool can enforce a required filter, or publish one table "
        "per grain.",
        "Cost to Serve Rate (bps) at service tier and offering grains has no certified asset base (DP-008 has no service "
        "tier dimension, and offering rows are Dimension Type Service Offering only if SM-20 publishes them). Confirm with "
        "SM-20 which DP-008 dimension types it certifies for Average Client Assets and Households.",
        "SM-25 references: Campaign Spend (DP-410) and Funded Households Acquired (DP-392) are referenced from SM-25 by "
        "lead ruling. DP-498's own measure 'Funded Households by Acquisition Cohort (from DP-492)' reads DP-492's cohort "
        "count (SM-20), not DP-392's first-touch count; confirm with the DP-498 owner that the SM-25 funnel count is the "
        "one shown beside New Households Acquired, or have SM-20 define the DP-492 cohort count for reference.",
        "Planning Engagement Invoices by Engagement Type needs DP-303 Advice Engagement (SM-22). Either SM-00 publishes "
        "Advice Engagement as a shared dimension or the cut stays with SM-22.",
        "Distribution Payments in Profitability is named so to stay apart from SM-27's distribution payment accruals "
        "(DP-487); confirm the name with the SM-27 owner.",
        "DP-346 Active Fee Deduction Authorizations is read from DP-346's custody-rule fact; the DP-305 spec counts the same "
        "authorizations. Confirm the two products keep identical rows or point DP-346's fact at DP-305 explicitly.",
        "DP-497 Commission Revenue per Confirmation reads confirmations from DP-349's re-performance fact rather than "
        "DP-301 (SM-24). Confirm DP-349's latest-version filter matches DP-301's confirmation count.",
    ],
)
