"""SM-29 Retail Conduct & Supervision: principal review, disclosure delivery, sales practice surveillance, branch
inspections, complaints, registrations and licensing, incentive governance, communications surveillance and the retail
conduct risk indicators, across offices, principals, advisors and months. See CONTRACT.md.

WP2 (CW-209; lead ruling at the WP0 integration): the retail conduct products get their own model rather than extending
SM-16. Reads Client Assets and Households from SM-20, the best-interest and PTE 2020-02 evidence counts from SM-22 and the
published money movement holds from SM-24; special-category data reaches it only as aggregates (CD-344)."""

# ---- Shared filter texts ------------------------------------------------------------------------------------------
_ASOF = "as of one date (default the latest load); never summed over dates"
_MONTH_END = "last month-end in the selected range; never summed over months"
_MIN10 = ("Minimum cell 10: a count by advisor, principal or office is shown only where it is 10 or more; smaller cells "
          "are suppressed, not rounded (CD-344; the DP-404 and DP-414 drafting rule applied to every advisor or office slice).")
_IN_FORCE = "{p}effective_from <= :as_of and ({p}effective_to is null or {p}effective_to > :as_of)"
# DP-008 rows exist at many dimension types, period types and snapshots: the advisor slice of the certified client-asset
# family is pinned to Dimension Type Advisor, monthly periods and the locked (Final or Restated) snapshot.
_DP008_ADVISOR = ["dimension_type = 'Advisor'", "period_type = 'MONTH'",
                  "snapshot in (select snapshot_id from dp_008.snapshot where snapshot_status = 'Locked')"]

# ---- Column groups for the access rules ---------------------------------------------------------------------------
# Client and account keys on conduct rows (identity tier): visible to retail conduct compliance for drill and
# re-delivery, never to broad roles.
_CLIENT_KEYS = ["reviewed_account", "reviewed_recommendation", "reviewed_client_order", "reviewed_account_feature",
                "checked_account", "checked_retail_investor", "account_delivery_evidence", "client_level_delivery_evidence",
                "communication_delivery_evidence", "fee_disclosure_evidence", "disclosure_account", "recipient_account",
                "fee_disclosure_recipient", "fee_disclosure_account", "alert_account", "triggering_recommendation",
                "triggering_transaction", "client_remediation", "complainant", "complaint_account",
                "intake_service_request", "related_recommendation", "interaction_account", "linked_service_request",
                "complaint_referral", "recipient_individual", "recipient_firm"]
# Named or keyed employees (employee performance data): visible to supervision for the people they supervise.
_PEOPLE = ["supervised_person", "assigned_supervisor", "designated_principal", "reviewing_principal",
           "supervised_representative", "alerted_representative", "action_subject_representative", "control_tester",
           "inspector", "action_owner", "plan_supervised_representative", "heightened_supervisor", "attester",
           "associated_person_named", "submitted_by", "reviewer", "approving_principal", "giver", "ge_approver",
           "captured_employee", "monitored_employee", "registered_person", "statement_participant", "plan_participant",
           "award_recipient", "advisor_key"]
# Special category (CD-344) and its proxies: heightened supervision plans (their basis can be special category) and the
# DP-039 disclosure events (restricted licensing view, CW-213 exception).
_SPECIAL = ["heightened_supervision_plan_reference", "disclosure_event_type", "disclosure_status", "reported_on_filing"]
# Compensation amounts (DP-390, Confidential - Compensation).
_COMP = ["total_earned", "net_payable_amount", "measured_result", "attainment_percentage", "earned_amount",
         "target_incentive_amount", "non_cash_award_value"]


def _count(name, expr, src, desc, agg="additive", time_rule="", note=""):
    d = dict(name=name, aggregation=agg, expr=expr, source=src, description=desc)
    if time_rule:
        d["time_rule"] = time_rule
    if note:
        d["note"] = note
    return d


def _ratio(name, num, den, src, desc, note=""):
    d = dict(name=name, aggregation="ratio", numerator=num, denominator=den, source=src, description=desc)
    if note:
        d["note"] = note
    return d


def _asof(name, expr, src, desc, note=""):
    return _count(name, expr, src, desc, agg="semi_additive", time_rule=_ASOF, note=note)


MODEL = dict(
    id="SM-29",
    status="Draft",
    description=(
        "Supervision, conduct and licensing across the retail business, for the Head of Retail Conduct, branch and "
        "supervisory principals, complaints, registration and licensing compliance, communications surveillance and "
        "sales compensation governance. It answers questions across offices, principals, advisors, scenarios and months: "
        "review backlogs and exceptions, disclosure delivery, sales practice alerts, inspections and findings, "
        "complaints and Rule 4530 reporting, registrations and CE, incentive plan conflicts and communications capture, "
        "with the retail conduct risk indicators (DP-404) that bring them together by advisor and office. Client "
        "special-category data is never shown row by row: protected clients and elder-exploitation holds appear only as "
        "counts of 10 or more."),
    questions=[
        "Which cash movements are on hold for fraud or elder-exploitation review: how many, for how much, and how many "
        "protected clients sit in each advisor's book (acceptance question 7, by aggregate)?",
        "Which offices and principals carry review backlogs past standard, high exception rates, self-reviews or "
        "reviews by a principal who is not the supervisor of record?",
        "Are Form CRS and Reg BI disclosures delivered on time, and which triggers fail most often?",
        "Which advisors breach two or more conduct indicators, combining best-interest and PTE 2020-02 evidence gaps, "
        "sales practice alerts, complaints and overdue corrective actions, by office and offering?",
        "How many complaints do we receive per 1,000 households and per USD 1 billion of client assets, how quickly do "
        "we respond, and what do we report under Rule 4530?",
        "Are branches inspected on cycle, supervisors qualified, registrations and CE current, communications captured, "
        "and incentive plans free of product-specific or rollover-biased components?",
    ],

    tables=[
        # --- Certified client assets by advisor (SM-20 family), read only to normalize conduct counts ------------------
        dict(name="client_assets_advisor", product="DP-008", entity="Measure Value", kind="Fact",
             grain="advisor x month (locked snapshot); the advisor slice of the certified client-asset family",
             always_filter=_DP008_ADVISOR,
             dimensions=[dict(name="period_end_date", attr="Period End Date"),
                         dict(name="dimension_key", attr="Dimension Key", note="The advisor (DP-009 Employee ID)")],
             facts=[dict(name="ending_client_assets", attr="Ending Client Assets")]),

        # --- DP-391 Supervisory Structure & Principal Coverage: the supervisor of record and the branch network --------
        dict(name="supervisory_assignment", product="DP-391", entity="Supervisory Assignment", kind="Fact",
             grain="supervised person x assigned supervisor x assignment type x effective period (SCD type 2)",
             default_filter="assignment in force at the as-of date: " + _IN_FORCE.format(p="assignment_"),
             dimensions=[dict(name="supervised_person", attr="Supervised Person"),
                         dict(name="assigned_supervisor", attr="Assigned Supervisor"),
                         dict(name="supervisory_assignment_type", attr="Supervisory Assignment Type"),
                         dict(name="supervising_office", attr="Supervising Office"),
                         dict(name="heightened_supervision_plan_reference", attr="Heightened Supervision Plan Reference",
                              note="Presence only; the plan's basis is never read (CD-344)"),
                         dict(name="assignment_effective_from", attr="Assignment Effective From"),
                         dict(name="assignment_effective_to", attr="Assignment Effective To")]),
        # Own dimension (DP-391 masters the 03 designation): DP-398, DP-402, DP-404 and DP-414 conform their office to it.
        dict(name="firm_branch_office", product="DP-391", entity="Firm Branch Office", kind="Dimension",
             default_filter="designation in force at the as-of date: " + _IN_FORCE.format(p="branch_designation_"),
             dimensions=[dict(name="office", attr="Office"),
                         dict(name="branch_type", attr="Branch Type"),
                         dict(name="supervises_non_branch_locations", attr="Supervises Non-Branch Locations Indicator"),
                         dict(name="residential_supervisory_location", attr="Residential Supervisory Location Indicator",
                              note="A residential location is an employee's home; only the type and state are shown"),
                         dict(name="branch_registration_reference", attr="Branch Registration Reference"),
                         dict(name="branch_status", attr="Branch Status"),
                         dict(name="branch_designation_effective_from", attr="Branch Designation Effective From"),
                         dict(name="branch_designation_effective_to", attr="Branch Designation Effective To")]),
        dict(name="supervisory_hierarchy_link", product="DP-391", entity="Supervisory Hierarchy Link", kind="Bridge",
             grain="child supervisory unit x parent unit x link effective period",
             default_filter="link in force at the as-of date: " + _IN_FORCE.format(p="link_"),
             dimensions=[dict(name="child_supervisory_unit", attr="Child Supervisory Unit"),
                         dict(name="parent_supervisory_unit", attr="Parent Supervisory Unit"),
                         dict(name="supervisory_link_type", attr="Supervisory Link Type"),
                         dict(name="link_effective_from", attr="Link Effective From"),
                         dict(name="link_effective_to", attr="Link Effective To")]),
        dict(name="principal_designation", product="DP-391", entity="Principal Designation", kind="Fact",
             grain="principal x designation type x office x effective period",
             default_filter="designation in force at the as-of date: " + _IN_FORCE.format(p="designation_"),
             dimensions=[dict(name="designated_principal", attr="Designated Principal"),
                         dict(name="principal_designation_type", attr="Principal Designation Type"),
                         dict(name="designation_office", attr="Designation Office"),
                         dict(name="supervised_functions", attr="Supervised Functions"),
                         dict(name="qualifying_registration", attr="Qualifying Registration"),
                         dict(name="designation_effective_from", attr="Designation Effective From"),
                         dict(name="designation_effective_to", attr="Designation Effective To")]),
        dict(name="branch_registration", product="DP-391", entity="Branch Registration", kind="Fact",
             grain="one Form BR filing for a branch office",
             dimensions=[dict(name="registered_office", attr="Registered Office"),
                         dict(name="branch_crd_number", attr="Branch CRD Number"),
                         dict(name="registered_branch_type", attr="Registered Branch Type"),
                         dict(name="form_br_filing_type", attr="Form BR Filing Type"),
                         dict(name="form_br_filed_date", attr="Form BR Filed Date"),
                         dict(name="branch_closing_date", attr="Branch Closing Date")]),

        # --- DP-398 Principal Review Queue & Supervisory Approvals ---------------------------------------------------
        # Completed reviews are immutable; open reviews are snapshotted daily, so an open review appears once per day.
        dict(name="supervisory_review", product="DP-398", entity="Supervisory Review Outcome", kind="Fact",
             grain="one principal review of one subject (PRNR-): completed reviews once, open reviews on the selected "
                   "daily snapshot",
             always_filter=["completed reviews, plus open reviews from the daily snapshot of the as-of date only "
                            "(earlier snapshots of an open review would count it once per day)"],
             dimensions=[dict(name="supervisory_review_id", attr="Supervisory Review ID"),
                         dict(name="supervisory_review_type", attr="Supervisory Review Type"),
                         dict(name="review_outcome", attr="Review Outcome"),
                         dict(name="review_completed_date", attr="Review Completed Date"),
                         dict(name="applied_supervisory_control", attr="Applied Supervisory Control"),
                         dict(name="standard_of_conduct_applied", attr="Standard of Conduct Applied"),
                         dict(name="profile_current", attr="Profile Current Indicator"),
                         dict(name="alternatives_evidence_present", attr="Alternatives Evidence Present Indicator"),
                         dict(name="cost_evidence_present", attr="Cost Evidence Present Indicator"),
                         dict(name="pte_documentation_present", attr="PTE Documentation Present Indicator"),
                         dict(name="rollover_analysis_reviewed", attr="Rollover Analysis Reviewed"),
                         dict(name="disclosure_delivery_checked", attr="Disclosure Delivery Checked"),
                         dict(name="supervised_representative", attr="Supervised Representative"),
                         dict(name="reviewing_principal", attr="Reviewing Principal"),
                         dict(name="source_sales_practice_alert", attr="Source Sales Practice Alert"),
                         dict(name="reviewed_recommendation", attr="Reviewed Recommendation",
                              note="DP-303 key; the recommendation and its evidence are SM-22's"),
                         dict(name="reviewed_account", attr="Reviewed Account"),
                         dict(name="reviewed_account_feature", attr="Reviewed Account Feature"),
                         dict(name="reviewed_client_order", attr="Reviewed Client Order"),
                         dict(name="reviewed_routing_rule", attr="Reviewed Routing Rule"),
                         dict(name="reviewed_execution_venue", attr="Reviewed Execution Venue")],
             hidden=[("Evidence Exceptions", "Free text the principal records; counted through Reviews Recording "
                                             "Evidence Exceptions, never shown across rows."),
                     ("Reviewed Correspondence", "A correspondence key; communications content stays in the "
                                                 "surveillance system (DP-078)."),
                     ("Investor Profile Version Checked", "A client investor profile key (DP-240); no cross-row "
                                                          "question needs the profile itself."),
                     ("Best Interest Evidence Reviewed", "A DP-303 evidence key; the evidence is SM-22's and is never "
                                                         "re-scored here (CW-224).")]),

        # --- DP-399 Form CRS & Reg BI Disclosure Delivery Control ----------------------------------------------------
        dict(name="disclosure_check", product="DP-399", entity="Disclosure Delivery Check", kind="Fact",
             grain="account or retail investor x disclosure trigger x trigger date (immutable per check)",
             dimensions=[dict(name="checked_account", attr="Checked Account"),
                         dict(name="checked_retail_investor", attr="Checked Retail Investor"),
                         dict(name="disclosure_trigger", attr="Disclosure Trigger"),
                         dict(name="trigger_date", attr="Trigger Date"),
                         dict(name="disclosures_checked", attr="Disclosures Checked"),
                         dict(name="form_crs_version_required", attr="Form CRS Version Required"),
                         dict(name="account_delivery_evidence", attr="Account Delivery Evidence"),
                         dict(name="client_level_delivery_evidence", attr="Client-Level Delivery Evidence"),
                         dict(name="communication_delivery_evidence", attr="Communication Delivery Evidence"),
                         dict(name="fee_disclosure_evidence", attr="Fee Disclosure Evidence"),
                         dict(name="check_date", attr="Check Date"),
                         dict(name="check_result", attr="Check Result")]),
        dict(name="account_disclosure_delivery", product="DP-399", entity="Account Disclosure Delivery", kind="Fact",
             grain="account x disclosure type x version x delivered date",
             dimensions=[dict(name="disclosure_account", attr="Disclosure Account"),
                         dict(name="disclosure_type", attr="Disclosure Type"),
                         dict(name="disclosure_version", attr="Disclosure Version"),
                         dict(name="disclosure_delivery_method", attr="Disclosure Delivery Method"),
                         dict(name="disclosure_delivered_date", attr="Disclosure Delivered Date"),
                         dict(name="related_program_enrollment", attr="Related Program Enrollment")]),
        dict(name="recipient_delivery", product="DP-399", entity="Recipient Delivery", kind="Fact",
             grain="distribution job x investor document x recipient account",
             dimensions=[dict(name="recipient_account", attr="Recipient Account"),
                         dict(name="recipient_delivery_method", attr="Recipient Delivery Method"),
                         dict(name="recipient_delivery_status", attr="Recipient Delivery Status"),
                         dict(name="returned_mail_date", attr="Returned Mail Date")],
             hidden=[("Distribution Job", "A DP-382 key used only to resolve the evidence; distribution jobs are SM-25's."),
                     ("Delivered Investor Document", "A DP-382 document key; documents are SM-25's.")]),
        dict(name="fee_disclosure_delivery", product="DP-399", entity="Fee Disclosure Delivery", kind="Fact",
             grain="recipient x account x fee disclosure type x fee schedule x delivered date",
             dimensions=[dict(name="fee_disclosure_recipient", attr="Fee Disclosure Recipient"),
                         dict(name="fee_disclosure_account", attr="Fee Disclosure Account"),
                         dict(name="fee_disclosure_type", attr="Fee Disclosure Type"),
                         dict(name="disclosed_fee_schedule", attr="Disclosed Fee Schedule"),
                         dict(name="disclosure_document_version", attr="Disclosure Document Version"),
                         dict(name="fee_disclosure_delivered_date", attr="Fee Disclosure Delivered Date"),
                         dict(name="fee_change_effective_date", attr="Fee Change Effective Date")]),
        dict(name="form_crs_filing", product="DP-399", entity="Form CRS Filing", kind="Dimension",
             dimensions=[dict(name="firm_filing_id", attr="Firm Filing ID"),
                         dict(name="filing_submitted_timestamp", attr="Filing Submitted Timestamp"),
                         dict(name="firm_filing_status", attr="Firm Filing Status"),
                         dict(name="form_crs_filing_ref", attr="Form CRS Filing"),
                         dict(name="form_crs_filer_capacity", attr="Form CRS Filer Capacity"),
                         dict(name="relationship_summary_version", attr="Relationship Summary Version"),
                         dict(name="form_crs_amendment_trigger", attr="Form CRS Amendment Trigger"),
                         dict(name="posted_to_website_date", attr="Posted to Website Date")]),

        # --- DP-400 Sales Practice Surveillance & Corrective Action --------------------------------------------------
        # DP-400's Client Holding entity (a view of 49 through DP-300) is not published: holdings are SM-24's book of
        # record, and a second copy here would break the one-book-per-table rule (CW-007).
        dict(name="sales_practice_alert", product="DP-400", entity="Sales Practice Alert", kind="Fact",
             grain="one sales practice alert (SPA-) with its current disposition",
             dimensions=[dict(name="sales_practice_alert_id", attr="Sales Practice Alert ID"),
                         dict(name="alert_scenario", attr="Alert Scenario"),
                         dict(name="alert_type", attr="Alert Type"),
                         dict(name="alert_generated_date", attr="Alert Generated Date"),
                         dict(name="alert_disposition", attr="Alert Disposition"),
                         dict(name="alerted_representative", attr="Alerted Representative"),
                         dict(name="alert_account", attr="Alert Account"),
                         dict(name="triggering_recommendation", attr="Triggering Recommendation"),
                         dict(name="triggering_transaction", attr="Triggering Transaction")]),
        dict(name="surveillance_scenario", product="DP-400", entity="Surveillance Scenario", kind="Dimension",
             default_filter="scenario version in force at the as-of date",
             dimensions=[dict(name="scenario_id", attr="Scenario ID"),
                         dict(name="scenario_type", attr="Scenario Type"),
                         dict(name="scenario_rule_basis", attr="Scenario Rule Basis"),
                         dict(name="scenario_model", attr="Scenario Model"),
                         dict(name="scenario_status", attr="Scenario Status"),
                         dict(name="scenario_effective_from", attr="Scenario Effective From"),
                         dict(name="scenario_effective_to", attr="Scenario Effective To")],
             hidden=[("Threshold Parameters", "Scenario thresholds are kept from the people the scenarios surveil; "
                                              "tuning is done on DP-400's own dashboard.")]),
        # One 08 Conduct Corrective Action object, two product slices: actions raised from alerts or reviews (DP-400)
        # and actions raised from findings (DP-402). Each table is pinned to its own source so no action is read twice.
        dict(name="alert_corrective_action", product="DP-400", entity="Conduct Corrective Action", kind="Fact",
             grain="one corrective action raised from a sales practice alert or a supervisory review",
             always_filter=["source_sales_practice_alert is not null or source_supervisory_review is not null"],
             dimensions=[dict(name="corrective_action_id", attr="Corrective Action ID"),
                         dict(name="source_supervisory_review", attr="Source Supervisory Review"),
                         dict(name="source_sales_practice_alert", attr="Source Sales Practice Alert"),
                         dict(name="corrective_action_type", attr="Corrective Action Type"),
                         dict(name="action_subject_representative", attr="Action Subject Representative"),
                         dict(name="action_due_date", attr="Action Due Date"),
                         dict(name="action_status", attr="Action Status"),
                         dict(name="client_remediation", attr="Client Remediation")]),

        # --- DP-402 Supervisory Controls, Branch Inspections & Findings ----------------------------------------------
        dict(name="control_test", product="DP-402", entity="Supervisory Control Test", kind="Fact",
             grain="supervisory control x test period (immutable once completed)",
             dimensions=[dict(name="tested_control", attr="Tested Control"),
                         dict(name="test_period_end_date", attr="Test Period End Date"),
                         dict(name="test_result", attr="Test Result"),
                         dict(name="control_tester", attr="Control Tester"),
                         dict(name="wsp_amendment_required", attr="WSP Amendment Required Indicator"),
                         dict(name="rule_3120_report_date", attr="Rule 3120 Report Date")]),
        dict(name="supervisory_control", product="DP-402", entity="Supervisory Control", kind="Dimension",
             dimensions=[dict(name="supervisory_control_number", attr="Supervisory Control Number"),
                         dict(name="governing_wsp_policy", attr="Governing WSP Policy"),
                         dict(name="supervised_activity", attr="Supervised Activity"),
                         dict(name="responsible_designation", attr="Responsible Designation"),
                         dict(name="control_frequency", attr="Control Frequency"),
                         dict(name="control_rule_basis", attr="Control Rule Basis"),
                         dict(name="control_status", attr="Control Status")]),
        dict(name="wsp_policy", product="DP-402", entity="WSP Policy", kind="Dimension",
             dimensions=[dict(name="policy_id", attr="Policy ID"),
                         dict(name="policy_title", attr="Policy Title"),
                         dict(name="policy_status", attr="Policy Status")]),
        dict(name="branch_inspection", product="DP-402", entity="Branch Inspection", kind="Fact",
             grain="one inspection of a branch office or location",
             dimensions=[dict(name="branch_inspection_id", attr="Branch Inspection ID"),
                         dict(name="inspected_office", attr="Inspected Office"),
                         dict(name="branch_type_at_inspection", attr="Branch Type at Inspection"),
                         dict(name="inspection_cycle", attr="Inspection Cycle"),
                         dict(name="remote_inspection", attr="Remote Inspection Indicator"),
                         dict(name="inspection_date", attr="Inspection Date"),
                         dict(name="inspector", attr="Inspector"),
                         dict(name="inspection_report_date", attr="Inspection Report Date")]),
        dict(name="supervisory_finding", product="DP-402", entity="Supervisory Finding", kind="Fact",
             grain="one supervisory finding from an inspection or a control test",
             dimensions=[dict(name="supervisory_finding_id", attr="Supervisory Finding ID"),
                         dict(name="finding_source", attr="Finding Source"),
                         dict(name="source_branch_inspection", attr="Source Branch Inspection"),
                         dict(name="source_control_test", attr="Source Control Test"),
                         dict(name="finding_severity", attr="Finding Severity"),
                         dict(name="finding_status", attr="Finding Status")]),
        dict(name="finding_corrective_action", product="DP-402", entity="Finding Corrective Action", kind="Fact",
             grain="one corrective action raised from a supervisory finding",
             always_filter=["source_supervisory_finding is not null"],
             dimensions=[dict(name="finding_action_id", attr="Corrective Action ID"),
                         dict(name="source_supervisory_finding", attr="Source Supervisory Finding"),
                         dict(name="action_owner", attr="Action Owner"),
                         dict(name="finding_action_due_date", attr="Action Due Date"),
                         dict(name="finding_action_status", attr="Action Status")]),
        # The one heightened supervision table: DP-400 and DP-402 read the same 08 object; DP-402's carries the
        # heightened supervisor, so DP-400's Representatives Under Heightened Supervision is counted here too.
        dict(name="heightened_supervision_plan", product="DP-402", entity="Heightened Supervision Plan", kind="Fact",
             grain="one heightened supervision plan for a representative (its basis is not read, CD-344)",
             default_filter="plan in force at the as-of date: plan_start_date <= :as_of and (plan_end_date is null or "
                            "plan_end_date > :as_of)",
             dimensions=[dict(name="heightened_supervision_plan_id", attr="Heightened Supervision Plan ID"),
                         dict(name="plan_supervised_representative", attr="Supervised Representative"),
                         dict(name="heightened_supervisor", attr="Heightened Supervisor"),
                         dict(name="plan_start_date", attr="Plan Start Date"),
                         dict(name="plan_end_date", attr="Plan End Date")]),
        dict(name="supervisory_attestation", product="DP-402", entity="Supervisory Attestation", kind="Fact",
             grain="attester x attestation type x attestation period (the Rule 3130 certification)",
             dimensions=[dict(name="attestation_type", attr="Attestation Type"),
                         dict(name="attester", attr="Attester"),
                         dict(name="attestation_completed_date", attr="Attestation Completed Date"),
                         dict(name="attestation_status", attr="Attestation Status"),
                         dict(name="attestation_period", attr="Attestation Period")]),

        # --- DP-404 Retail Conduct Risk Indicators: the advisor and office view ---------------------------------------
        # Each count is read from its owning product under the owner's measure name (CW-224). The copies of DP-400,
        # DP-402, DP-039 and DP-036 counts are the advisor and office read of the same published numbers for roles that
        # do not see the source rows; the metrics below say which table each role reads. Row-level rates are hidden:
        # rates are recomputed from counts, never averaged.
        dict(name="conduct_indicator", product="DP-404", entity="Conduct Indicator", kind="Fact",
             grain="advisor x office x offering x month (each indicator a column; monthly snapshot)",
             always_filter=["one monthly snapshot per month-end (the locked month-end load)"],
             default_filter="calendar_date_key = latest month-end",
             dimensions=[dict(name="indicator_month", attr="Calendar Date Key"),
                         dict(name="office_key", attr="Firm Branch Office Key"),
                         dict(name="offering_key", attr="Offering Key"),
                         dict(name="advisor_key", attr="Advisor Key")],
             facts=[dict(name="recommendations_without_bi_evidence",
                         attr="Recommendations Without Best-Interest Evidence (from DP-334)"),
                    dict(name="rollovers_without_pte_documentation",
                         attr="Rollovers Without PTE 2020-02 Documentation (from DP-335)"),
                    dict(name="alerts_past_review_standard", attr="Alerts Past Review Standard (from DP-400)"),
                    dict(name="corrective_actions_overdue", attr="Corrective Actions Overdue (from DP-400)"),
                    dict(name="open_findings", attr="Open Findings by Severity (from DP-402)"),
                    dict(name="clients_under_protection", attr="Clients Under Protection (from DP-322)",
                         note="An aggregate of DP-322's special-category flag; shown at 10 or more only"),
                    dict(name="advisors_without_registration", attr="Active Advisors Without Registration (from DP-039)"),
                    dict(name="ce_overdue", attr="CE Overdue Count (from DP-039)"),
                    dict(name="overdue_filings", attr="Overdue Filings (from DP-036)")],
             hidden=[("Evidence Gap Rate % (from DP-334)", "A row rate; the model references SM-22's Evidence Gap Rate %, "
                                                           "recomputed from counts for each slice."),
                     ("PTE Documentation Gap Rate % (from DP-335)", "A row rate; the model references SM-22's PTE "
                                                                    "Documentation Gap Rate %."),
                     ("Review Exception Rate % (from DP-398)", "A row rate; Review Exception Rate % is computed from "
                                                               "supervisory_review counts."),
                     ("Households (from DP-008)", "A copy of the certified Households; the model references "
                                                  "SM-20/Households at the advisor slice."),
                     ("Ending Client Assets (from DP-008)", "A copy of the certified Ending Client Assets; the model "
                                                            "references SM-20/Client Assets through client_assets_advisor.")]),

        # --- DP-414 Complaints & Rule 4530 Reporting -----------------------------------------------------------------
        # Handling is SCD type 2: one complaint has a row per handling version, so the current version is pinned.
        dict(name="complaint", product="DP-414", entity="Complaint", kind="Fact",
             grain="one complaint (CPL-), current handling version",
             always_filter=["handling version in force at the as-of date (SCD type 2; older versions would count a "
                            "complaint more than once)"],
             dimensions=[dict(name="complaint_id", attr="Complaint ID"),
                         dict(name="received_date", attr="Received Date"),
                         dict(name="complaint_source", attr="Complaint Source"),
                         dict(name="written_complaint", attr="Written Complaint Indicator"),
                         dict(name="complainant", attr="Complainant"),
                         dict(name="intake_service_request", attr="Intake Service Request"),
                         dict(name="complaint_account", attr="Account"),
                         dict(name="product_share_class", attr="Product / Share Class"),
                         dict(name="related_recommendation", attr="Related Recommendation"),
                         dict(name="associated_person_named", attr="Associated Person Named"),
                         dict(name="complaint_office", attr="Complaint Office"),
                         dict(name="complaint_category", attr="Complaint Category"),
                         dict(name="finra_problem_code", attr="FINRA Problem Code"),
                         dict(name="finra_product_code", attr="FINRA Product Code"),
                         dict(name="root_cause", attr="Root Cause"),
                         dict(name="complaint_status", attr="Complaint Status"),
                         dict(name="final_response_due_date", attr="Final Response Due Date"),
                         dict(name="final_response_date", attr="Final Response Date"),
                         dict(name="complaint_outcome", attr="Complaint Outcome"),
                         dict(name="client_remediation", attr="Client Remediation"),
                         dict(name="arbitration_matter", attr="Arbitration Matter"),
                         dict(name="finra_4530d_reporting_quarter", attr="FINRA 4530(d) Reporting Quarter"),
                         dict(name="finra_4530a_reportable", attr="FINRA 4530(a) Event Reportable Indicator"),
                         dict(name="form_u4_reportable", attr="Form U4 Reportable Indicator"),
                         dict(name="related_disclosure_event", attr="Related Disclosure Event")],
             facts=[dict(name="redress_amount", attr="Redress Amount")]),
        dict(name="complaint_interaction", product="DP-414", entity="Contact Center Interaction", kind="Fact",
             grain="one assisted-service interaction (read for unlogged dissatisfaction only)",
             dimensions=[dict(name="interaction_id", attr="Interaction ID"),
                         dict(name="interaction_account", attr="Interaction Account"),
                         dict(name="interaction_start", attr="Interaction Start Timestamp"),
                         dict(name="dissatisfaction_expressed", attr="Dissatisfaction Expressed Indicator"),
                         dict(name="linked_service_request", attr="Linked Service Request")]),
        dict(name="survey_response", product="DP-414", entity="Survey Response", kind="Fact",
             grain="one survey response (read for complaint referrals only)",
             dimensions=[dict(name="response_id", attr="Response ID"),
                         dict(name="response_timestamp", attr="Response Timestamp"),
                         dict(name="complaint_referral", attr="Complaint Referral")]),

        # --- DP-036 Communications Review & FINRA Filing -------------------------------------------------------------
        dict(name="compliance_review", product="DP-036", entity="Fact Compliance Review", kind="Fact",
             grain="compliance review x asset version (one submission)",
             dimensions=[dict(name="review_id", attr="Review ID"),
                         dict(name="submission_date_key", attr="Submission Date Key"),
                         dict(name="submission_timestamp", attr="Submission Timestamp"),
                         dict(name="submitted_by", attr="Submitted By"),
                         dict(name="review_type", attr="Review Type"),
                         dict(name="communication_asset", attr="Communication Asset"),
                         dict(name="products_featured", attr="Products Featured"),
                         dict(name="services_featured", attr="Services Featured"),
                         dict(name="intended_audience", attr="Intended Audience"),
                         dict(name="finra_communication_category", attr="FINRA Communication Category"),
                         dict(name="investment_company_communication_type", attr="Investment Company Communication Type"),
                         dict(name="marketing_rule_advertisement", attr="Marketing Rule Advertisement Indicator"),
                         dict(name="marketing_rule_advertisement_type", attr="Marketing Rule Advertisement Type"),
                         dict(name="testimonial_endorsement", attr="Testimonial / Endorsement Indicator"),
                         dict(name="third_party_rating", attr="Third-Party Rating Indicator"),
                         dict(name="fair_and_balanced_check", attr="Fair and Balanced Check"),
                         dict(name="performance_shown", attr="Performance Shown Indicator"),
                         dict(name="performance_type", attr="Performance Type"),
                         dict(name="gross_net_presentation", attr="Gross / Net Presentation"),
                         dict(name="performance_as_of_date", attr="Performance As-Of Date"),
                         dict(name="used_before_approval_flag", attr="Used Before Approval Flag"),
                         dict(name="expired_in_use_flag", attr="Expired In Use Flag"),
                         dict(name="principal_qualification_exception", attr="Principal Qualification Exception")]),
        dict(name="review_step", product="DP-036", entity="Fact Review Step", kind="Fact",
             grain="compliance review x review step sequence",
             dimensions=[dict(name="review_step_sequence", attr="Review Step Sequence"),
                         dict(name="reviewer", attr="Reviewer"),
                         dict(name="reviewer_role", attr="Reviewer Role"),
                         dict(name="step_outcome", attr="Step Outcome"),
                         dict(name="step_completed_timestamp", attr="Step Completed Timestamp")]),
        dict(name="compliance_approval", product="DP-036", entity="Fact Compliance Approval", kind="Fact",
             grain="compliance review x approval decision",
             dimensions=[dict(name="approval_status", attr="Approval Status"),
                         dict(name="approval_decision_date", attr="Approval Decision Date"),
                         dict(name="approving_principal", attr="Approving Principal"),
                         dict(name="approving_principal_license", attr="Approving Principal License"),
                         dict(name="approval_expiry_date", attr="Approval Expiry Date"),
                         dict(name="withdrawal_date", attr="Withdrawal Date")]),
        dict(name="finra_filing", product="DP-036", entity="Fact FINRA Filing", kind="Fact",
             grain="compliance review x FINRA filing submission",
             dimensions=[dict(name="finra_filing_requirement", attr="FINRA Filing Requirement"),
                         dict(name="finra_filing_reference", attr="FINRA Filing Reference"),
                         dict(name="first_use_date", attr="First Use Date"),
                         dict(name="filing_due_date", attr="Filing Due Date"),
                         dict(name="filed_date", attr="Filed Date"),
                         dict(name="finra_review_outcome", attr="FINRA Review Outcome")]),
        dict(name="asset_version", product="DP-036", entity="Asset Version", kind="Dimension",
             dimensions=[dict(name="version_number", attr="Version Number"),
                         dict(name="asset_lifecycle_status", attr="Asset Lifecycle Status"),
                         dict(name="publication_date", attr="Publication Date"),
                         dict(name="asset_expiry_date", attr="Expiry Date"),
                         dict(name="withdrawal_reason", attr="Withdrawal Reason")]),
        dict(name="asset_compliance_reference", product="DP-036", entity="Asset Compliance Reference", kind="Dimension",
             dimensions=[dict(name="mirrored_approval_status", attr="Approval Status (Mirrored)"),
                         dict(name="performance_content_declared", attr="Performance Content Declared Indicator"),
                         dict(name="hypothetical_performance_declared", attr="Hypothetical Performance Declared Indicator"),
                         dict(name="testimonial_rating_declared",
                              attr="Testimonial / Endorsement / Rating Declared Indicator")]),
        dict(name="track_record", product="DP-036", entity="Share Class", kind="Dimension",
             dimensions=[dict(name="track_record_share_class", attr="Share Class ID"),
                         dict(name="performance_inception_date", attr="Performance Inception Date"),
                         dict(name="track_record_source", attr="Track Record Source"),
                         dict(name="performance_calculation_basis", attr="Performance Calculation Basis")]),

        # --- DP-038 Gifts & Non-Cash Compensation --------------------------------------------------------------------
        dict(name="ge_item", product="DP-038", entity="Fact G&E Item", kind="Fact",
             grain="gift or entertainment item x recipient individual (one benefit on one date)",
             dimensions=[dict(name="gne_id", attr="GNE ID"),
                         dict(name="direction", attr="Direction"),
                         dict(name="benefit_type", attr="Benefit Type"),
                         dict(name="benefit_date", attr="Benefit Date"),
                         dict(name="giver", attr="Giver"),
                         dict(name="recipient_individual", attr="Recipient Individual"),
                         dict(name="recipient_firm", attr="Recipient Firm"),
                         dict(name="host_present", attr="Host Present Indicator"),
                         dict(name="related_event", attr="Related Event"),
                         dict(name="union_official", attr="Union Official Indicator"),
                         dict(name="erisa_plan_fiduciary", attr="ERISA Plan Fiduciary Indicator"),
                         dict(name="government_official", attr="Government Official Indicator"),
                         dict(name="applicable_limit_rule", attr="Applicable Limit Rule"),
                         dict(name="recipient_ytd_value", attr="Recipient Year-to-Date Value",
                              note="A running total per recipient and year: read the latest, never summed"),
                         dict(name="limit_breach", attr="Limit Breach Indicator"),
                         dict(name="sales_target_precondition", attr="Sales Target Precondition Indicator"),
                         dict(name="meeting_event", attr="Meeting Event"),
                         dict(name="sponsor_firm", attr="Sponsor Firm"),
                         dict(name="member_firm_prior_approval", attr="Member Firm Prior Approval Indicator"),
                         dict(name="guest_expenses_paid", attr="Guest Expenses Paid Indicator")],
             facts=[dict(name="total_cost", attr="Total Cost"),
                    dict(name="per_recipient_value", attr="Per-Recipient Value"),
                    dict(name="annual_limit_amount", attr="Annual Limit Amount",
                         note="The limit of the rule; taken once per recipient and year, never summed")]),
        dict(name="ge_approval", product="DP-038", entity="Fact G&E Approval", kind="Fact",
             grain="gift or entertainment item x approval decision (approver)",
             dimensions=[dict(name="ge_approval_status", attr="G&E Approval Status"),
                         dict(name="ge_approver", attr="G&E Approver")]),
        dict(name="ge_distribution_cost", product="DP-038", entity="Fact Distribution Cost Item", kind="Fact",
             grain="distribution cost item (source record x service period), Gifts & Entertainment category only",
             always_filter=["distribution_expense_category = 'Gifts & Entertainment'"],
             dimensions=[dict(name="distribution_cost_item_id", attr="Distribution Cost Item ID"),
                         dict(name="distribution_expense_category", attr="Distribution Expense Category"),
                         dict(name="service_period_start", attr="Service Period Start")],
             facts=[dict(name="expense_amount", attr="Expense Amount")],
             hidden=[("Source Record", "A ledger source key; the reconciliation is read at month level only.")]),

        # --- DP-039 Representative Registrations, Licensing & CE (restricted view: licensing compliance only) --------
        # The registrations themselves are the shared DP-009 Individual Registration (SM-00); DP-039's tables are the
        # licensing compliance view and are read only by that role (see access).
        dict(name="person_compliance_status", product="DP-039", entity="Fact Person Compliance Status", kind="Fact",
             grain="registered person x status date (daily person-level compliance status)",
             always_filter=["status_date_key is a single as-of date (daily status rows repeat each person every day)"],
             default_filter="status_date_key = latest",
             dimensions=[dict(name="status_date_key", attr="Status Date Key"),
                         dict(name="registered_person", attr="Registered Person Key")],
             facts=[dict(name="registered_headcount", attr="Registered Headcount"),
                    dict(name="unregistered_coverage_exceptions", attr="Unregistered Coverage Exception"),
                    dict(name="ce_overdue_count", attr="CE Overdue Count"),
                    dict(name="ce_due_next_60_days", attr="CE Due Next 60 Days"),
                    dict(name="late_u4_amendments", attr="Late U4 Disclosure Amendments"),
                    dict(name="open_disclosure_events", attr="Open Disclosure Events"),
                    dict(name="exam_pass_pending", attr="Exam Pass Pending"),
                    dict(name="terminated_while_covering", attr="Registrations Terminated While Covering"),
                    dict(name="registration_copy_stale", attr="Registration Copy Stale"),
                    dict(name="active_without_registration", attr="Active Advisors Without Registration")]),
        dict(name="exam_result", product="DP-039", entity="Fact Exam Result", kind="Fact",
             grain="registration x exam attempt",
             dimensions=[dict(name="examined_person", attr="Examined Person"),
                         dict(name="exam_code", attr="Exam Code"),
                         dict(name="exam_attempt_sequence", attr="Exam Attempt Sequence"),
                         dict(name="exam_date", attr="Exam Date"),
                         dict(name="exam_result_value", attr="Exam Result")]),
        dict(name="registration_filing", product="DP-039", entity="Fact Registration Filing", kind="Fact",
             grain="registration x form filing",
             dimensions=[dict(name="filed_for_person", attr="Filed For Person"),
                         dict(name="form_type", attr="Form Type"),
                         dict(name="form_filing_date", attr="Form Filing Date"),
                         dict(name="termination_reason", attr="Termination Reason"),
                         dict(name="triggering_lifecycle_event", attr="Triggering Lifecycle Event")]),
        dict(name="disclosure_event", product="DP-039", entity="Fact Disclosure Event", kind="Fact",
             grain="registered person x disclosure event (special category; restricted licensing view, CW-213 exception)",
             dimensions=[dict(name="disclosed_person", attr="Disclosed Person"),
                         dict(name="disclosure_event_type", attr="Disclosure Event Type"),
                         dict(name="disclosure_status", attr="Disclosure Status"),
                         dict(name="event_date", attr="Event Date"),
                         dict(name="reported_on_filing", attr="Reported On Filing")],
             hidden=[("Disclosure Event ID", "The event key; counts use the row, and no role needs the id across rows.")]),
        dict(name="ce_requirement", product="DP-039", entity="Fact CE Requirement", kind="Fact",
             grain="registration x CE element x due date",
             dimensions=[dict(name="ce_person", attr="CE Person"),
                         dict(name="ce_element", attr="CE Element"),
                         dict(name="ce_due_date", attr="CE Due Date"),
                         dict(name="ce_status", attr="CE Status")],
             facts=[dict(name="credits_completed", attr="Credits Completed")]),

        # --- DP-078 Communications Capture & Surveillance ------------------------------------------------------------
        dict(name="employee_capture_day", product="DP-078", entity="Fact Employee Capture Day", kind="Fact",
             grain="monitored employee x capture date",
             dimensions=[dict(name="capture_date_key", attr="Capture Date Key"),
                         dict(name="monitored_employee", attr="Monitored Employee Key"),
                         dict(name="in_scope_employee", attr="In-Scope Employee"),
                         dict(name="silent_employee_flag", attr="Silent Employee Flag"),
                         dict(name="without_supervisor_assignment", attr="Employees Without Supervisor Assignment")],
             facts=[dict(name="recorded_activity_capture_gap", attr="Recorded Activity Capture Gap"),
                    dict(name="unapproved_channel_activity", attr="Unapproved Channel Activity")]),
        dict(name="captured_communication", product="DP-078", entity="Fact Captured Communication", kind="Fact",
             grain="one captured communication (archived message or call); content is not read",
             dimensions=[dict(name="communication_record_id", attr="Communication Record ID"),
                         dict(name="capture_channel", attr="Capture Channel"),
                         dict(name="captured_employee", attr="Captured Employee"),
                         dict(name="communication_timestamp", attr="Communication Timestamp"),
                         dict(name="retention_rule", attr="Retention Rule"),
                         dict(name="retention_expiry_date", attr="Retention Expiry Date"),
                         dict(name="legal_hold", attr="Legal Hold Indicator")]),
        dict(name="comms_surveillance_alert", product="DP-078", entity="Fact Surveillance Alert", kind="Fact",
             grain="one communications surveillance alert",
             dimensions=[dict(name="comms_alert_id", attr="Alert ID"),
                         dict(name="alert_source", attr="Alert Source"),
                         dict(name="policy_lexicon_hit", attr="Policy / Lexicon Hit"),
                         dict(name="flagged_communication", attr="Flagged Communication"),
                         dict(name="alert_monitored_employee", attr="Monitored Employee"),
                         dict(name="alert_review_status", attr="Alert Review Status"),
                         dict(name="comms_alert_disposition", attr="Alert Disposition"),
                         dict(name="related_complaint", attr="Related Complaint")]),
        dict(name="approved_channel", product="DP-078", entity="Approved Communication Channel", kind="Dimension",
             default_filter="approval in force at the as-of date: " + _IN_FORCE.format(p="approval_"),
             dimensions=[dict(name="channel_approval_id", attr="Channel Approval ID"),
                         dict(name="channel_type", attr="Channel Type"),
                         dict(name="social_platform", attr="Social Platform"),
                         dict(name="firm_social_media_account", attr="Firm Social Media Account"),
                         dict(name="channel_account_owner", attr="Account Owner"),
                         dict(name="account_use_type", attr="Account Use Type"),
                         dict(name="approved_for_business_use", attr="Approved for Business Use Indicator"),
                         dict(name="capture_method", attr="Capture Method"),
                         dict(name="approval_effective_from", attr="Approval Effective From"),
                         dict(name="approval_effective_to", attr="Approval Effective To")]),
        dict(name="retention_rule_dim", product="DP-078", entity="Retention Rule", kind="Dimension",
             dimensions=[dict(name="retention_rule_id", attr="Retention Rule ID"),
                         dict(name="record_class", attr="Record Class"),
                         dict(name="governing_requirement", attr="Governing Requirement"),
                         dict(name="retention_period_years", attr="Retention Period (Years)")]),

        # --- DP-390 Incentive Plan Governance & Advisor Payouts (Confidential - Compensation) -------------------------
        # Statement amounts (Total Earned, Net Payable Amount) repeat on every earnings line of a statement: they are
        # taken once per statement, never summed over lines. DP-390's Variable Compensation Award (DP-198's pay, SM-15)
        # and Certified Client Assets (DP-008, SM-20) entities are not published here.
        dict(name="incentive_earnings", product="DP-390", entity="Incentive Earnings", kind="Fact",
             grain="compensation statement (advisor x statement period) x plan component earnings line",
             always_filter=["statement_status = 'Issued' or the statement is the latest version of its period "
                            "(statements are immutable once issued)"],
             dimensions=[dict(name="statement_id", attr="Statement ID"),
                         dict(name="statement_participant", attr="Statement Participant"),
                         dict(name="statement_period_end", attr="Statement Period End"),
                         dict(name="statement_status", attr="Statement Status"),
                         dict(name="statement_issued_date", attr="Statement Issued Date"),
                         dict(name="payroll_result_reference", attr="Payroll Result Reference"),
                         dict(name="earning_component", attr="Earning Component")],
             facts=[dict(name="total_earned", attr="Total Earned", note="Statement level: once per statement"),
                    dict(name="net_payable_amount", attr="Net Payable Amount", note="Statement level: once per statement"),
                    dict(name="measured_result", attr="Measured Result"),
                    dict(name="attainment_percentage", attr="Attainment Percentage"),
                    dict(name="earned_amount", attr="Earned Amount")]),
        dict(name="incentive_plan", product="DP-390", entity="Incentive Plan", kind="Dimension",
             default_filter="plan version in force at the as-of date: " + _IN_FORCE.format(p="plan_"),
             dimensions=[dict(name="incentive_plan_id", attr="Incentive Plan ID"),
                         dict(name="incentive_plan_name", attr="Incentive Plan Name"),
                         dict(name="incentive_plan_type", attr="Incentive Plan Type"),
                         dict(name="incentive_plan_year", attr="Incentive Plan Year"),
                         dict(name="payout_frequency", attr="Payout Frequency"),
                         dict(name="eligible_advisor_roles", attr="Eligible Advisor Roles"),
                         dict(name="plan_approval_status", attr="Plan Approval Status"),
                         dict(name="plan_effective_from", attr="Plan Effective From"),
                         dict(name="plan_effective_to", attr="Plan Effective To")]),
        dict(name="incentive_component", product="DP-390", entity="Incentive Plan Component", kind="Dimension",
             dimensions=[dict(name="component_id", attr="Component ID"),
                         dict(name="parent_incentive_plan", attr="Parent Incentive Plan"),
                         dict(name="component_measure", attr="Component Measure"),
                         dict(name="component_weight", attr="Component Weight"),
                         dict(name="threshold_attainment", attr="Threshold Attainment"),
                         dict(name="cap_amount", attr="Cap Amount"),
                         dict(name="product_specific_time_limited", attr="Product-Specific Time-Limited Indicator"),
                         dict(name="proprietary_product_linked", attr="Proprietary Product Linked Indicator"),
                         dict(name="rollover_neutral", attr="Rollover Neutral Indicator"),
                         dict(name="incentive_conflict_review_reference", attr="Incentive Conflict Review Reference")]),
        dict(name="plan_participation", product="DP-390", entity="Plan Participation", kind="Bridge",
             grain="advisor x incentive plan x participation effective period",
             default_filter="participation in force at the as-of date: " + _IN_FORCE.format(p="participation_"),
             dimensions=[dict(name="plan_participant", attr="Plan Participant"),
                         dict(name="assigned_plan", attr="Assigned Plan"),
                         dict(name="participant_eligibility_status", attr="Participant Eligibility Status"),
                         dict(name="plan_acknowledgment_date", attr="Plan Acknowledgment Date"),
                         dict(name="participation_effective_from", attr="Participation Effective From"),
                         dict(name="participation_effective_to", attr="Participation Effective To")],
             facts=[dict(name="target_incentive_amount", attr="Target Incentive Amount")]),
        dict(name="recognition_award", product="DP-390", entity="Recognition Award", kind="Fact",
             grain="one recognition award to an advisor",
             dimensions=[dict(name="recognition_award_id", attr="Recognition Award ID"),
                         dict(name="award_recipient", attr="Award Recipient"),
                         dict(name="recognition_program", attr="Recognition Program"),
                         dict(name="recognition_award_type", attr="Recognition Award Type"),
                         dict(name="award_date", attr="Award Date"),
                         dict(name="product_specific_criteria", attr="Product-Specific Criteria Indicator"),
                         dict(name="award_conduct_review_reference", attr="Award Conduct Review Reference")],
             facts=[dict(name="non_cash_award_value", attr="Non-Cash Award Value")]),
        dict(name="incentive_conflict_review", product="DP-390", entity="Incentive Conflict Review", kind="Fact",
             grain="one 08 conflict review of a plan component or recognition award on a review date",
             dimensions=[dict(name="reviewed_incentive_plan_component", attr="Reviewed Incentive Plan Component"),
                         dict(name="reviewed_recognition_award", attr="Reviewed Recognition Award"),
                         dict(name="conflict_review_date", attr="Conflict Review Date"),
                         dict(name="conflict_tests_applied", attr="Conflict Tests Applied"),
                         dict(name="proprietary_product_incentive_finding", attr="Proprietary Product Incentive Finding"),
                         dict(name="conflict_review_outcome", attr="Conflict Review Outcome"),
                         dict(name="mitigation_applied", attr="Mitigation Applied")]),
    ],

    shared=["DP-009/Employee", "DP-009/Individual Registration", "DP-009/Coverage Assignment",
            "DP-009/Advisor Role Assignment", "DP-240/Party", "DP-093/Account", "DP-093/Program Enrollment",
            "DP-093/Account Feature", "DP-004/Service Offering", "DP-004/Share Class", "DP-013/Calendar Date",
            "DP-013/Office Location", "DP-013/Internal Legal Entity", "DP-212/Model",
            # Principals, inspectors, testers and attesters who hold no advisor role: the DP-192 worker (the source of
            # SM-15's certified headcount, so it may lend its dimension; see open decisions)
            "DP-192/Employee"],

    relationships=[
        # Certified client assets by advisor
        dict(frm="client_assets_advisor", to="DP-009/Employee", on="client_assets_advisor.dimension_key = employee.employee_id",
             type="many-to-one"),
        dict(frm="client_assets_advisor", to="DP-013/Calendar Date",
             on="client_assets_advisor.period_end_date = calendar_date.calendar_date", type="many-to-one"),
        # Supervisory structure (DP-391)
        dict(frm="supervisory_assignment", to="DP-009/Employee",
             on="supervisory_assignment.supervised_person = employee.employee_id", type="many-to-one",
             warning="A person can have a primary and a secondary supervisor in force at once. Filter "
                     "supervisory_assignment_type = 'Primary' before grouping counts by supervisor, or a person is "
                     "counted under each."),
        dict(frm="supervisory_assignment", to="DP-192/Employee",
             on="supervisory_assignment.assigned_supervisor = employee.employee_id", type="many-to-one"),
        dict(frm="supervisory_assignment", to="DP-013/Office Location",
             on="supervisory_assignment.supervising_office = office_location.office_id", type="many-to-one"),
        dict(frm="firm_branch_office", to="DP-013/Office Location", on="firm_branch_office.office = office_location.office_id",
             type="one-to-one"),
        dict(frm="supervisory_hierarchy_link", to="DP-013/Office Location",
             on="supervisory_hierarchy_link.child_supervisory_unit = office_location.office_id (matched by value; GAP-03-015)",
             type="many-to-one"),
        dict(frm="principal_designation", to="firm_branch_office",
             on="principal_designation.designation_office = firm_branch_office.office", type="many-to-one"),
        dict(frm="principal_designation", to="DP-192/Employee",
             on="principal_designation.designated_principal = employee.employee_id", type="many-to-one"),
        dict(frm="principal_designation", to="DP-009/Individual Registration",
             on="principal_designation.qualifying_registration = individual_registration.license_id", type="many-to-one"),
        dict(frm="branch_registration", to="firm_branch_office",
             on="branch_registration.registered_office = firm_branch_office.office", type="many-to-one"),
        dict(frm="DP-009/Individual Registration", to="DP-009/Employee",
             on="individual_registration.registered_person = employee.employee_id", type="many-to-one",
             warning="A person holds many registrations (category x jurisdiction). Use registrations to filter or count "
                     "people with count(distinct); joining them to a person-level fact counts that fact once per "
                     "registration."),
        # Principal review (DP-398)
        dict(frm="supervisory_review", to="DP-009/Employee",
             on="supervisory_review.supervised_representative = employee.employee_id", type="many-to-one"),
        dict(frm="supervisory_review", to="DP-192/Employee",
             on="supervisory_review.reviewing_principal = employee.employee_id", type="many-to-one"),
        dict(frm="supervisory_review", to="DP-093/Account", on="supervisory_review.reviewed_account = account.account_id",
             type="many-to-one"),
        dict(frm="supervisory_review", to="DP-093/Account Feature",
             on="supervisory_review.reviewed_account_feature = account_feature.account_feature_id", type="many-to-one"),
        dict(frm="supervisory_review", to="sales_practice_alert",
             on="supervisory_review.source_sales_practice_alert = sales_practice_alert.sales_practice_alert_id",
             type="many-to-one"),
        dict(frm="supervisory_review", to="DP-013/Calendar Date",
             on="supervisory_review.review_completed_date = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="supervisory_review", to="supervisory_assignment",
             on="supervisory_review.supervised_representative = supervisory_assignment.supervised_person and "
                "supervisory_assignment_type = 'Primary' and the assignment is in force at review_completed_date "
                "(or the as-of date for open reviews)",
             type="many-to-one",
             warning="Without the Primary and in-force pins a review joins every supervisor the representative has had; "
                     "this join gives the supervising office of a review."),
        # Disclosure delivery (DP-399)
        dict(frm="disclosure_check", to="DP-093/Account", on="disclosure_check.checked_account = account.account_id",
             type="many-to-one"),
        dict(frm="disclosure_check", to="DP-240/Party", on="disclosure_check.checked_retail_investor = party.party_id",
             type="many-to-one"),
        dict(frm="disclosure_check", to="form_crs_filing",
             on="disclosure_check.form_crs_version_required = form_crs_filing.relationship_summary_version",
             type="many-to-one"),
        dict(frm="disclosure_check", to="account_disclosure_delivery",
             on="disclosure_check.account_delivery_evidence = account_disclosure_delivery (its key)", type="many-to-one"),
        dict(frm="disclosure_check", to="fee_disclosure_delivery",
             on="disclosure_check.fee_disclosure_evidence = fee_disclosure_delivery (its key)", type="many-to-one"),
        dict(frm="disclosure_check", to="DP-013/Calendar Date", on="disclosure_check.check_date = calendar_date.calendar_date",
             type="many-to-one"),
        dict(frm="account_disclosure_delivery", to="DP-093/Account",
             on="account_disclosure_delivery.disclosure_account = account.account_id", type="many-to-one"),
        dict(frm="account_disclosure_delivery", to="DP-093/Program Enrollment",
             on="account_disclosure_delivery.related_program_enrollment = program_enrollment.program_enrollment_id",
             type="many-to-one"),
        dict(frm="recipient_delivery", to="DP-093/Account", on="recipient_delivery.recipient_account = account.account_id",
             type="many-to-one"),
        dict(frm="fee_disclosure_delivery", to="DP-093/Account",
             on="fee_disclosure_delivery.fee_disclosure_account = account.account_id", type="many-to-one"),
        # Sales practice surveillance (DP-400)
        dict(frm="sales_practice_alert", to="surveillance_scenario",
             on="sales_practice_alert.alert_scenario = surveillance_scenario.scenario_id (version in force at "
                "alert_generated_date)", type="many-to-one"),
        dict(frm="sales_practice_alert", to="DP-009/Employee",
             on="sales_practice_alert.alerted_representative = employee.employee_id", type="many-to-one"),
        dict(frm="sales_practice_alert", to="DP-093/Account", on="sales_practice_alert.alert_account = account.account_id",
             type="many-to-one"),
        dict(frm="sales_practice_alert", to="DP-013/Calendar Date",
             on="sales_practice_alert.alert_generated_date = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="surveillance_scenario", to="DP-212/Model", on="surveillance_scenario.scenario_model = model.model_id",
             type="many-to-one"),
        dict(frm="alert_corrective_action", to="sales_practice_alert",
             on="alert_corrective_action.source_sales_practice_alert = sales_practice_alert.sales_practice_alert_id",
             type="many-to-one"),
        dict(frm="alert_corrective_action", to="supervisory_review",
             on="alert_corrective_action.source_supervisory_review = supervisory_review.supervisory_review_id",
             type="many-to-one"),
        dict(frm="alert_corrective_action", to="DP-009/Employee",
             on="alert_corrective_action.action_subject_representative = employee.employee_id", type="many-to-one"),
        # Controls, inspections and findings (DP-402)
        dict(frm="control_test", to="supervisory_control",
             on="control_test.tested_control = supervisory_control.supervisory_control_number", type="many-to-one"),
        dict(frm="control_test", to="DP-192/Employee", on="control_test.control_tester = employee.employee_id",
             type="many-to-one"),
        dict(frm="control_test", to="DP-013/Calendar Date",
             on="control_test.test_period_end_date = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="supervisory_control", to="wsp_policy", on="supervisory_control.governing_wsp_policy = wsp_policy.policy_id",
             type="many-to-one"),
        dict(frm="branch_inspection", to="firm_branch_office",
             on="branch_inspection.inspected_office = firm_branch_office.office (designation in force at inspection_date)",
             type="many-to-one"),
        dict(frm="branch_inspection", to="DP-192/Employee", on="branch_inspection.inspector = employee.employee_id",
             type="many-to-one"),
        dict(frm="branch_inspection", to="DP-013/Calendar Date",
             on="branch_inspection.inspection_date = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="supervisory_finding", to="branch_inspection",
             on="supervisory_finding.source_branch_inspection = branch_inspection.branch_inspection_id", type="many-to-one"),
        dict(frm="supervisory_finding", to="control_test",
             on="supervisory_finding.source_control_test = control_test.tested_control and the test period",
             type="many-to-one"),
        dict(frm="finding_corrective_action", to="supervisory_finding",
             on="finding_corrective_action.source_supervisory_finding = supervisory_finding.supervisory_finding_id",
             type="many-to-one",
             warning="A finding can have several corrective actions. Count findings with count(distinct "
                     "supervisory_finding_id) when grouping by an action column."),
        dict(frm="finding_corrective_action", to="DP-192/Employee",
             on="finding_corrective_action.action_owner = employee.employee_id", type="many-to-one"),
        dict(frm="heightened_supervision_plan", to="DP-009/Employee",
             on="heightened_supervision_plan.plan_supervised_representative = employee.employee_id", type="many-to-one"),
        dict(frm="heightened_supervision_plan", to="DP-192/Employee",
             on="heightened_supervision_plan.heightened_supervisor = employee.employee_id", type="many-to-one"),
        dict(frm="supervisory_attestation", to="DP-192/Employee", on="supervisory_attestation.attester = employee.employee_id",
             type="many-to-one"),
        # Conduct indicators (DP-404)
        dict(frm="conduct_indicator", to="DP-009/Employee", on="conduct_indicator.advisor_key = employee.employee_id",
             type="many-to-one"),
        dict(frm="conduct_indicator", to="firm_branch_office", on="conduct_indicator.office_key = firm_branch_office.office",
             type="many-to-one"),
        dict(frm="conduct_indicator", to="DP-004/Service Offering",
             on="conduct_indicator.offering_key = service_offering.offering_id", type="many-to-one"),
        dict(frm="conduct_indicator", to="DP-013/Calendar Date",
             on="conduct_indicator.indicator_month = calendar_date.calendar_date", type="many-to-one"),
        # Complaints (DP-414)
        dict(frm="complaint", to="DP-240/Party", on="complaint.complainant = party.party_id", type="many-to-one"),
        dict(frm="complaint", to="DP-093/Account", on="complaint.complaint_account = account.account_id", type="many-to-one"),
        dict(frm="complaint", to="DP-004/Share Class", on="complaint.product_share_class = share_class.share_class_id",
             type="many-to-one"),
        dict(frm="complaint", to="DP-009/Employee", on="complaint.associated_person_named = employee.employee_id",
             type="many-to-one"),
        dict(frm="complaint", to="firm_branch_office", on="complaint.complaint_office = firm_branch_office.office",
             type="many-to-one"),
        dict(frm="complaint", to="DP-013/Calendar Date", on="complaint.received_date = calendar_date.calendar_date",
             type="many-to-one"),
        dict(frm="DP-009/Coverage Assignment", to="DP-093/Account",
             on="coverage_assignment.covered_account = account.account_id and primary_coverage_indicator = 'Y' and the "
                "assignment is in force at the date of the fact (complaint received_date)",
             type="many-to-one",
             warning="Only the primary coverage assignment in force at the complaint's received date keeps one advisor "
                     "of record per account; other coverage roles would count a complaint under each advisor."),
        dict(frm="DP-009/Coverage Assignment", to="DP-009/Employee",
             on="coverage_assignment.covering_advisor = employee.employee_id", type="many-to-one"),
        dict(frm="DP-093/Program Enrollment", to="DP-093/Account", on="program_enrollment.enrolled_account = account.account_id",
             type="many-to-many",
             warning="An account can be enrolled in more than one offering over time (and, for some programs, at once). "
                     "Grouping complaints by offering counts a complaint under each active enrollment of its account, "
                     "so offering rows do not add up to Complaints Received; self-directed accounts form their own row."),
        dict(frm="DP-093/Program Enrollment", to="DP-004/Service Offering",
             on="program_enrollment.enrolled_service_offering = service_offering.offering_id", type="many-to-one"),
        dict(frm="complaint_interaction", to="DP-093/Account",
             on="complaint_interaction.interaction_account = account.account_id", type="many-to-one"),
        dict(frm="survey_response", to="complaint", on="survey_response.complaint_referral = complaint.complaint_id",
             type="many-to-one"),
        # Communications review (DP-036)
        dict(frm="compliance_review", to="asset_version", on="compliance_review.communication_asset = asset_version (its key)",
             type="many-to-one"),
        dict(frm="compliance_review", to="DP-009/Employee", on="compliance_review.submitted_by = employee.employee_id",
             type="many-to-one"),
        dict(frm="compliance_review", to="DP-013/Calendar Date",
             on="compliance_review.submission_date_key = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="compliance_review", to="DP-004/Share Class",
             on="compliance_review.products_featured contains share_class.share_class_id", type="many-to-many",
             warning="A communication can feature several share classes. Grouping reviews by share class counts the "
                     "review under each one, so share class rows do not add up to the number of reviews."),
        dict(frm="compliance_review", to="DP-004/Service Offering",
             on="compliance_review.services_featured = service_offering.offering_id", type="many-to-one"),
        dict(frm="track_record", to="compliance_review",
             on="track_record links to its review (DP-036's borrowed review key)", type="many-to-one"),
        dict(frm="review_step", to="compliance_review", on="review_step's review key = compliance_review.review_id",
             type="many-to-one"),
        dict(frm="review_step", to="DP-009/Employee", on="review_step.reviewer = employee.employee_id", type="many-to-one"),
        dict(frm="compliance_approval", to="compliance_review",
             on="compliance_approval's review key = compliance_review.review_id", type="many-to-one",
             warning="A review can have several approval decisions (approved, then withdrawn). Use the latest decision "
                     "per review when counting reviews by approval status."),
        dict(frm="compliance_approval", to="DP-009/Employee",
             on="compliance_approval.approving_principal = employee.employee_id", type="many-to-one"),
        dict(frm="compliance_approval", to="DP-009/Individual Registration",
             on="compliance_approval.approving_principal_license = individual_registration.license_id", type="many-to-one"),
        dict(frm="finra_filing", to="compliance_review", on="finra_filing's review key = compliance_review.review_id",
             type="many-to-one"),
        dict(frm="asset_compliance_reference", to="asset_version",
             on="asset_compliance_reference's asset version key = asset_version (its key)", type="many-to-one"),
        dict(frm="asset_compliance_reference", to="compliance_review",
             on="asset_compliance_reference's compliance review reference = compliance_review.review_id",
             type="many-to-one"),
        # Gifts and non-cash compensation (DP-038)
        dict(frm="ge_item", to="DP-009/Employee", on="ge_item.giver = employee.employee_id", type="many-to-one"),
        dict(frm="ge_item", to="DP-240/Party", on="ge_item.recipient_individual = party.party_id", type="many-to-one"),
        dict(frm="ge_item", to="DP-013/Calendar Date", on="ge_item.benefit_date = calendar_date.calendar_date",
             type="many-to-one"),
        dict(frm="ge_approval", to="ge_item", on="ge_approval's item key = ge_item.gne_id", type="many-to-one",
             warning="An item can have more than one approval decision. Use the latest decision per item."),
        dict(frm="DP-009/Advisor Role Assignment", to="DP-009/Employee",
             on="advisor_role_assignment.role_advisor = employee.employee_id and the role is in force at "
                "ge_item.benefit_date", type="many-to-many",
             warning="A giver can hold several advisor roles in force at once. Grouping G&E items by advisor role "
                     "counts an item under each role, so role rows do not add up to the items given."),
        # Registrations and licensing (DP-039, restricted)
        dict(frm="person_compliance_status", to="DP-009/Employee",
             on="person_compliance_status.registered_person = employee.employee_id", type="many-to-one"),
        dict(frm="person_compliance_status", to="DP-013/Calendar Date",
             on="person_compliance_status.status_date_key = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="exam_result", to="DP-009/Employee", on="exam_result.examined_person = employee.employee_id",
             type="many-to-one"),
        dict(frm="registration_filing", to="DP-009/Employee", on="registration_filing.filed_for_person = employee.employee_id",
             type="many-to-one"),
        dict(frm="disclosure_event", to="DP-009/Employee", on="disclosure_event.disclosed_person = employee.employee_id",
             type="many-to-one"),
        dict(frm="ce_requirement", to="DP-009/Employee", on="ce_requirement.ce_person = employee.employee_id",
             type="many-to-one"),
        # Communications capture and surveillance (DP-078)
        dict(frm="employee_capture_day", to="DP-009/Employee",
             on="employee_capture_day.monitored_employee = employee.employee_id", type="many-to-one"),
        dict(frm="employee_capture_day", to="DP-013/Calendar Date",
             on="employee_capture_day.capture_date_key = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="captured_communication", to="approved_channel",
             on="captured_communication.capture_channel = approved_channel.channel_type (approval in force at "
                "communication_timestamp)", type="many-to-one"),
        dict(frm="captured_communication", to="retention_rule_dim",
             on="captured_communication.retention_rule = retention_rule_dim.retention_rule_id", type="many-to-one"),
        dict(frm="captured_communication", to="DP-009/Employee",
             on="captured_communication.captured_employee = employee.employee_id", type="many-to-one"),
        dict(frm="comms_surveillance_alert", to="captured_communication",
             on="comms_surveillance_alert.flagged_communication = captured_communication.communication_record_id",
             type="many-to-one"),
        dict(frm="comms_surveillance_alert", to="DP-009/Employee",
             on="comms_surveillance_alert.alert_monitored_employee = employee.employee_id", type="many-to-one"),
        dict(frm="DP-009/Employee", to="DP-013/Internal Legal Entity",
             on="employee.employing_legal_entity = internal_legal_entity.legal_entity_id", type="many-to-one"),
        # Incentive governance (DP-390)
        dict(frm="incentive_earnings", to="DP-009/Employee",
             on="incentive_earnings.statement_participant = employee.employee_id", type="many-to-one"),
        dict(frm="incentive_earnings", to="incentive_component",
             on="incentive_earnings.earning_component = incentive_component.component_id", type="many-to-one"),
        dict(frm="incentive_earnings", to="DP-013/Calendar Date",
             on="incentive_earnings.statement_period_end = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="incentive_component", to="incentive_plan",
             on="incentive_component.parent_incentive_plan = incentive_plan.incentive_plan_id", type="many-to-one"),
        dict(frm="plan_participation", to="DP-009/Employee", on="plan_participation.plan_participant = employee.employee_id",
             type="many-to-one"),
        dict(frm="plan_participation", to="incentive_plan", on="plan_participation.assigned_plan = incentive_plan.incentive_plan_id",
             type="many-to-one",
             warning="An advisor can participate in several plans in a year. Group Earned vs Target % by plan, never "
                     "add targets across an advisor's plans to a statement total."),
        dict(frm="recognition_award", to="DP-009/Employee", on="recognition_award.award_recipient = employee.employee_id",
             type="many-to-one"),
        dict(frm="incentive_conflict_review", to="incentive_component",
             on="incentive_conflict_review.reviewed_incentive_plan_component = incentive_component.component_id",
             type="many-to-one"),
        dict(frm="incentive_conflict_review", to="recognition_award",
             on="incentive_conflict_review.reviewed_recognition_award = recognition_award.recognition_award_id",
             type="many-to-one"),
    ],

    hierarchies=[
        dict(name="Branch network", levels=["firm_branch_office.branch_type", "firm_branch_office.office"]),
        dict(name="Supervisory control", levels=["supervisory_control.supervised_activity",
                                                 "supervisory_control.supervisory_control_number"]),
        dict(name="Surveillance scenario", levels=["surveillance_scenario.scenario_type", "surveillance_scenario.scenario_id"]),
        dict(name="Complaint classification", levels=["complaint.complaint_category", "complaint.finra_problem_code",
                                                      "complaint.root_cause"]),
        dict(name="Incentive plan", levels=["incentive_plan.incentive_plan_type", "incentive_plan.incentive_plan_name",
                                            "incentive_component.component_measure"]),
    ],

    metrics=[
        # --- Certified and sibling metrics, referenced ------------------------------------------------------------------
        dict(name="Client Assets", ref="SM-20/Client Assets",
             note="Read from client_assets_advisor (Dimension Type Advisor, locked month-ends) as the denominator of the "
                  "per-USD-1-billion complaint rate; never added to anything published here."),
        dict(name="Households", ref="SM-20/Households",
             note="The advisor slice at the month-end, the denominator of the per-1,000-household conduct rates "
                  "(DP-404 reads it from the same locked snapshot)."),
        dict(name="Recommendations Without Best-Interest Evidence", ref="SM-22/Recommendations Without Best-Interest Evidence",
             note="Acceptance question 3, first half: DP-334's Evidence Gap Flag, defined once in SM-22. Sliced here by "
                  "advisor, office and offering through conduct_indicator.recommendations_without_bi_evidence (DP-404 "
                  "reads it as published, never re-derived). " + _MIN10),
        dict(name="Evidence Gap Rate %", ref="SM-22/Evidence Gap Rate %",
             note="Recomputed from SM-22's counts for each slice; DP-404's row rate is hidden."),
        dict(name="Rollovers Without PTE 2020-02 Documentation", ref="SM-22/Rollovers Without PTE 2020-02 Documentation",
             note="Acceptance question 3, second half: DP-335's PTE Documentation Gap Flag, defined once in SM-22; "
                  "sliced by advisor and office through conduct_indicator.rollovers_without_pte_documentation. " + _MIN10),
        dict(name="PTE Documentation Gap Rate %", ref="SM-22/PTE Documentation Gap Rate %",
             note="Recomputed from SM-22's counts for each slice; DP-404's row rate is hidden."),
        dict(name="Active Money Movement Holds", ref="SM-24/Active Money Movement Holds",
             note="Acceptance question 7: filter Hold Type = Fraud. SM-24 publishes DP-302's non-special holds only "
                  "(Rule 2165 and other special-category hold reasons are suppressed, CD-344), so elder-exploitation holds "
                  "are not in this count."),
        dict(name="Held Amount", ref="SM-24/Held Amount",
             note="Acceptance question 7: the amount of the movements on the published (non-special) holds, one "
                  "currency at a time."),

        # --- DP-391 Supervisory structure ------------------------------------------------------------------------------
        _asof("Active Branch Designations",
              "count(firm_branch_office rows) where branch_status = 'Active' and the designation is in force at the as-of date",
              ("DP-391", "Active Branch Designations"), "Branch offices, OSJs and locations designated and active."),
        _asof("Branches Without Form BR Registration",
              "count(active firm_branch_office rows) with branch_type in ('Office of Supervisory Jurisdiction', 'Branch "
              "Office') and no branch_registration with a branch_crd_number and branch_closing_date empty",
              ("DP-391", "Branches Without Form BR Registration"),
              "Active branches and OSJs with no open Form BR registration."),
        _asof("Registered Branch Type Mismatches",
              "count(active firm_branch_office rows) whose latest branch_registration.registered_branch_type differs "
              "from firm_branch_office.branch_type", ("DP-391", "Registered Branch Type Mismatches"),
              "Active designations whose registered branch type differs from the designated type."),
        _asof("Closed Registrations Still Designated",
              "count(firm_branch_office rows) with branch_status = 'Active' whose branch_registration has "
              "branch_closing_date before the as-of date or whose latest form_br_filing_type is a closing filing",
              ("DP-391", "Closed Registrations Still Designated"),
              "Offices still designated active although their Form BR registration is closed."),
        _count("Representatives Without Qualified Supervisor",
               "count(distinct DP-009 Individual Registration.registered_person) with an Approved representative "
               "registration and no supervisory_assignment in force at the as-of date, or whose assigned_supervisor "
               "holds no Approved principal registration", ("DP-391", "Representatives Without Qualified Supervisor"),
               "Registered representatives with no supervisor in force or a supervisor who is not a qualified principal.",
               agg="count_distinct", note=_MIN10),
        _count("Supervisors Without Principal Registration",
               "count(distinct supervisory_assignment.assigned_supervisor) of assignments in force with no Approved "
               "principal-category DP-009 Individual Registration", ("DP-391", "Supervisors Without Principal Registration"),
               "Supervisors of record who hold no approved principal registration.", agg="count_distinct"),
        _count("Principal Span of Supervision",
               "per assigned_supervisor: count(distinct supervised_person) over Primary assignments in force; shown as the "
               "per-principal value and as the median and maximum across principals, recomputed for each slice",
               ("DP-391", "Principal Span of Supervision"),
               "How many people each principal supervises, with the median and maximum.", agg="non_additive",
               note=_MIN10),
        _count("Principals Over Span Limit",
               "count(distinct assigned_supervisor) whose Principal Span of Supervision exceeds 25 (tailoring lever)",
               ("DP-391", "Principals Over Span Limit"),
               "Principals supervising more people than the span limit.", agg="count_distinct", note=_MIN10),
        _asof("OSJs Without Designated Principal",
              "count(active firm_branch_office rows) with branch_type = 'Office of Supervisory Jurisdiction' and no "
              "principal_designation in force with principal_designation_type = 'OSJ Principal' for that office",
              ("DP-391", "OSJs Without Designated Principal"), "OSJs with no designated OSJ principal."),
        _asof("Designations Without Qualifying Registration",
              "count(principal_designation rows in force) whose qualifying_registration is empty or resolves to a DP-009 "
              "Individual Registration with registration_status not 'Approved'",
              ("DP-391", "Designations Without Qualifying Registration"),
              "Principal designations not backed by an approved registration."),
        _asof("Supervisory Units Without Parent",
              "count(distinct supervisory_hierarchy_link.child_supervisory_unit in force) with no parent link, other than "
              "the home office root unit", ("DP-391", "Supervisory Units Without Parent"),
              "Supervisory units left outside the supervisory tree.", note="Units are matched by value (GAP-03-015)."),
        _asof("Residential Supervisory Locations",
              "count(active firm_branch_office rows) with residential_supervisory_location = 'Y', with those with "
              "supervises_non_branch_locations = 'Y', by office state (DP-013 Office Location)",
              ("DP-391", "Residential Supervisory Locations"),
              "Residential supervisory locations under FINRA Rule 3110.19.", note=_MIN10),
        _asof("Heightened Supervision Assignments",
              "count(supervisory_assignment rows in force) with heightened_supervision_plan_reference populated",
              ("DP-391", "Heightened Supervision Assignments"),
              "Supervisory assignments carrying a heightened supervision plan.",
              note="Presence of a plan only; the basis is never read (CD-344). " + _MIN10),

        # --- DP-398 Principal review -----------------------------------------------------------------------------------
        _count("Supervisory Reviews Completed", "count(supervisory_review rows) where review_completed_date is in the period",
               ("DP-398", "Supervisory Reviews Completed"), "Principal reviews completed in the period.", note=_MIN10),
        _asof("Open Principal Review Queue",
              "count(supervisory_review rows) where review_completed_date is null, on the daily snapshot of the as-of date",
              ("DP-398", "Open Review Queue"), "Principal reviews waiting for a decision.", note=_MIN10),
        _count("Principal Review Aging Median (Business Days)",
               "median over reviews of business days (DP-013 calendar) from the subject timestamp (recommendation "
               "presented, application received, feature approval or order received) to review_completed_date, or to the "
               "as-of date for open reviews; recomputed for each slice",
               ("DP-398", "Review Aging (Business Days)"), "Typical business days a review takes.", agg="non_additive",
               note="Aging starts at the subject's own timestamp: the review has no queued timestamp (taxonomy gap)."),
        _count("Principal Review Aging P90 (Business Days)",
               "90th percentile of the same business-day durations, recomputed for each slice",
               ("DP-398", "Review Aging (Business Days)"), "Business days within which 90% of reviews are decided.",
               agg="non_additive"),
        _count("Reviews Past Review Standard",
               "count(supervisory_review rows) open or completed in the period whose aging exceeds the standard of their "
               "type (recommendation and rollover 2 business days, new account 3, account feature and options 1, "
               "correspondence 5)", ("DP-398", "Reviews Past Review Standard"),
               "Reviews that took longer than the standard for their type.",
               note="The standards are drafting thresholds (tailoring lever). " + _MIN10),
        _ratio("Review Exception Rate %",
               "count(completed supervisory_review rows in the period) with review_outcome in ('Rejected', 'Approved with "
               "Exception', 'Escalated')", "[Supervisory Reviews Completed]", ("DP-398", "Review Exception Rate %"),
               "Share of completed reviews rejected, approved with exception or escalated.",
               note="DP-404's per-row copy is hidden; this is the one rate. " + _MIN10),
        _count("Reviews Escalated",
               "count(completed supervisory_review rows) with review_outcome = 'Escalated', and of rows with "
               "source_sales_practice_alert populated", ("DP-398", "Reviews Escalated"),
               "Reviews escalated, and reviews raised from a sales practice alert."),
        _count("Reviews Recording Evidence Exceptions",
               "count(completed recommendation and rollover supervisory_review rows) with profile_current = 'N', "
               "alternatives_evidence_present = 'N', cost_evidence_present = 'N' or evidence exceptions recorded",
               ("DP-398", "Reviews Recording Evidence Exceptions"),
               "Reviews in which the principal recorded a best-interest evidence exception.",
               note="The outcome as the principal recorded it, published for DP-334; it is not SM-22's Recommendations "
                    "Without Best-Interest Evidence and is never added to it."),
        _count("Rollover Reviews Recording Missing PTE Documentation",
               "count(completed supervisory_review rows) with supervisory_review_type = 'Rollover' and "
               "(rollover_analysis_reviewed is empty or pte_documentation_present = 'N')",
               ("DP-398", "Rollover Reviews Recording Missing PTE Documentation"),
               "Rollover reviews in which the principal recorded missing PTE 2020-02 documentation.",
               note="As recorded; SM-22's Rollovers Without PTE 2020-02 Documentation is the evidence answer."),
        _count("Reviews by Unassigned Principal",
               "count(completed supervisory_review rows) whose reviewing_principal is not the assigned_supervisor of a "
               "supervisory_assignment of the supervised_representative in force at review_completed_date",
               ("DP-398", "Reviews by Unassigned Principal"),
               "Reviews decided by a principal who is not the representative's supervisor of record."),
        _count("Self-Reviews", "count(supervisory_review rows) where reviewing_principal = supervised_representative",
               ("DP-398", "Self-Reviews"), "Reviews in which the principal reviewed their own business (Rule 3110(b)(6))."),
        _count("Options Approvals Reviewed by Level",
               "count(completed supervisory_review rows) whose reviewed_account_feature is a DP-093 Account Feature with "
               "feature_type = 'Options', by options approval level, with the share completed before the account's first "
               "options order", ("DP-398", "Options Approvals Reviewed by Level"),
               "Options approvals reviewed by a principal, by approval level (FINRA Rule 2360(b)(16)).",
               note="A firm without options drops this metric (tailoring lever)."),
        _count("Best Execution Reviews Completed",
               "count(completed supervisory_review rows) with supervisory_review_type = 'Best Execution', by subject "
               "(reviewed_routing_rule, reviewed_execution_venue or reviewed_client_order) and review_outcome",
               ("DP-398", "Best Execution Reviews Completed"), "Best execution reviews completed, by subject."),
        _ratio("Reviews per Principal", "[Supervisory Reviews Completed]",
               "count(distinct supervisory_review.reviewing_principal) with a completed review in the period",
               ("DP-398", "Reviews per Principal"), "Average completed reviews per reviewing principal.",
               note="Show beside Open Principal Review Queue by principal. " + _MIN10),

        # --- DP-399 Disclosure delivery --------------------------------------------------------------------------------
        _count("Disclosure Checks Performed", "count(disclosure_check rows) where check_date is in the period",
               ("DP-399", "Disclosure Checks Performed"), "Disclosure delivery checks performed."),
        _ratio("Disclosure Check Failure Rate %",
               "count(disclosure_check rows in the period) with check_result in ('Missing', 'Late', 'Wrong Version', "
               "'Failed Delivery')", "[Disclosure Checks Performed]", ("DP-399", "Disclosure Check Failure Rate %"),
               "Share of disclosure checks that failed."),
        _count("Missing Disclosures", "count(disclosure_check rows in the period) with check_result = 'Missing'",
               ("DP-399", "Missing Disclosures"), "Checks that found no disclosure delivered, by the evidence left empty."),
        _count("Late Disclosures",
               "count(disclosure_check rows in the period) whose evidence delivery date (account_disclosure_delivery."
               "disclosure_delivered_date, or a recipient_delivery with status 'Delivered' and no returned_mail_date) is "
               "after trigger_date for account opening and recommendation triggers, or more than 30 days after it for a "
               "material change", ("DP-399", "Late Disclosures"), "Disclosures delivered after their deadline."),
        _count("Wrong Form CRS Version Delivered",
               "count(disclosure_check rows) whose form_crs_version_required differs from the disclosure_version of the "
               "Form CRS account_disclosure_delivery relied on", ("DP-399", "Wrong Form CRS Version Delivered"),
               "Checks where the client received an outdated Form CRS."),
        _count("Failed or Returned Deliveries Relied On",
               "count(disclosure_check rows) whose communication evidence resolves to a recipient_delivery with "
               "recipient_delivery_status = 'Failed' or returned_mail_date populated",
               ("DP-399", "Failed or Returned Deliveries Relied On"),
               "Checks that relied on a failed or returned delivery."),
        _count("Accounts Opened Without Form CRS",
               "count(distinct DP-093 Account.account_id) of retail account types with account_open_date in the period "
               "and no account_disclosure_delivery with disclosure_type = 'Form CRS' delivered on or before the open date",
               ("DP-399", "Accounts Opened Without Form CRS"),
               "Retail accounts opened before Form CRS was delivered.", agg="count_distinct"),
        _ratio("Account Opening Check Coverage %",
               "count(disclosure_check rows in the period) with disclosure_trigger = 'Account Opening'",
               "count(distinct DP-093 Account.account_id) of retail account types opened in the period",
               ("DP-399", "Account Opening Check Coverage %"), "Share of new retail accounts with an opening check."),
        _count("Form CRS Posting Lag (Days)",
               "per Form CRS filing: calendar days from form_crs_filing.filing_submitted_timestamp to "
               "posted_to_website_date; shown per filing and as the maximum across filings",
               ("DP-399", "Form CRS Posting Lag (Days)"), "Days between filing Form CRS and posting it on the website.",
               agg="non_additive"),
        _count("Form CRS Amendment Re-Delivery Outstanding",
               "count(distinct disclosure_check.checked_retail_investor) with disclosure_trigger = 'Material Change' for an "
               "amended relationship_summary_version and no delivery of that version within 60 days of posted_to_website_date",
               ("DP-399", "Form CRS Amendment Re-Delivery Outstanding"),
               "Retail investors still owed an amended Form CRS after 60 days.", agg="count_distinct"),
        _count("Fee Changes Without Advance Disclosure",
               "count(disclosure_check rows) whose fee_disclosure_delivery has fee_disclosure_delivered_date after "
               "fee_change_effective_date, or no fee disclosure for the schedule before that date",
               ("DP-399", "Fee Changes Without Advance Disclosure"), "Fee changes applied before they were disclosed."),
        _count("Disclosure Re-Delivery Population",
               "count(distinct disclosure_check.checked_retail_investor) with an open failed check (check_result not 'Pass' "
               "and no later passing check for the same trigger), by disclosure_trigger",
               ("DP-399", "Re-Delivery Population"),
               "Retail investors to whom compliance must send a disclosure again.", agg="count_distinct",
               note="The list itself is visible to retail conduct compliance only (client keys)."),

        # --- DP-400 Sales practice surveillance ------------------------------------------------------------------------
        _asof("Active Surveillance Scenarios",
              "count(surveillance_scenario versions) with scenario_status = 'Active' in force at the as-of date",
              ("DP-400", "Active Scenarios"), "Sales practice surveillance scenarios running."),
        _count("Sales Practice Alerts Generated", "count(sales_practice_alert rows) with alert_generated_date in the period",
               ("DP-400", "Alerts Generated"), "Sales practice alerts generated.", note=_MIN10),
        _asof("Open Sales Practice Alerts",
              "count(sales_practice_alert rows) with alert_disposition empty or 'Open' at the as-of date",
              ("DP-400", "Open Alerts"), "Sales practice alerts not yet dispositioned.",
              note="Mean and maximum age: Open Sales Practice Alert Age. " + _MIN10),
        _count("Open Sales Practice Alert Age (Days)",
               "mean and maximum calendar days since alert_generated_date over open alerts at the as-of date, recomputed "
               "for each slice", ("DP-400", "Open Alerts"), "How long open alerts have been waiting.", agg="non_additive"),
        _asof("Alerts Past Review Standard",
              "count(open sales_practice_alert rows) more than 30 calendar days after alert_generated_date; by the alerted "
              "representative's supervisor through supervisory_assignment (Primary, in force). Roles without alert rows "
              "read sum(conduct_indicator.alerts_past_review_standard) at the month-end, the same published count",
              ("DP-400", "Alerts Past Review Standard"), "Open alerts older than the 30-day review standard.",
              note=_MIN10),
        _count("Alert Disposition Mix",
               "count(sales_practice_alert rows dispositioned in the period) by alert_disposition",
               ("DP-400", "Alert Disposition Mix"), "How alerts were closed: no further action, explained, escalated or "
               "corrective action.",
               note="The disposition period comes from the alert's status history at load (no disposition date)."),
        _ratio("Alert to Corrective Action Rate %",
               "count(distinct dispositioned sales_practice_alert) with an alert_corrective_action whose "
               "source_sales_practice_alert is the alert", "count(distinct sales_practice_alert dispositioned in the period)",
               ("DP-400", "Alert to Corrective Action Rate %"), "Share of dispositioned alerts that led to corrective action."),
        _asof("Corrective Actions Overdue",
              "count(alert_corrective_action rows) with action_due_date before the as-of date and action_status not "
              "'Completed'. Roles without action rows read sum(conduct_indicator.corrective_actions_overdue) at the "
              "month-end", ("DP-400", "Corrective Actions Overdue"),
              "Corrective actions raised from alerts or reviews and not completed on time.",
              note="Finding actions are counted separately (Finding Corrective Actions Overdue); the two are not added "
                   "(see open decisions). " + _MIN10),
        _count("Corrective Actions With Client Remediation",
               "count(alert_corrective_action rows opened in the period) with client_remediation populated",
               ("DP-400", "Corrective Actions With Client Remediation"),
               "Corrective actions that include remediation to the client."),
        _count("Representatives Under Heightened Supervision",
               "count(distinct heightened_supervision_plan.plan_supervised_representative) with a plan in force at the "
               "as-of date", ("DP-400", "Representatives Under Heightened Supervision"),
               "Representatives on a heightened supervision plan.", agg="count_distinct",
               note="Read from DP-402's table of the same 08 object (one heightened supervision table). " + _MIN10),
        _count("Repeat-Alert Representatives",
               "count(distinct sales_practice_alert.alerted_representative) with three or more alerts with alert_disposition "
               "not 'No Further Action' in the 12 months to the as-of date, split by whether a heightened supervision plan "
               "is in force", ("DP-400", "Repeat-Alert Representatives"),
               "Representatives with repeated substantive alerts.", agg="count_distinct", note=_MIN10),
        _asof("Scenarios Due for Threshold Review",
              "count(active surveillance_scenario versions) whose scenario_effective_from is more than 12 months before "
              "the as-of date, or whose scenario_model's DP-212 Model is no longer in validated use",
              ("DP-400", "Scenarios Due for Threshold Review"), "Scenarios whose thresholds are due for review."),
        _ratio("Sales Practice Alerts per 1,000 Accounts", "[Sales Practice Alerts Generated] x 1,000",
               "count(distinct DP-093 Account.account_id) open in the period", ("DP-400", "Alerts per 1,000 Accounts"),
               "Alert rate per 1,000 open accounts, by scenario and registration type."),

        # --- DP-402 Supervisory controls, inspections and findings -----------------------------------------------------
        _asof("Active Supervisory Controls", "count(supervisory_control rows) with control_status = 'Active'",
              ("DP-402", "Active Supervisory Controls"), "Supervisory controls in the written supervisory procedures."),
        _ratio("Controls Tested in Year %",
               "count(distinct active supervisory_control) with a control_test whose test_period_end_date is in the Rule "
               "3120 report year", "[Active Supervisory Controls]", ("DP-402", "Controls Tested in Year %"),
               "Share of active controls tested in the report year."),
        _ratio("Control Test Failure Rate %",
               "count(control_test rows in the year) with test_result in ('Fail', 'Partially Effective')",
               "count(control_test rows in the year)", ("DP-402", "Control Test Failure Rate %"),
               "Share of control tests that failed or were partially effective."),
        _count("Tests Requiring WSP Amendment", "count(control_test rows in the year) with wsp_amendment_required = 'Y'",
               ("DP-402", "Tests Requiring WSP Amendment"), "Control tests that require a procedure change."),
        _asof("Controls on Inactive WSP Policy",
              "count(active supervisory_control rows) whose wsp_policy.policy_status is not 'Active'",
              ("DP-402", "Controls on Inactive WSP Policy"), "Active controls governed by a retired procedure."),
        _asof("Branch Inspections Overdue",
              "count(active firm_branch_office designations) whose latest branch_inspection.inspection_date is older than "
              "its inspection_cycle (OSJ and supervising branch annually, non-supervising branch every three years)",
              ("DP-402", "Inspections Overdue"), "Branches overdue for their Rule 3110(c) inspection."),
        _ratio("Branch Inspections On Cycle %",
               "count(active firm_branch_office designations) whose latest inspection is within its inspection_cycle",
               "[Active Branch Designations]", ("DP-402", "Inspections On Cycle %"),
               "Share of active branches inspected on cycle."),
        _count("Inspection Report Lag Median (Days)",
               "median calendar days from inspection_date to inspection_report_date for inspections in the year, "
               "recomputed for each slice", ("DP-402", "Inspection Report Lag (Days)"),
               "Typical days from inspection to report.", agg="non_additive", note=_MIN10),
        _ratio("Remote Inspection Share %", "count(branch_inspection rows in the year) with remote_inspection = 'Y'",
               "count(branch_inspection rows in the year)", ("DP-402", "Remote Inspection Share %"),
               "Share of inspections done remotely (FINRA Rule 3110.18)."),
        _asof("Open Findings by Severity",
              "count(supervisory_finding rows) with finding_status not 'Closed', by finding_severity and finding_source. "
              "Roles without finding rows read sum(conduct_indicator.open_findings) at the month-end",
              ("DP-402", "Open Findings by Severity"), "Supervisory findings not yet closed.", note=_MIN10),
        _asof("Findings Without Corrective Action",
              "count(open supervisory_finding rows) with finding_severity in ('High', 'Medium') and no "
              "finding_corrective_action", ("DP-402", "Findings Without Corrective Action"),
              "Open high or medium findings with no corrective action."),
        _asof("Finding Corrective Actions Overdue",
              "count(finding_corrective_action rows) with finding_action_due_date before the as-of date and "
              "finding_action_status not 'Completed'", ("DP-402", "Finding Corrective Actions Overdue"),
              "Corrective actions on findings not completed on time.",
              note="Findings have no owner or due date of their own; both come from the action (taxonomy gap)."),
        _asof("Heightened Supervision Plans Without Supervisor",
              "count(heightened_supervision_plan rows in force) with heightened_supervisor empty, beside the count of "
              "plans in force", ("DP-402", "Heightened Supervision Plans Without Supervisor"),
              "Heightened supervision plans with no named supervisor.", note=_MIN10),
        _count("Rule 3120 Report Delivered",
               "Y when at least one control_test of the report year has rule_3120_report_date on or before the firm's "
               "report deadline, with that date; shown per report year", ("DP-402", "Rule 3120 Report Delivered"),
               "Whether the annual Rule 3120 supervisory control report was delivered on time.", agg="non_additive"),
        _count("Rule 3130 Certification Complete",
               "Y when a supervisory_attestation of attestation_type = 'Rule 3130 CEO Certification' for the year has "
               "attestation_status = 'Completed', with attestation_completed_date; shown per year",
               ("DP-402", "Rule 3130 Certification Complete"),
               "Whether the CEO's annual Rule 3130 certification is complete.", agg="non_additive"),

        # --- DP-404 Conduct risk indicators ------------------------------------------------------------------------------
        _ratio("Sales Practice Alerts per 1,000 Households",
               "[Sales Practice Alerts Generated] in the month by alerted representative x 1,000",
               "[Households] of the same advisor at the month-end (SM-20, Dimension Type Advisor)",
               ("DP-404", "Sales Practice Alerts per 1,000 Households (from DP-400)"),
               "Alerts per 1,000 households in each advisor's book.",
               note="Advisor and business line slices only: DP-008 publishes no office or offering slice. " + _MIN10),
        _ratio("Complaints per 1,000 Households",
               "[Complaints Received] in the month by associated_person_named x 1,000",
               "[Households] of the same advisor at the month-end", ("DP-404", "Complaints per 1,000 Households (from DP-414)"),
               "Complaints naming an advisor per 1,000 households in their book.",
               note="By office as a count only (DP-008 has no office slice). " + _MIN10),
        _ratio("Complaints per USD 1 Billion Client Assets",
               "[Complaints Received] in the month for the advisor or business line x 1,000,000,000",
               "[Client Assets] of the same slice at the month-end (client_assets_advisor)",
               ("DP-404", "Complaints per USD 1 Billion Client Assets (from DP-414)"),
               "Complaints per USD 1 billion of certified client assets.",
               note="Combines DP-414 counts with SM-20's certified Client Assets, lined up by advisor and month, never "
                    "joined fact to fact."),
        _asof("Clients Under Protection",
              "sum(conduct_indicator.clients_under_protection) at the month-end, by advisor (each advisor's row counts "
              "distinct protected parties in their primary-coverage book); suppressed below 10",
              ("DP-404", "Clients Under Protection (from DP-322)"),
              "Clients in the advisor's book with a protection flag (specified adult, trusted contact concern or "
              "exploitation hold), as an aggregate only.",
              note="Acceptance question 7 by aggregate. Special category (CD-344): DP-322's flag is never shown per "
                   "client and senior investor cases stay in DP-403's restricted view. Summing advisors double counts a "
                   "client covered by two advisors only if coverage is not primary; DP-404 counts primary coverage. "
                   + _MIN10),
        _count("Advisors Breaching Two or More Indicators",
               "count(distinct conduct_indicator.advisor_key) in the month for whom at least two hold: Evidence Gap Rate % "
               "above 5%, PTE Documentation Gap Rate % above 5%, Sales Practice Alerts per 1,000 Households above 20, "
               "Complaints per 1,000 Households above 5, alerts past review standard above 3, corrective actions overdue "
               "above 0", ("DP-404", "Advisors Breaching Two or More Indicators"),
               "Advisors flagged on at least two conduct indicators in the month (a rules-based screen, not a score).",
               agg="count_distinct", note="Thresholds are DP-404's reference defaults (tailoring lever). " + _MIN10),

        # --- DP-414 Complaints -------------------------------------------------------------------------------------------
        _count("Complaints Received", "count(complaint rows) with received_date in the period",
               ("DP-414", "Complaints Received"), "Complaints received, by category, source and written or oral.",
               note=_MIN10),
        _asof("Open Complaints", "count(complaint rows) with complaint_status not 'Closed' at the as-of date",
              ("DP-414", "Open Complaints"), "Complaints still open, with their mean age."),
        _asof("Final Responses Past Due",
              "count(complaint rows) with final_response_date after final_response_due_date, or open with "
              "final_response_due_date before the as-of date", ("DP-414", "Final Responses Past Due"),
              "Complaints whose final response was or is late."),
        _count("Median Days to Final Response",
               "median calendar days from received_date to final_response_date for complaints with a final response in "
               "the period, recomputed for each slice", ("DP-414", "Median Days to Final Response"),
               "Typical days to a final response.", agg="non_additive",
               note="Final Response Date stands in for a closed date (GAP-08-028)."),
        _count("Complaint Outcome Mix", "count(complaint rows closed in the period) by complaint_outcome",
               ("DP-414", "Complaint Outcome Mix"), "Closed complaints by outcome: upheld, partially upheld, not upheld, "
               "withdrawn."),
        _ratio("Complaint Upheld Rate %", "count(complaint rows closed in the period) with complaint_outcome = 'Upheld'",
               "count(complaint rows closed in the period)", ("DP-414", "Complaint Outcome Mix"),
               "Share of closed complaints upheld."),
        _count("Redress Paid", "sum(complaint.redress_amount) for complaints closed in the period (USD)",
               ("DP-414", "Redress Paid"), "Redress paid on closed complaints.",
               note="Remediation paid through DP-409 is SM-25's; this is the redress recorded on the complaint."),
        _count("Rule 4530(d) Complaint Statistics",
               "count(complaint rows) with written_complaint = 'Y' by finra_4530d_reporting_quarter x finra_problem_code x "
               "finra_product_code", ("DP-414", "Rule 4530(d) Statistics"),
               "Written complaints by FINRA problem and product code, as filed quarterly."),
        _count("Rule 4530(a) Reportable Events",
               "count(complaint rows in the period) with finra_4530a_reportable = 'Y', and of those with "
               "form_u4_reportable = 'Y' and related_disclosure_event populated", ("DP-414", "Rule 4530(a) Reportable Events"),
               "Complaints that are Rule 4530(a) reportable events."),
        _count("Complaints Naming an Associated Person",
               "count(complaint rows in the period) with associated_person_named populated",
               ("DP-414", "Complaints Naming an Associated Person"),
               "Complaints that name an associated person, by person and office.", note=_MIN10),
        _ratio("Complaints per 1,000 Accounts by Offering",
               "[Complaints Received] whose complaint_account has an active DP-093 Program Enrollment in the offering x 1,000",
               "count(distinct DP-093 Program Enrollment.enrolled_account) active in the offering",
               ("DP-414", "Complaints per 1,000 Accounts by Offering"),
               "Complaint rate per 1,000 enrolled accounts, by offering; self-directed accounts form their own row.",
               note="Offering rows do not add up (an account can be in more than one offering; see the relationship)."),
        _count("Complaints by Advisor of Record",
               "count(complaint rows in the period) by the covering_advisor of the primary DP-009 Coverage Assignment of "
               "complaint_account in force at received_date", ("DP-414", "Complaints by Advisor of Record"),
               "Complaints by the advisor of record of the account.", note=_MIN10),
        _count("Unlogged Service Dissatisfaction",
               "count(complaint_interaction rows in the period) with dissatisfaction_expressed = 'Y' whose "
               "linked_service_request has no escalated complaint and no complaint has it as intake_service_request",
               ("DP-414", "Unlogged Service Dissatisfaction"),
               "Service interactions with expressed dissatisfaction and no complaint logged: candidates for Rule 4530 review."),
        _count("Survey Complaint Referrals",
               "count(survey_response rows in the period) with complaint_referral populated, split by whether it resolves "
               "to a complaint", ("DP-414", "Survey Complaint Referrals"), "Survey responses referred as complaints."),
        _count("Recurring Complaint Root Causes",
               "per root_cause: count(complaint rows) in the trailing quarter, listing root causes with 5 or more and their "
               "finra_product_code mix", ("DP-414", "Recurring Root Causes"),
               "Root causes behind five or more complaints in the quarter.", agg="non_additive"),
        _count("Recommendation-Related Complaints",
               "count(complaint rows in the period) with related_recommendation populated",
               ("DP-414", "Recommendation-Related Complaints"),
               "Complaints about a recommendation; its evidence is SM-22's."),

        # --- DP-036 Communications review and FINRA filing -------------------------------------------------------------
        _count("Communication Review Cycle Time Median",
               "median business days from submission_timestamp to the approving compliance_approval.approval_decision_date "
               "of reviews decided in the period, recomputed for each slice", ("DP-036", "Review Cycle Time"),
               "Typical business days from submission to decision.", agg="non_additive"),
        _count("Communication Review Step Cycle Time Median",
               "median hours between consecutive review_step.step_completed_timestamp values (the first from "
               "submission_timestamp), by reviewer_role", ("DP-036", "Step Cycle Time"),
               "Typical hours each reviewer role takes.", agg="non_additive"),
        _asof("Open Communication Review Backlog",
              "count(compliance_review rows) submitted before the as-of date with no compliance_approval of status "
              "Approved, Approved with Changes or Rejected, by review_type and age band",
              ("DP-036", "Open Review Backlog"), "Communication reviews waiting for a decision."),
        _ratio("Communication First-Pass Approval Rate",
               "count(reviews decided in the period) approved with no review_step of step_outcome = 'Changes Requested'",
               "count(reviews decided in the period)", ("DP-036", "First-Pass Approval Rate"),
               "Share of communications approved without requested changes."),
        _ratio("FINRA Filing Timeliness %",
               "count(finra_filing rows due in the period) with finra_filing_requirement populated and filed_date <= "
               "filing_due_date", "count(finra_filing rows) with filing_due_date in the period",
               ("DP-036", "FINRA Filing Timeliness %"), "Share of FINRA advertising filings made on time (Rule 2210(c))."),
        _asof("Overdue FINRA Filings",
              "count(finra_filing rows) with filing_due_date before the as-of date and filed_date empty. Roles without "
              "filing rows read sum(conduct_indicator.overdue_filings) at the month-end",
              ("DP-036", "Overdue Filings"), "FINRA advertising filings past due."),
        _count("Communications Used Before Approval",
               "count(compliance_review rows) where used_before_approval_flag = 'Y'", ("DP-036", "Used Before Approval Flag"),
               "Communications first used before approval."),
        _count("Communications Expired In Use", "count(compliance_review rows) where expired_in_use_flag = 'Y'",
               ("DP-036", "Expired In Use Flag"), "Published communications whose approval expired or was withdrawn."),
        _asof("Communication Approvals Expiring Next 30 Days",
              "count(compliance_approval rows) approving with approval_expiry_date in the next 30 days whose asset_version "
              "is still Published", ("DP-036", "Approvals Expiring Next 30 Days"),
              "Approvals of live communications that run out in the next 30 days."),
        _count("Principal Qualification Exceptions",
               "count(compliance_review rows) where principal_qualification_exception = 'Y'",
               ("DP-036", "Principal Qualification Exception"),
               "Approvals by a principal without the registration the communication category needs."),
        _ratio("FINRA Comment Rate",
               "count(finra_filing rows in the period) with finra_review_outcome other than 'No Comment'",
               "count(finra_filing rows) with a finra_review_outcome in the period", ("DP-036", "FINRA Comment Rate"),
               "Share of FINRA-reviewed filings that came back with comments."),
        _count("Marketing Rule Advertisements Reviewed",
               "count(reviews decided in the period) with marketing_rule_advertisement = 'Y', by "
               "marketing_rule_advertisement_type, with those with testimonial_endorsement or third_party_rating = 'Y'",
               ("DP-036", "Marketing Rule Advertisements Reviewed"), "Advertisements reviewed under the Marketing Rule."),
        _count("Performance Shown Without Declaration",
               "count(compliance_review rows) with performance_shown = 'Y' whose asset_compliance_reference has "
               "performance_content_declared not 'Y', or hypothetical_performance_declared = 'Y' and performance_type not "
               "'Hypothetical'", ("DP-036", "Performance Shown Without Declaration"),
               "Communications showing performance the content owner did not declare."),
        _count("Gross-Only Performance in Advertisements",
               "count(Marketing Rule advertisements) with performance_shown = 'Y' and gross_net_presentation = 'Gross Only'",
               ("DP-036", "Gross-Only Performance in Advertisements"),
               "Advertisements showing gross performance without net (Rule 206(4)-1(d)(1))."),
        _count("Performance Without Track Record Basis",
               "count(compliance_review rows) with performance_shown = 'Y' whose featured share class (track_record) has "
               "performance_inception_date or track_record_source empty", ("DP-036", "Performance Without Track Record Basis"),
               "Communications showing performance with no track record behind it."),
        _count("Mirrored Approval Status Mismatch",
               "count(asset versions) whose asset_compliance_reference.mirrored_approval_status differs from the latest "
               "compliance_approval.approval_status of the review it names", ("DP-036", "Mirrored Approval Status Mismatch"),
               "Asset versions whose marketing-system approval status disagrees with compliance."),

        # --- DP-038 Gifts and non-cash compensation --------------------------------------------------------------------
        _count("G&E Recipient Year-to-Date Value",
               "per recipient_individual and calendar year: ge_item.recipient_ytd_value of the latest benefit valuation "
               "(gifts only)", ("DP-038", "Recipient Year-to-Date Value"),
               "Value of gifts each recipient has received this year.", agg="non_additive",
               note="A running total: never summed across recipients or items."),
        _ratio("G&E Limit Utilization %", "[G&E Recipient Year-to-Date Value] per recipient",
               "ge_item.annual_limit_amount of the recipient's applicable_limit_rule, once per recipient and year",
               ("DP-038", "Limit Utilization %"), "Share of the annual gift limit each recipient has used.",
               note="The USD 300 FINRA Rule 3220 limit is a drafting assumption (moving rule)."),
        _count("Near-Limit Recipients",
               "count(distinct ge_item.recipient_individual) with G&E Limit Utilization % at or above 80% and below 100% in "
               "the year", ("DP-038", "Near-Limit Recipients"), "Recipients close to the annual gift limit.",
               agg="count_distinct"),
        _count("G&E Limit Breaches", "count(ge_item rows in the year) with limit_breach = 'Y'",
               ("DP-038", "Limit Breach Count"), "Gift items that breached the limit, by giver and recipient firm.",
               note=_MIN10),
        _count("Late or Missing G&E Approvals",
               "count(ge_item rows) whose latest ge_approval.ge_approval_status is empty, Pending past benefit_date, or "
               "Rejected while the benefit was given", ("DP-038", "Late or Missing Approval Count"),
               "Gifts and entertainment given without timely approval.",
               note="Lateness is tested against Benefit Date and the status history (GAP-08-019)."),
        _count("Non-Cash Compensation Exceptions",
               "count(training or education meeting items) with member_firm_prior_approval not 'Y' or guest_expenses_paid "
               "= 'Y', plus items with sales_target_precondition = 'Y', by sponsor_firm",
               ("DP-038", "Non-Cash Compensation Exception"),
               "Non-cash compensation outside the FINRA Rule 2341(l)(5) conditions."),
        _count("Entertainment Frequency per Recipient",
               "per recipient_individual: count(ge_item rows) with benefit_type = 'Business Entertainment' in the trailing "
               "12 months, listing recipients above 12", ("DP-038", "Entertainment Frequency per Recipient"),
               "How often each recipient was entertained in the last 12 months.", agg="non_additive"),
        _count("G&E Spend by Recipient Firm",
               "sum(ge_item.total_cost) of items given in the year, by recipient_firm (per_recipient_value summed per "
               "individual beside it)", ("DP-038", "Spend by Recipient Firm"), "Gift and entertainment spend by firm."),
        _count("Special Recipient Items",
               "count and sum(total_cost) of ge_item rows in the year with erisa_plan_fiduciary, union_official or "
               "government_official = 'Y', by indicator", ("DP-038", "Special Recipient Items"),
               "Items given to ERISA plan fiduciaries, union officials or government officials."),
        _count("Items Given by Producing Advisors",
               "count and sum(total_cost) of ge_item rows given in the year whose giver holds a DP-009 Advisor Role "
               "Assignment with producing_indicator = 'Y' in force at benefit_date, by advisor role",
               ("DP-038", "Items Given by Producing Advisors"), "Gifts and entertainment given by producing advisors.",
               note="Role rows do not add up (see the relationship)."),
        _count("Event-Linked G&E Items", "count and sum(total_cost) of ge_item rows with related_event populated",
               ("DP-038", "Event-Linked Items"), "Gifts and entertainment linked to a marketing event.",
               note="The event type slice needs DP-011's Marketing Event (SM-25), which this model does not read."),
        _count("Unreconciled G&E Spend",
               "per month: sum(ge_item.total_cost) given minus sum(ge_distribution_cost.expense_amount) whose "
               "service_period_start falls in the month; shown when the absolute difference exceeds 2%",
               ("DP-038", "Unreconciled G&E Spend"), "Gift and entertainment spend that does not tie to the ledger.",
               agg="non_additive"),

        # --- DP-039 Registrations, licensing and CE (restricted licensing view) ----------------------------------------
        _count("Registered Headcount",
               "count(distinct person_compliance_status.registered_person) with registered_headcount = 1 on the as-of "
               "status date", ("DP-039", "Registered Headcount"),
               "Registered persons with at least one approved registration, by category and registering firm.",
               agg="count_distinct",
               note="Not SM-15's Certified Headcount: this counts registered people, not employees."),
        _ratio("Registration Coverage %",
               "count(distinct covered client parties) whose state of residence is a jurisdiction of an Approved "
               "registration of their covering advisor of the right category, on the as-of date",
               "count(distinct covered client parties) of the same advisors", ("DP-039", "Registration Coverage %"),
               "Share of covered clients living in a state where their advisor is registered."),
        _asof("Unregistered Coverage Exceptions",
              "sum(person_compliance_status.unregistered_coverage_exceptions) on the as-of status date",
              ("DP-039", "Unregistered Coverage Exception"),
              "Primary coverage assignments where the advisor is not registered in the client's state."),
        _asof("CE Overdue Count",
              "count(ce_requirement rows) with ce_due_date before the as-of date and ce_status not 'Complete'. Roles "
              "outside licensing read sum(conduct_indicator.ce_overdue) at the month-end",
              ("DP-039", "CE Overdue Count"), "Continuing education requirements overdue, by CE element.", note=_MIN10),
        _asof("CE Due Next 60 Days",
              "count(ce_requirement rows) with ce_status not 'Complete' and ce_due_date in the next 60 days, with "
              "sum(credits_completed)", ("DP-039", "CE Due Next 60 Days"), "Continuing education due in the next 60 days."),
        _ratio("U5 Filing Timeliness %",
               "count(registration_filing rows) with form_type = 'U5' and form_filing_date within 30 days of the person's "
               "termination date", "count(terminations of registered persons in the period)",
               ("DP-039", "U5 Filing Timeliness"), "Share of Form U5 filings made within 30 days of termination."),
        _count("Late U4 Disclosure Amendments",
               "count(disclosure_event rows) whose Form U4 amendment (reported_on_filing) was filed more than 30 days after "
               "event_date, or with reported_on_filing empty more than 30 days after it",
               ("DP-039", "Late U4 Disclosure Amendments"), "Disclosure events reported late on Form U4.",
               note="Restricted licensing view only. " + _MIN10),
        _asof("Open Disclosure Events",
              "count(disclosure_event rows) with disclosure_status not 'Resolved', by disclosure_event_type",
              ("DP-039", "Open Disclosure Events"), "Disclosure events not yet resolved.",
              note="Special category: restricted licensing view only, minimum cell 10 on any count by event type (CW-213 "
                   "exception, CD-344)."),
        _asof("Exam Pass Pending",
              "sum(person_compliance_status.exam_pass_pending) on the as-of status date, by exam_code",
              ("DP-039", "Exam Pass Pending"), "Pending registrations still waiting for a passed exam."),
        _asof("Registrations Terminated While Covering",
              "sum(person_compliance_status.terminated_while_covering) on the as-of status date",
              ("DP-039", "Registrations Terminated While Covering"),
              "Terminated registrations whose holder still covers clients."),
        _asof("Registration Copy Stale", "sum(person_compliance_status.registration_copy_stale) on the as-of status date",
              ("DP-039", "Registration Copy Stale"),
              "Advisors whose 03 registration copy is stale or differs from their 08 registrations."),
        _asof("Active Advisors Without Registration",
              "sum(person_compliance_status.active_without_registration) on the as-of status date. Roles outside "
              "licensing read sum(conduct_indicator.advisors_without_registration) at the month-end",
              ("DP-039", "Active Advisors Without Registration"),
              "Active producing advisors with no approved registration.", note=_MIN10),

        # --- DP-078 Communications capture and surveillance ------------------------------------------------------------
        _count("In-Scope Employees",
               "count(distinct employee_capture_day.monitored_employee) with in_scope_employee = 'Y' on the as-of capture "
               "date", ("DP-078", "In-Scope Employee"), "Employees whose communications must be captured.",
               agg="count_distinct"),
        _count("Captured Communications",
               "count(captured_communication rows) with communication_timestamp in the period",
               ("DP-078", "Captured Communication Count"), "Communications captured, by channel and employee.",
               note=_MIN10),
        _count("Silent Employees",
               "count(distinct employee_capture_day.monitored_employee) with silent_employee_flag = 'Y' on the as-of date "
               "(no capture in 10 business days while active)", ("DP-078", "Silent Employee Flag"),
               "In-scope employees with no captured communication in the window.", agg="count_distinct", note=_MIN10),
        _count("Recorded Activity Capture Gaps",
               "sum(employee_capture_day.recorded_activity_capture_gap) over capture dates in the period",
               ("DP-078", "Recorded Activity Capture Gap"),
               "Recorded advisor activities whose communication was not archived."),
        _count("Unapproved Channel Activity",
               "sum(employee_capture_day.unapproved_channel_activity) over capture dates in the period",
               ("DP-078", "Unapproved Channel Activity"),
               "Communications and recorded activities on a channel not approved for the employee."),
        _asof("Open Communication Surveillance Alerts",
              "count(comms_surveillance_alert rows) with alert_review_status not 'Closed', with mean and maximum age in "
              "business days since the flagged communication_timestamp", ("DP-078", "Open Alert Count and Age"),
              "Communications surveillance alerts awaiting review.",
              note="Age runs from the flagged communication: the alert has no generated date (GAP-08-023)."),
        _ratio("Communication Alert Escalation Rate %",
               "count(comms_surveillance_alert rows closed in the period) with comms_alert_disposition = 'Escalated' or "
               "related_complaint populated", "count(comms_surveillance_alert rows closed in the period)",
               ("DP-078", "Alert Escalation Rate"), "Share of closed communications alerts escalated or linked to a complaint."),
        _count("Retention Shortfall Records",
               "count(captured_communication rows) whose retention_expiry_date is earlier than communication_timestamp "
               "plus retention_rule_dim.retention_period_years", ("DP-078", "Retention Shortfall Flag"),
               "Captured communications set to be deleted before their retention period ends (SEC Rule 17a-4(b)(4))."),
        _asof("Legal Hold Exposure",
              "count(captured_communication rows) with legal_hold = 'Y', and of those with retention_expiry_date in the "
              "next 90 days", ("DP-078", "Legal Hold Exposure"),
              "Communications under legal hold, and those whose deletion must be suspended soon."),
        _asof("Unsupervised Social Accounts",
              "count(approved_channel rows in force) with channel_type = 'Social Media', account_use_type = 'Business' and "
              "capture_method empty or 'None', or firm_social_media_account empty while social_platform is populated",
              ("DP-078", "Unsupervised Social Account Flag"), "Business social media accounts not captured."),
        _count("Employees Without Supervisor Assignment",
               "count(distinct employee_capture_day.monitored_employee) with without_supervisor_assignment = 'Y' on the "
               "as-of date", ("DP-078", "Employees Without Supervisor Assignment"),
               "In-scope employees with no supervisor of record to review their communications.", agg="count_distinct"),
        _ratio("Alerts per 1,000 Captured Communications",
               "count(comms_surveillance_alert rows) on communications captured in the period x 1,000",
               "[Captured Communications]", ("DP-078", "Alerts per 1,000 Captured Communications"),
               "Surveillance alert rate per 1,000 captured communications, by channel."),

        # --- DP-390 Incentive governance (Confidential - Compensation) -------------------------------------------------
        _asof("Active Incentive Plans",
              "count(incentive_plan versions) with plan_approval_status = 'Approved' in force at the as-of date",
              ("DP-390", "Active Incentive Plans"), "Approved incentive plans in force, by type and year."),
        _asof("Components Without Current Conflict Review",
              "count(incentive_component rows of active plans) with no incentive_conflict_review in the 12 months before "
              "the as-of date", ("DP-390", "Components Without Current Conflict Review"),
              "Plan components not reviewed for conflicts in the last 12 months."),
        _asof("Product-Specific Time-Limited Components",
              "count(incentive_component rows of active plans) with product_specific_time_limited = 'Y', and of those "
              "with proprietary_product_linked = 'Y'", ("DP-390", "Product-Specific Time-Limited Components"),
              "Components that reward selling specific products in a limited time (prohibited under Reg BI)."),
        _asof("Components Not Rollover-Neutral",
              "count(incentive_component rows of active plans) with rollover_neutral not 'Y', by component_measure",
              ("DP-390", "Components Not Rollover-Neutral"), "Components that pay more for rollovers."),
        _count("Conflict Reviews With Adverse Finding",
               "count(incentive_conflict_review rows in the period) with conflict_review_outcome in ('Mitigation "
               "Required', 'Prohibited') or proprietary_product_incentive_finding populated, split by mitigation_applied",
               ("DP-390", "Conflict Reviews With Adverse Finding"), "Conflict reviews that found an incentive conflict."),
        _count("Recognition Awards on Product-Specific Criteria",
               "count(recognition_award rows in the period) with product_specific_criteria = 'Y', with "
               "sum(non_cash_award_value)", ("DP-390", "Recognition Awards on Product-Specific Criteria"),
               "Recognition awards based on selling specific products."),
        _count("Recognition Awards Without Conduct Review",
               "count(recognition_award rows in the period) with award_conduct_review_reference empty and no "
               "incentive_conflict_review of the award", ("DP-390", "Recognition Awards Without Conduct Review"),
               "Recognition awards made without a conduct review."),
        _asof("Participants Without Plan Acknowledgment",
              "count(plan_participation rows in force) with participant_eligibility_status = 'Eligible' and "
              "plan_acknowledgment_date empty", ("DP-390", "Participants Without Plan Acknowledgment"),
              "Eligible participants who have not acknowledged their plan.", note=_MIN10),
        _count("Incentive Earned by Component",
               "sum(incentive_earnings.earned_amount) on statements with statement_period_end in the period (USD)",
               ("DP-390", "Incentive Earned by Component"), "Incentive earned, by plan component and measure.",
               note="Line-level amount: additive across lines, unlike the statement totals."),
        _ratio("Mean Attainment by Component", "sum(incentive_earnings.attainment_percentage) over earnings lines",
               "count(incentive_earnings lines) for statements in the period", ("DP-390", "Mean Attainment by Component"),
               "Average attainment per component, with the share at threshold and at cap."),
        _ratio("Earned vs Target %",
               "sum(incentive_earnings.total_earned) taken once per statement, for the participant's statements in the "
               "plan year", "sum(plan_participation.target_incentive_amount) for the same participants and plan",
               ("DP-390", "Earned vs Target %"), "Incentive earned against target, by plan and advisor role."),
        _count("Net Payable on Issued Statements",
               "sum(incentive_earnings.net_payable_amount) taken once per statement_id, for statements with "
               "statement_status = 'Issued' and statement_issued_date in the period (USD)",
               ("DP-390", "Net Payable on Issued Statements"), "Net incentive payable on statements issued.",
               note="Summing over earnings lines would multiply each statement by its line count."),
        _asof("Issued Statements Not Paid Through Payroll",
              "count(distinct incentive_earnings.statement_id) with statement_status = 'Issued', statement_issued_date more "
              "than 30 days before the as-of date and payroll_result_reference empty",
              ("DP-390", "Issued Statements Not Paid Through Payroll"),
              "Issued statements with no payroll result after 30 days (the pay itself is DP-198's)."),
    ],

    excluded=[
        ("DP-398", "Recommendation Review Coverage %",
         "Its denominator is DP-303's recommendations requiring review, which SM-22 publishes; the coverage gap is "
         "answered there by DP-334's Unreviewed Recommendations, and this rate stays on DP-398's dashboard."),
        ("DP-400", "Complex Product Alerts",
         "Needs the Recommended Share Class of the triggering DP-303 recommendation and its 01 Product Risk Indicator; "
         "this model does not read DP-303 (SM-22's) and DP-004 does not publish the risk indicator by recommendation. "
         "See open decisions."),
        ("DP-400", "Concentrated Accounts Without Alert",
         "A scenario-coverage check over 49 Client Holding through DP-300; holdings are SM-24's book of record and a copy "
         "here would put a second Client Holding table in the layer (CW-007). It stays on DP-400's tuning dashboard."),
        ("DP-414", "Complaints From Protected Clients (from DP-322)",
         "Needs DP-322's Protection Flag Present per complainant, which no table here carries (DP-322 lists no BI "
         "delivery and the flag is special category). DP-414 publishes it at 10 or more on its own dashboard; the "
         "layer's protected-client aggregate is Clients Under Protection (DP-404)."),
        ("DP-390", "Earned Tie-Out to Variable Awards (from DP-198)",
         "A participant-level reconciliation of incentive statements to DP-198's variable compensation awards; pay is "
         "SM-15's and the break list is a compensation operations control, not a cross-row business number."),
        ("DP-390", "Asset-Based Results Differing From DP-008",
         "A data control comparing statement measured results with the certified DP-008 values by advisor; the certified "
         "Client Assets and Net New Assets are SM-20's and the break list stays on DP-390's dashboard."),
    ],

    access=dict(
        classification="Confidential - Personal Data, special-category attributes hidden (DP-039 is Restricted - "
                       "Personal Data; DP-390 is Confidential - Compensation)",
        # Client special-category data (CD-344) never reaches a row here: protected clients and elder-exploitation holds
        # are DP-322, DP-403 and DP-456 restricted views, read only as DP-404's count of 10 or more. Employee conduct data
        # (alerts, findings, heightened supervision, complaints naming a person) is employee performance data and is
        # shown by person only to the people who supervise them.
        roles=[
            dict(role="retail_conduct_compliance",       # Head of Retail Conduct, complaints, disclosure control
                 rows="all offices, advisors, reviews, alerts, findings, complaints, disclosure checks and communications "
                      "reviews; no DP-039 or DP-390 rows; counts by advisor or office of 10 or more (" + _MIN10 + ")",
                 columns="all except special category and compensation; client keys for drill and re-delivery",
                 hidden=_SPECIAL + _COMP),
            dict(role="supervisory_principal",
                 rows="reviews, alerts, corrective actions, findings, inspections, complaints, G&E items and capture rows "
                      "of the persons and offices the viewer supervises (supervisory_assignment or principal_designation in "
                      "force); no DP-039 or DP-390 rows",
                 columns="all except client keys, special category and compensation",
                 hidden=_CLIENT_KEYS + _SPECIAL + _COMP),
            dict(role="registration_licensing_compliance",
                 rows="all DP-039 rows (the only role that sees the restricted licensing view) with the DP-391 structure "
                      "and DP-009 registrations; any count by disclosure event type of 10 or more",
                 columns="all, including disclosure events (CW-213 exception); no client keys, no compensation",
                 hidden=_CLIENT_KEYS + _COMP),
            dict(role="communications_surveillance",
                 rows="DP-078 and DP-036 rows; supervisory structure for the supervisor of record",
                 columns="all except client keys, special category and compensation",
                 hidden=_CLIENT_KEYS + _SPECIAL + _COMP),
            dict(role="compensation_governance",          # sales compensation, HR rewards, compliance reviewer of plans
                 rows="DP-390 rows, with the supervisory structure and conduct indicators by advisor",
                 columns="all except client keys and special category",
                 hidden=_CLIENT_KEYS + _SPECIAL),
            dict(role="broad_internal",                   # business line heads, enterprise risk (DP-248), finance
                 rows="conduct indicators, complaints, reviews, disclosure checks, inspections and controls in aggregate; "
                      "no DP-039 or DP-390 rows; no row-level conduct data",
                 columns="aggregates by office, branch type, business line, offering, scenario type, complaint category "
                         "and month only; every count by advisor or office suppressed below 10",
                 hidden=_PEOPLE + _CLIENT_KEYS + _SPECIAL + _COMP),
        ]),

    verified_questions=[
        dict(question="Which cash movements are on hold for fraud or elder-exploitation review?",
             answer="By aggregate only (acceptance question 7). [Active Money Movement Holds] and [Held Amount] (SM-24, "
                    "DP-302's published holds) filtered to Hold Type = Fraud at the as-of date, by hold reason and age; "
                    "beside them [Clients Under Protection] from conduct_indicator at the latest month-end by advisor and "
                    "office, suppressed below 10. Elder-exploitation (Rule 2165) holds are special category: they are not "
                    "in SM-24's published rows and reach the layer only as DP-404's protected-client count (the Rule 2165 "
                    "clock is read by DP-404 and DP-456 as aggregates). No row-level list is given here; the case list is "
                    "DP-403's restricted view."),
        dict(question="Which offices have principal reviews past standard or decided by someone other than the "
                      "supervisor of record this quarter?",
             answer="[Reviews Past Review Standard], [Reviews by Unassigned Principal] and [Self-Reviews] for the quarter, "
                    "from supervisory_review joined to supervisory_assignment (Primary, in force at review_completed_date) "
                    "and grouped by firm_branch_office.office, with [Open Principal Review Queue] at the as-of date; "
                    "cells below 10 suppressed.",
             sql="select o.office, count(*) filter (where r.reviewing_principal = r.supervised_representative) as self_reviews "
                 "from dp_398.supervisory_review_outcome r join dp_391.supervisory_assignment a "
                 "on a.supervised_person = r.supervised_representative and a.supervisory_assignment_type = 'Primary' "
                 "and a.assignment_effective_from <= r.review_completed_date "
                 "and (a.assignment_effective_to is null or a.assignment_effective_to > r.review_completed_date) "
                 "join dp_391.firm_branch_office o on o.office = a.supervising_office "
                 "where r.review_completed_date >= date_trunc('quarter', current_date) group by 1 having count(*) >= 10"),
        dict(question="Which advisors breach two or more conduct indicators this month, and where do evidence gaps sit?",
             answer="[Advisors Breaching Two or More Indicators] at the latest month-end by office (conduct_indicator "
                    "-> firm_branch_office), with [Recommendations Without Best-Interest Evidence] and [Rollovers Without "
                    "PTE 2020-02 Documentation] (SM-22, read through conduct_indicator) and [Sales Practice Alerts per "
                    "1,000 Households] by advisor; minimum cell 10."),
        dict(question="What is our complaint rate per 1,000 households and per USD 1 billion of client assets by "
                      "business line, and how much did we report under Rule 4530(d) last quarter?",
             answer="[Complaints per 1,000 Households] and [Complaints per USD 1 Billion Client Assets] for the month "
                    "(complaints from complaint, current handling version; Households and Client Assets from SM-20 at the "
                    "same month-end), and [Rule 4530(d) Complaint Statistics] for the last reporting quarter by FINRA "
                    "problem and product code."),
        dict(question="Are our Form CRS deliveries on time and which triggers fail most?",
             answer="[Disclosure Check Failure Rate %] and [Late Disclosures] by disclosure_trigger for the period, with "
                    "[Accounts Opened Without Form CRS] and [Form CRS Amendment Re-Delivery Outstanding] at the as-of date."),
        dict(question="Are branches inspected on cycle and supervisors qualified?",
             answer="[Branch Inspections On Cycle %] and [Branch Inspections Overdue] by firm_branch_office.branch_type at "
                    "the as-of date, with [Supervisors Without Principal Registration], [OSJs Without Designated "
                    "Principal] and [Principals Over Span Limit]."),
    ],

    cannot_answer=[
        dict(question="List the individual cash movements on fraud or elder-exploitation hold, with the client and amount",
             why="Row-level holds with a special-category reason are DP-456's and DP-403's restricted views (CD-344); the "
                 "semantic layer gives counts and amounts only. The list is worked in the case system by the Rule 2165 "
                 "team.", gap=""),
        dict(question="How many movements are on a Rule 2165 elder-exploitation hold, and for how much?",
             why="DP-456's aggregate view (hold type x age bucket x outcome, limited to non-special holds) and DP-403 list "
                 "no BI delivery, and SM-24 suppresses special-category holds; only DP-404's Clients Under Protection "
                 "reaches the layer. See open decisions.", gap=""),
        dict(question="Which recommendations lack best-interest evidence, recommendation by recommendation?",
             why="The evidence flags are DP-334's and DP-335's, published in SM-22; this model carries only their counts "
                 "by advisor, office and offering.", gap=""),
        dict(question="How long does a review wait in the principal's queue before it is picked up?",
             why="08 Supervisory Review has no queued or assigned timestamp; aging starts at the subject's own "
                 "timestamp. No gap is registered for it yet.", gap=""),
        dict(question="How long do communications surveillance alerts take to review?",
             why="08 Surveillance Alert has no generated, reviewed or closed timestamps; age runs from the flagged "
                 "communication.", gap="GAP-08-023"),
        dict(question="When was each gift or entertainment item approved?",
             why="08 G&E Approval has no approval decision date; lateness is inferred from the status history.",
             gap="GAP-08-019"),
        dict(question="How long do complaints take to close, separate from the final response?",
             why="08 Complaint has no closed date separate from Final Response Date.", gap="GAP-08-028"),
        dict(question="Roll supervisory metrics up a branch-to-region supervisory tree",
             why="Supervisory Hierarchy Link child and parent units point to two object types, so the tree is joined by "
                 "value.", gap="GAP-03-015"),
    ],

    open_decisions=[
        "Sibling references (WP2, written in parallel): Recommendations Without Best-Interest Evidence, Evidence Gap Rate "
        "%, Rollovers Without PTE 2020-02 Documentation and PTE Documentation Gap Rate % are referenced as SM-22/<DP-334 "
        "or DP-335 measure name>; Active Money Movement Holds and Held Amount as SM-24/<DP-302 measure name>. If SM-22 or "
        "SM-24 rename them, re-point the ref (the definitions stay theirs; this model never re-derives the flags, CW-224). "
        "Checked against the sibling drafts of sm_22_advice_planning.py and sm_24_brokerage_execution.py on 2026-10-15: "
        "all six names resolve.",
        "Acceptance question 7: elder-exploitation holds reach the layer only as DP-404's Clients Under Protection (a "
        "count of protected clients, not of holds or amounts). Decide whether DP-456's aggregate view (hold type x age "
        "bucket x outcome, minimum cell 10) lists the BI semantic model delivery and joins SM-24 or SM-29; until then the "
        "Rule 2165 hold count and amount cannot be stated in the layer.",
        "DP-404 grain: the Conduct Indicator fact is keyed advisor x office x offering x month with a surrogate key (model "
        "gap). Confirm each count is written once at its own slice (other keys empty); if a per-advisor count repeats on "
        "every offering row, summing across offerings double counts and the metrics that read conduct_indicator need an "
        "always_filter on the slice.",
        "Clients Under Protection: DP-404 counts protected parties in each advisor's primary-coverage book. Confirm that "
        "the firm total is the distinct count (not the sum of advisor rows) when DP-322 flags a party covered through two "
        "accounts with different advisors.",
        "Corrective actions: DP-400 and DP-402 both read 08 Conduct Corrective Action (alert or review sourced, and finding "
        "sourced). The model publishes Corrective Actions Overdue and Finding Corrective Actions Overdue separately and "
        "never adds them; confirm an action cannot carry both a finding and an alert or review source.",
        "Heightened supervision: DP-400 and DP-402 both read 08 Heightened Supervision Plan; the model keeps one table "
        "(DP-402's, which carries the heightened supervisor) and computes DP-400's Representatives Under Heightened "
        "Supervision from it. Confirm with the DP-400 owner.",
        "Principals, inspectors, control testers and attesters who hold no advisor role are role-played from DP-192 "
        "Employee (SM-15's product, readable as the source of Certified Headcount). Decide whether SM-00 should publish a "
        "principal role on DP-009 instead so that conduct models need not read the HR worker record.",
        "DP-400 Complex Product Alerts is excluded: carry the Recommended Share Class (or the firm risk rating) on the 08 "
        "Sales Practice Alert, or let SM-29 read DP-303's Recommendation key through SM-22, to publish it.",
        "DP-398 open reviews are snapshotted daily; the supervisory_review always_filter keeps the as-of date's snapshot. "
        "Confirm DP-398 exposes a snapshot date column; the logical model lists none on Supervisory Review Outcome.",
        "DP-414 Complaint handling is SCD type 2 but the logical model carries no version or effective-date column; the "
        "complaint table's pin to the current handling version needs one.",
        "DP-039 is the restricted licensing view (Restricted - Personal Data): only registration_licensing_compliance reads "
        "its tables. Other roles read the DP-039 counts DP-404 carries by advisor (Active Advisors Without Registration, "
        "CE Overdue Count) from conduct_indicator; confirm this is the intended release of those two counts.",
        "Thresholds used in metric definitions (review standards, 30-day alert standard, span limit 25, conduct indicator "
        "bands, 80% near-limit, USD 300 gift limit, 2% ledger tolerance) are the products' drafting assumptions and "
        "tailoring levers; confirm with the Head of Retail Conduct before the model is Confirmed.",
        "Event-Linked G&E Items by event type needs DP-011 Marketing Event (SM-25); published without the event type slice.",
    ],
)
