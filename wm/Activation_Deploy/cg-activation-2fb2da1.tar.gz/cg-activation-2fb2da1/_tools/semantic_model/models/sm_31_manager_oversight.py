"""SM-31 Manager Oversight & Due Diligence: external managers and sub-advisers, manager searches and due diligence, the
oversight scorecard, hires, terminations and the Section 15(c) renewal evidence (lead ruling at WP2; CW-209). See CONTRACT.md.

Products: DP-306 Manager & Sub-Adviser Master (the Manager dimension, engagements, key persons, guideline sets, product
list status), DP-535 Manager Search, Selection & Due Diligence, DP-536 Sub-Adviser Oversight Scorecard and DP-538
Sub-Adviser Hires, Terminations & Section 15(c) Renewal Evidence. It owns no certified metric: returns are SM-08's,
ex-ante risk SM-10's, fund net assets and the Firm AUM slices SM-11's, read with ref= and sliced by engagement.
"""

# One row per external manager on the as-of date: the 52 profile is effective dated (DP-306 is SCD type 2).
_AS_OF = "the model's as-of date (default: today)"
_PROFILE_ON_AS_OF = ("profile_effective_from <= as_of_date and (profile_effective_to is null or profile_effective_to > "
                     "as_of_date), as_of_date = " + _AS_OF)
# The certified return of record (SM-08): final or restated, highest version of the same return key.
_RETURN_OF_RECORD = ["Return Status in ('Final', 'Restated')",
                     "Return Version = the highest Return Version of the same return key (subject, period, fee basis, "
                     "net fee basis, calculation type, price basis, tax basis, sales charge basis, currency)",
                     "Return Subject Type = 'Portfolio' and Return Portfolio is the Sleeve Portfolio of a sub-adviser "
                     "engagement (the fund's own share class returns are SM-08's)"]
# Background check results are consumer reports under the FCRA (DP-535 DQ5): outcome and authorization only, and only in
# the manager research restricted view.
_BACKGROUND = ["background_check_type", "check_date", "subject_authorization_obtained", "regulatory_disclosure_found",
               "background_check_outcome"]
# Individuals and employees: key persons are 02 parties; reviewers, owners and analysts are DP-192 employees.
_PEOPLE = ["key_person_role", "key_person_departure_date", "key_person_notified_date"]
_FREE_TEXT = ["conclusion_commentary", "recommendation_rationale", "elimination_reason", "areas_inspected",
              "watch_reason", "list_status_reason"]

MODEL = dict(
    id="SM-31",
    status="Draft",
    description=(
        "External managers and sub-advisers across every engagement, for the manager research team, the investment "
        "oversight committee, fund legal and the fund board's Section 15(c) process. It answers questions across "
        "managers, engagements, searches, reviews and renewal years: who is on watch and why, whether due diligence and "
        "oversight reviews are current, how the scorecard readings tie out to the certified returns and risk numbers, "
        "and what each fund engagement's last Section 15(c) renewal showed. Questions about one manager's file are "
        "answered in the manager research system."),
    questions=[
        "Which sub-advisers are under review and what did the last Section 15(c) renewal data show? (acceptance question 12)",
        "How many sub-adviser engagements are active, by engagement scope and fund or mandate, and which lack an active "
        "agreement, board approval or acknowledged guidelines?",
        "Which oversight metrics breached their approved thresholds this quarter, at which managers, and do the readings "
        "tie out to the certified official returns and ex-ante tracking error?",
        "Are manager searches and due diligence reviews current: open searches by need, reviews overdue by questionnaire "
        "type, and approved hires without a resulting engagement?",
        "How many sub-advisers did we hire and terminate this year, with what reasons, transition times and costs, and "
        "were the decisions approved by the investment committee?",
        "Which third-party products are on our approved lists without current due diligence, and which were approved "
        "despite failed criteria?",
    ],

    tables=[
        # ======================= DP-306 Manager & Sub-Adviser Master (the Manager dimension) ======================
        dict(name="manager", product="DP-306", entity="Manager", kind="Dimension",
             always_filter=[_PROFILE_ON_AS_OF],   # one profile period per manager, so engagement counts do not repeat
             dimensions=[dict(name="external_manager_types", attr="External Manager Types",
                              note="Multi-valued (sub-adviser, third-party fund manager, model provider); filter, do not group"),
                         dict(name="research_coverage_status", attr="Research Coverage Status"),
                         dict(name="ownership_structure", attr="Ownership Structure"),
                         dict(name="form_adv_last_reviewed", attr="Form ADV Last Reviewed Date"),
                         dict(name="affiliated_person", attr="Affiliated Person Indicator"),
                         dict(name="profile_effective_from", attr="Profile Effective From"),
                         dict(name="profile_effective_to", attr="Profile Effective To")],
             hidden=[("Coverage Analyst", "An employee reference (DP-192); coverage by analyst is a workload question "
                                          "for the research system, not a cross-manager one.")]),
        dict(name="manager_strategy", product="DP-306", entity="External Manager Strategy", kind="Dimension",
             dimensions=[dict(name="manager_strategy_name", attr="Manager Strategy Name"),
                         dict(name="strategy_asset_class", attr="Strategy Asset Class"),
                         dict(name="strategy_style", attr="Strategy Style"),
                         dict(name="vehicles_available", attr="Vehicles Available"),
                         dict(name="strategy_research_status", attr="Strategy Research Status")]),
        dict(name="key_person", product="DP-306", entity="Manager Key Person", kind="Dimension",
             dimensions=[dict(name="key_person_role", attr="Key Person Role"),
                         dict(name="key_person_flag", attr="Key Person Indicator"),
                         dict(name="role_start_date", attr="Role Start Date"),
                         dict(name="key_person_departure_date", attr="Departure Date"),
                         dict(name="key_person_notified_date", attr="Departure Notified Date")],
             hidden=[("Key Person", "The individual's DP-240 party key; kept only to join background checks, never shown "
                                    "and never joined to DP-240 names."),
                     ("Key Person Strategies", "A multi-valued list; key person risk is read by manager, not by strategy.")]),
        # The engagement is the hub every oversight, renewal and termination row joins to. It reads the DP-306 master;
        # the DP-538 conformed copy adds two information statement columns the model does not read (open decisions).
        dict(name="engagement", product="DP-306", entity="Sub-Adviser Engagement", kind="Dimension",
             grain="sub-adviser x fund or mandate x sleeve x engagement period (SADV-)",
             dimensions=[dict(name="engagement_id", attr="Sub-Adviser Engagement ID"),
                         dict(name="engagement_scope", attr="Engagement Scope"),
                         dict(name="investment_discretion", attr="Investment Discretion Indicator"),
                         dict(name="trading_delegated", attr="Trading Delegated Indicator"),
                         dict(name="proxy_voting_delegated", attr="Proxy Voting Delegated Indicator"),
                         dict(name="engagement_status", attr="Engagement Status"),
                         dict(name="engagement_start_date", attr="Engagement Start Date"),
                         dict(name="engagement_end_date", attr="Engagement End Date"),
                         dict(name="board_approval_date", attr="Board Approval Date"),
                         dict(name="relied_on_exemptive_relief", attr="Relied-On Exemptive Relief",
                              note="A reference to the 35 exemptive order relied on; flagged personal data by the "
                                   "validator's word match only (no individual is named)"),
                         dict(name="shareholder_approval_required", attr="Shareholder Approval Required Indicator"),
                         dict(name="information_statement_due", attr="Information Statement Due Date"),
                         dict(name="information_statement_sent", attr="Information Statement Sent Date")]),
        dict(name="guideline_set", product="DP-306", entity="Sub-Adviser Guideline Set", kind="Dimension",
             default_filter="the current version of each engagement: highest Guideline Version with Guideline Effective "
                            "Date <= as_of_date",
             dimensions=[dict(name="guideline_version", attr="Guideline Version"),
                         dict(name="guideline_effective_date", attr="Guideline Effective Date"),
                         dict(name="guideline_delivered_date", attr="Guideline Delivered Date"),
                         dict(name="guideline_acknowledged_date", attr="Guideline Acknowledged Date"),
                         dict(name="sub_adviser_pre_trade_checks", attr="Sub-Adviser Pre-Trade Checks Indicator")]),
        dict(name="product_list_status", product="DP-306", entity="Product List Status", kind="Fact",
             grain="third-party instrument x list scope x status period",
             always_filter=["list_status_effective_from <= as_of_date and (list_status_effective_to is null or "
                            "list_status_effective_to > as_of_date)"],   # one status per instrument and list on the date
             dimensions=[dict(name="list_scope", attr="List Scope"),
                         dict(name="product_list_status", attr="Product List Status"),
                         dict(name="list_status_reason", attr="List Status Reason"),
                         dict(name="list_status_effective_from", attr="List Status Effective From"),
                         dict(name="list_status_effective_to", attr="List Status Effective To")]),

        # ======================= DP-535 Manager Search, Selection & Due Diligence =================================
        dict(name="manager_search", product="DP-535", entity="Manager Search", kind="Dimension",
             dimensions=[dict(name="search_need", attr="Search Need"),
                         dict(name="search_status", attr="Search Status"),
                         dict(name="search_opened_date", attr="Search Opened Date"),
                         dict(name="search_closed_date", attr="Search Closed Date"),
                         dict(name="recommendation_date", attr="Recommendation Date"),
                         dict(name="interim_contract", attr="Interim Contract Indicator")],
             hidden=[("Search Owner", "An employee reference (DP-192); no cross-search question needs the owner's name.")]),
        dict(name="search_candidate", product="DP-535", entity="Fact Search Candidate", kind="Fact",
             grain="manager search x candidate external manager strategy",
             dimensions=[dict(name="search_stage", attr="Search Stage"),
                         dict(name="elimination_reason", attr="Elimination Reason")],
             hidden=[("Candidate Due Diligence Reviews", "A multi-valued list of review keys; reviews are joined from "
                                                         "dd_review by strategy, never summed through the list.")]),
        dict(name="questionnaire_template", product="DP-535", entity="Questionnaire Template", kind="Dimension",
             dimensions=[dict(name="questionnaire_template_version", attr="Questionnaire Template Version"),
                         dict(name="questionnaire_type", attr="Questionnaire Type"),
                         dict(name="template_status", attr="Template Status"),
                         dict(name="template_effective_from", attr="Template Effective From"),
                         dict(name="template_effective_to", attr="Template Effective To")]),
        dict(name="dd_review", product="DP-535", entity="Fact Manager Due Diligence Review", kind="Fact",
             grain="one manager due diligence review (MDILG-); every review kept",
             dimensions=[dict(name="due_diligence_review_type", attr="Due Diligence Review Type"),
                         dict(name="questionnaire_sent_date", attr="Questionnaire Sent Date"),
                         dict(name="questionnaire_received_date", attr="Questionnaire Received Date"),
                         dict(name="overall_due_diligence_rating", attr="Overall Due Diligence Rating"),
                         dict(name="due_diligence_outcome", attr="Due Diligence Outcome"),
                         dict(name="review_completed_date", attr="Review Completed Date"),
                         dict(name="next_review_due_date", attr="Next Review Due Date")],
             hidden=[("Lead Reviewer", "An employee reference (DP-192); reviewer workload is not a cross-manager question.")]),
        dict(name="dd_score", product="DP-535", entity="Fact Due Diligence Score", kind="Fact",
             grain="manager due diligence review x scoring factor",
             dimensions=[dict(name="scoring_factor", attr="Scoring Factor")],
             facts=[dict(name="factor_score", attr="Factor Score", note="1 to 5 scale; read only through the weighted score"),
                    dict(name="factor_weight", attr="Factor Weight")]),
        dict(name="onsite_visit", product="DP-535", entity="Fact Onsite Visit", kind="Fact",
             grain="manager due diligence review x visit date",
             dimensions=[dict(name="visit_date", attr="Visit Date"),
                         dict(name="virtual_visit", attr="Virtual Visit Indicator"),
                         dict(name="areas_inspected", attr="Areas Inspected")]),
        # Restricted view (DP-535 DQ5): FCRA consumer reports on individuals. Only manager_research_restricted sees rows
        # by manager or key person; everyone else sees counts by check type only, suppressed below 10 rows.
        dict(name="background_check", product="DP-535", entity="Fact Background Check Result", kind="Fact",
             grain="manager key person x background check type x check date",
             dimensions=[dict(name="background_check_type", attr="Background Check Type"),
                         dict(name="check_date", attr="Check Date"),
                         dict(name="subject_authorization_obtained", attr="Subject Authorization Obtained Indicator"),
                         dict(name="regulatory_disclosure_found", attr="Regulatory Disclosure Found Indicator"),
                         dict(name="background_check_outcome", attr="Background Check Outcome")]),
        # One product due diligence table: DP-535's entity is DP-306's Product Due Diligence (conformed) plus the
        # approving committee decision, so DP-306's copy is not read a second time.
        dict(name="product_due_diligence", product="DP-535", entity="Fact Product Due Diligence", kind="Fact",
             grain="third-party product (17 instrument) x due diligence review (TPDUE-)",
             dimensions=[dict(name="product_use_scopes", attr="Product Use Scopes",
                              note="Multi-valued; filter, do not group without the many-to-many warning in mind"),
                         dict(name="full_due_diligence", attr="Full Due Diligence Indicator"),
                         dict(name="complex_product", attr="Complex Product Indicator"),
                         dict(name="product_due_diligence_outcome", attr="Product Due Diligence Outcome"),
                         dict(name="product_review_effective_date", attr="Product Review Effective Date"),
                         dict(name="product_next_review_due_date", attr="Product Next Review Due Date")]),
        dict(name="criterion_result", product="DP-535", entity="Fact Product Criterion Result", kind="Fact",
             grain="product due diligence x criterion",
             dimensions=[dict(name="product_due_diligence_criterion", attr="Product Due Diligence Criterion"),
                         dict(name="criterion_value", attr="Criterion Value"),
                         dict(name="criterion_threshold", attr="Criterion Threshold"),
                         dict(name="criterion_result", attr="Criterion Result")]),
        dict(name="fund_of_funds_use", product="DP-535", entity="Fact Fund of Funds Use", kind="Fact",
             grain="product due diligence x acquiring fund of funds",
             dimensions=[dict(name="exceeds_12d1_limits", attr="Exceeds Section 12(d)(1) Limits Indicator"),
                         dict(name="evaluation_findings_date", attr="Evaluation Findings Date"),
                         dict(name="duplicative_fees_assessment", attr="Duplicative Fees Assessment")]),

        # ======================= DP-536 Sub-Adviser Oversight Scorecard ===========================================
        # One watch table: DP-536's entity is DP-306's Sub-Adviser Watch Status (conformed) plus the deciding review.
        dict(name="watch_status", product="DP-536", entity="Sub-Adviser Watch Status", kind="Fact",
             grain="sub-adviser engagement x watch status period",
             default_filter="the watch period in force on the as-of date: watch_effective_from <= as_of_date and "
                            "(watch_effective_to is null or watch_effective_to > as_of_date)",
             dimensions=[dict(name="watch_status", attr="Watch Status"),
                         dict(name="watch_reason", attr="Watch Reason"),
                         dict(name="watch_review_deadline", attr="Watch Review Deadline"),
                         dict(name="watch_effective_from", attr="Watch Effective From"),
                         dict(name="watch_effective_to", attr="Watch Effective To")]),
        dict(name="oversight_review", product="DP-536", entity="Fact Oversight Review", kind="Fact",
             grain="one oversight review (OVRVW-) of an engagement for a review period",
             dimensions=[dict(name="oversight_review_type", attr="Oversight Review Type"),
                         dict(name="review_period_start", attr="Review Period Start"),
                         dict(name="review_period_end", attr="Review Period End"),
                         dict(name="engagement_review_conclusion", attr="Engagement Review Conclusion"),
                         dict(name="conclusion_commentary", attr="Conclusion Commentary"),
                         dict(name="oversight_review_completed_date", attr="Review Completed Date")],
             hidden=[("Oversight Reviewer", "An employee reference (DP-192); no cross-engagement question needs it.")]),
        # Metric Value mixes units (percent, rank, count): it is shown per reading and never summed across metrics.
        dict(name="metric_reading", product="DP-536", entity="Fact Oversight Metric Reading", kind="Fact",
             grain="sub-adviser engagement x oversight review (review period) x oversight metric",
             dimensions=[dict(name="oversight_metric", attr="Oversight Metric"),
                         dict(name="metric_unit", attr="Metric Unit"),
                         dict(name="metric_source_domain", attr="Metric Source Domain"),
                         dict(name="metric_flag", attr="Metric Flag"),
                         dict(name="holdings_as_of_date", attr="Holdings As-Of Date"),
                         dict(name="source_return_version", attr="Source Return Version")],
             facts=[dict(name="metric_value", attr="Metric Value",
                         note="One oversight metric at a time; a reading of a certified number is a pinned copy and "
                              "the certified value is the ref metric")],
             hidden=[("Source Performance Return", "A pinned DP-145 key; used by the tie-out metric, not shown."),
                     ("Source Benchmark Return", "A pinned DP-145 key; used by the tie-out metric, not shown."),
                     ("Source Ex-Post Risk Statistic", "A pinned 32 statistic key (DP-157); used by the tie-out metric."),
                     ("Source Risk Measure", "A pinned DP-146 key; used by the tie-out metric, not shown."),
                     ("Source Peer Metric Snapshot", "A pinned DP-014 key; used by the tie-out metric, not shown."),
                     ("Source Fee Benchmark Result", "A pinned DP-506 key; used by the tie-out metric, not shown."),
                     ("Source Financial Highlights", "A pinned DP-165 key; used by the tie-out metric, not shown."),
                     ("Breach Count Guideline Set", "The guideline set version a breach count was taken against."),
                     ("Source Investment Breaches", "A multi-valued list of DP-163 breach keys; counted, not joined.")]),
        dict(name="metric_threshold", product="DP-536", entity="Oversight Metric Threshold", kind="Dimension",
             always_filter=["the threshold in force on the reading's review_period_end: threshold_effective_from <= "
                            "review_period_end and (threshold_effective_to is null or threshold_effective_to > "
                            "review_period_end)"],
             dimensions=[dict(name="threshold_limit_type", attr="Threshold Limit Type"),
                         dict(name="threshold_value", attr="Threshold Value"),
                         dict(name="warning_value", attr="Warning Value"),
                         dict(name="threshold_effective_from", attr="Threshold Effective From"),
                         dict(name="threshold_effective_to", attr="Threshold Effective To")]),
        dict(name="compliance_certification", product="DP-536", entity="Fact Compliance Certification", kind="Fact",
             grain="certification subject (manager or engagement) x certification type x certification period",
             dimensions=[dict(name="certification_type", attr="Certification Type"),
                         dict(name="certification_period_end", attr="Certification Period End"),
                         dict(name="certification_due_date", attr="Certification Due Date"),
                         dict(name="certification_received_date", attr="Certification Received Date"),
                         dict(name="exceptions_reported", attr="Exceptions Reported Indicator")],
             hidden=[("Linked Investment Breaches", "A multi-valued list of DP-163 breach keys; counted, not joined.")]),
        dict(name="guideline_inclusion", product="DP-536", entity="Fact Guideline Rule Inclusion", kind="Fact",
             grain="guideline set version x 33 compliance rule version or 01 investment restriction",
             dimensions=[dict(name="inclusion_type", attr="Inclusion Type"),
                         dict(name="included_rule_version", attr="Included Rule Version")]),
        dict(name="oversight_finding", product="DP-536", entity="Fact Oversight Finding", kind="Fact",
             grain="one oversight finding (OVFND-)",
             dimensions=[dict(name="finding_source_type", attr="Finding Source Type"),
                         dict(name="finding_category", attr="Finding Category"),
                         dict(name="finding_severity", attr="Finding Severity"),
                         dict(name="finding_due_date", attr="Finding Due Date"),
                         dict(name="finding_status", attr="Finding Status"),
                         dict(name="finding_closed_date", attr="Finding Closed Date")]),
        dict(name="remediation_action", product="DP-536", entity="Fact Remediation Action", kind="Fact",
             grain="oversight finding x action sequence",
             dimensions=[dict(name="action_sequence", attr="Action Sequence"),
                         dict(name="committed_date", attr="Committed Date"),
                         dict(name="completed_date", attr="Completed Date")]),

        # ======================= DP-538 Hires, Terminations & Section 15(c) Renewal Evidence ======================
        # DP-538's agreement entity is DP-306's Fund Advisory Agreement (conformed) plus the agreement type.
        dict(name="fund_advisory_agreement", product="DP-538", entity="Fund Advisory Agreement", kind="Dimension",
             dimensions=[dict(name="advisory_agreement_type", attr="Advisory Agreement Type"),
                         dict(name="advisory_agreement_status", attr="Advisory Agreement Status"),
                         dict(name="agreement_effective_date", attr="Agreement Effective Date"),
                         dict(name="agreement_termination_date", attr="Agreement Termination Date")]),
        dict(name="contract_renewal", product="DP-538", entity="Advisory Contract Renewal", kind="Dimension",
             dimensions=[dict(name="renewal_year", attr="Renewal Year"),
                         dict(name="request_15c_date", attr="15(c) Request Date"),
                         dict(name="materials_delivered_date", attr="Materials Delivered Date")]),
        dict(name="board_resolution", product="DP-538", entity="Board Resolution", kind="Dimension",
             dimensions=[dict(name="resolution_type", attr="Resolution Type"),
                         dict(name="resolution_outcome", attr="Resolution Outcome"),
                         dict(name="resolution_effective_date", attr="Resolution Effective Date")]),
        dict(name="exemptive_relief", product="DP-538", entity="Exemptive Relief Reliance", kind="Dimension",
             dimensions=[dict(name="exemptive_relief_type", attr="Exemptive Relief Type"),
                         dict(name="reliance_effective_from", attr="Reliance Effective From"),
                         dict(name="reliance_effective_to", attr="Reliance Effective To")]),
        dict(name="renewal_submission", product="DP-538", entity="Fact Section 15(c) Renewal Submission", kind="Fact",
             grain="sub-adviser engagement x 35 advisory contract renewal (renewal year); every year kept",
             dimensions=[dict(name="questionnaire_sent_to_sub_adviser", attr="Questionnaire Sent to Sub-Adviser Date"),
                         dict(name="sub_adviser_response_received", attr="Sub-Adviser Response Received Date"),
                         dict(name="renewal_recommendation", attr="Renewal Recommendation"),
                         dict(name="recommendation_rationale", attr="Recommendation Rationale"),
                         dict(name="submission_delivered_date", attr="Submission Delivered Date")],
             hidden=[("Included Oversight Reviews", "A multi-valued list of DP-536 review keys; read by the "
                                                    "current-review metric, never joined row to row.")]),
        # One termination table: DP-538's entity is DP-306's Manager Termination (conformed) plus the originating search
        # and transition event, so DP-306's copy is not read a second time.
        dict(name="termination", product="DP-538", entity="Fact Manager Termination", kind="Fact",
             grain="sub-adviser engagement x termination effective date",
             dimensions=[dict(name="termination_reason", attr="Termination Reason"),
                         dict(name="termination_notice_date", attr="Termination Notice Date"),
                         dict(name="termination_effective_date", attr="Termination Effective Date")]),
        dict(name="transition_event", product="DP-538", entity="Fact Transition Event", kind="Fact",
             grain="one transition event (TRN-)",
             dimensions=[dict(name="transition_type", attr="Transition Type"),
                         dict(name="in_specie", attr="In-Specie Indicator"),
                         dict(name="actual_completion_date", attr="Actual Completion Date"),
                         dict(name="post_transition_report_delivered", attr="Post-Transition Report Delivered Indicator")],
             facts=[dict(name="transition_total_cost", attr="Transition Total Cost")]),
        # The investment committee decisions behind hires, terminations, thresholds and product approvals. DP-538's copy
        # carries the most columns of the three product copies (DP-535, DP-536, DP-538); see open decisions.
        dict(name="committee_decision", product="DP-538", entity="Investment Committee Decision", kind="Dimension",
             dimensions=[dict(name="decision_committee", attr="Decision Committee"),
                         dict(name="decision_meeting_date", attr="Decision Meeting Date"),
                         dict(name="committee_decision_type", attr="Committee Decision Type"),
                         dict(name="committee_decision_outcome", attr="Committee Decision Outcome"),
                         dict(name="decision_effective_date", attr="Decision Effective Date")]),

        # ======================= Certified facts read only to slice referenced metrics by engagement =============
        dict(name="sleeve_return", product="DP-145", entity="Performance Return", kind="Fact",
             grain="sleeve portfolio x return period x fee basis x calculation basis x currency (version of record)",
             always_filter=_RETURN_OF_RECORD,
             default_filter="Hypothetical Indicator = 'N'",
             dimensions=[dict(name="return_period_start", attr="Return Period Start Date"),
                         dict(name="return_period_end", attr="Return Period End Date"),
                         dict(name="return_period_basis", attr="Return Period Basis"),
                         dict(name="return_fee_basis", attr="Return Fee Basis"),
                         dict(name="return_currency", attr="Return Currency")],
             facts=[dict(name="return_value", attr="Return Value", note="Read only through [Official Return]")]),
        dict(name="benchmark_return", product="DP-145", entity="Benchmark Return", kind="Fact",
             grain="benchmark x period x return type x currency x hedged basis (version of record)",
             always_filter=["Benchmark Return Status in ('Final', 'Restated')",
                            "Benchmark Return Version = the highest version of the same benchmark, period, return type, "
                            "currency and hedged basis"],
             dimensions=[dict(name="benchmark_period_end", attr="Benchmark Period End Date"),
                         dict(name="benchmark_period_basis", attr="Benchmark Period Basis"),
                         dict(name="benchmark_return_currency", attr="Benchmark Return Currency")],
             facts=[dict(name="benchmark_return_value", attr="Benchmark Return Value",
                         note="Read only through [Benchmark Return]")]),
        dict(name="sleeve_risk", product="DP-146", entity="Portfolio Risk Measure", kind="Fact",
             grain="approved risk calculation run x sleeve portfolio x risk measure x benchmark",
             always_filter=["measure_calculation_run is an approved and completed Risk Calculation Run (SM-10)",
                            "one risk model per query",
                            "risk_measure = 'Ex-Ante Tracking Error' and measured_portfolio is the Sleeve Portfolio of a "
                            "sub-adviser engagement"],
             default_filter="run as-of date = the latest as-of date with an approved run",
             dimensions=[dict(name="risk_measure", attr="Risk Measure"),
                         dict(name="measure_benchmark", attr="Measure Benchmark")],
             facts=[dict(name="risk_measure_value", attr="Risk Measure Value",
                         note="Read only through [Ex-Ante Tracking Error]")]),
    ],

    shared=["DP-240/Party", "DP-004/Investment Product", "DP-004/Share Class", "DP-140/Investment Mandate",
            "DP-140/Portfolio", "DP-213/Contract", "DP-097/Instrument", "DP-013/Calendar Date",
            "DP-013/Internal Legal Entity"],

    relationships=[
        # Manager and engagement (DP-306)
        dict(frm="manager", to="DP-240/Party", on="manager.profiled_manager = party.party_id", type="one-to-one",
             warning="Managers are organizations; the same party table holds key persons, who are never joined here."),
        dict(frm="manager_strategy", to="manager", on="manager_strategy.strategy_manager = manager.profiled_manager",
             type="many-to-one"),
        dict(frm="key_person", to="manager", on="key_person.key_person_manager = manager.profiled_manager",
             type="many-to-one"),
        dict(frm="engagement", to="manager", on="engagement.engaged_sub_adviser = manager.profiled_manager",
             type="many-to-one"),
        dict(frm="engagement", to="manager_strategy",
             on="engagement.engaged_strategy = manager_strategy.external_manager_strategy_id", type="many-to-one"),
        dict(frm="engagement", to="DP-004/Investment Product", on="engagement.engaged_fund = investment_product.product_id",
             type="many-to-one"),
        dict(frm="engagement", to="DP-140/Investment Mandate", on="engagement.delegated_mandate = investment_mandate.mandate_id",
             type="many-to-one"),
        dict(frm="engagement", to="DP-140/Portfolio", on="engagement.sleeve_portfolio = portfolio.portfolio_id",
             type="many-to-one"),
        dict(frm="engagement", to="DP-213/Contract", on="engagement.governing_contract = contract.contract_id",
             type="many-to-one"),
        dict(frm="engagement", to="fund_advisory_agreement",
             on="engagement.governing_fund_agreement = fund_advisory_agreement.advisory_agreement_id", type="many-to-one"),
        dict(frm="engagement", to="DP-013/Internal Legal Entity",
             on="engagement.overseeing_adviser_entity = internal_legal_entity.legal_entity_id", type="many-to-one"),
        dict(frm="engagement", to="exemptive_relief",
             on="engagement.relied_on_exemptive_relief = exemptive_relief key, with relying_fund = engagement.engaged_fund "
                "and exemptive_relief_type = 'Manager of Managers'", type="many-to-one"),
        dict(frm="engagement", to="DP-013/Calendar Date", on="engagement.engagement_start_date = calendar_date.calendar_date",
             type="many-to-one"),
        dict(frm="guideline_set", to="engagement", on="guideline_set.guideline_engagement = engagement.engagement_id",
             type="many-to-one",
             warning="Every guideline version of an engagement is kept; without the current-version default filter an "
                     "engagement counts once per version."),
        dict(frm="fund_advisory_agreement", to="DP-240/Party", on="fund_advisory_agreement.external_sub_adviser = party.party_id",
             type="many-to-one"),
        dict(frm="exemptive_relief", to="DP-004/Investment Product", on="exemptive_relief.relying_fund = investment_product.product_id",
             type="many-to-one"),
        # Third-party product lists and due diligence (DP-306, DP-535)
        dict(frm="product_list_status", to="DP-097/Instrument", on="product_list_status.listed_instrument = instrument.instrument_id",
             type="many-to-one"),
        dict(frm="product_list_status", to="product_due_diligence",
             on="product_list_status.deciding_product_review = product_due_diligence.product_due_diligence_id",
             type="many-to-one"),
        dict(frm="product_due_diligence", to="DP-097/Instrument",
             on="product_due_diligence.reviewed_instrument = instrument.instrument_id", type="many-to-one"),
        dict(frm="product_due_diligence", to="committee_decision",
             on="product_due_diligence.product_approving_decision = committee_decision key", type="many-to-one"),
        dict(frm="DP-097/Instrument", to="DP-004/Share Class", on="instrument.own_share_class = share_class.share_class_id",
             type="many-to-one"),
        dict(frm="criterion_result", to="product_due_diligence",
             on="criterion_result.criterion_product_review = product_due_diligence.product_due_diligence_id",
             type="many-to-one",
             warning="A review has many criteria; count reviews with count(distinct product_due_diligence), never rows "
                     "of criterion_result."),
        dict(frm="fund_of_funds_use", to="product_due_diligence",
             on="fund_of_funds_use.fund_of_funds_product_review = product_due_diligence.product_due_diligence_id",
             type="many-to-one"),
        dict(frm="fund_of_funds_use", to="DP-004/Investment Product",
             on="fund_of_funds_use.acquiring_fund = investment_product.product_id", type="many-to-one"),
        dict(frm="fund_of_funds_use", to="DP-213/Contract",
             on="fund_of_funds_use.fund_of_funds_investment_agreement = contract.contract_id", type="many-to-one"),
        # Searches and manager due diligence (DP-535)
        dict(frm="search_candidate", to="manager_search", on="search_candidate.candidate_search = manager_search.manager_search_id",
             type="many-to-one"),
        dict(frm="search_candidate", to="manager_strategy",
             on="search_candidate.candidate_strategy = manager_strategy.external_manager_strategy_id", type="many-to-one"),
        dict(frm="manager_search", to="DP-004/Investment Product", on="manager_search.target_product = investment_product.product_id",
             type="many-to-one"),
        dict(frm="manager_search", to="DP-140/Investment Mandate", on="manager_search.target_mandate = investment_mandate.mandate_id",
             type="many-to-one"),
        dict(frm="manager_search", to="manager_strategy",
             on="manager_search.selected_strategy = manager_strategy.external_manager_strategy_id", type="many-to-one"),
        dict(frm="manager_search", to="committee_decision",
             on="manager_search.approving_committee_decision = committee_decision key", type="many-to-one"),
        dict(frm="manager_search", to="engagement", on="manager_search.resulting_engagement = engagement.engagement_id",
             type="many-to-one"),
        dict(frm="dd_review", to="manager", on="dd_review.reviewed_manager = manager.profiled_manager", type="many-to-one"),
        dict(frm="dd_review", to="manager_strategy",
             on="dd_review.reviewed_strategy = manager_strategy.external_manager_strategy_id", type="many-to-one"),
        dict(frm="dd_review", to="questionnaire_template",
             on="dd_review.questionnaire_template_used = questionnaire_template key (code and version)", type="many-to-one"),
        dict(frm="dd_score", to="dd_review", on="dd_score.scored_review = dd_review.manager_due_diligence_review_id",
             type="many-to-one",
             warning="A review has one row per scoring factor; never count reviews from dd_score rows."),
        dict(frm="onsite_visit", to="dd_review", on="onsite_visit.visited_review = dd_review.manager_due_diligence_review_id",
             type="many-to-one"),
        dict(frm="background_check", to="key_person",
             on="background_check.checked_key_person = key_person key (manager, key person, role, role start date)",
             type="many-to-one",
             warning="Restricted view: only manager_research_restricted may group background checks by key person or "
                     "manager. A key person with two roles has two key_person rows, so count checks with "
                     "count(distinct background check key), not rows after the join."),
        # Oversight scorecard (DP-536)
        dict(frm="watch_status", to="engagement", on="watch_status.watched_engagement = engagement.engagement_id",
             type="many-to-one",
             warning="Every watch period is kept; without the as-of default filter an engagement counts once per period."),
        dict(frm="watch_status", to="oversight_review",
             on="watch_status.deciding_oversight_review = oversight_review.oversight_review_id", type="many-to-one"),
        dict(frm="oversight_review", to="engagement", on="oversight_review.reviewed_engagement = engagement.engagement_id",
             type="many-to-one"),
        dict(frm="oversight_review", to="DP-013/Calendar Date",
             on="oversight_review.review_period_end = calendar_date.calendar_date", type="many-to-one"),
        dict(frm="metric_reading", to="oversight_review",
             on="metric_reading.reading_review = oversight_review.oversight_review_id", type="many-to-one"),
        dict(frm="metric_reading", to="metric_threshold",
             on="metric_threshold.threshold_engagement = oversight_review.reviewed_engagement and "
                "metric_threshold.threshold_metric = metric_reading.oversight_metric, effective on review_period_end",
             type="many-to-one"),
        dict(frm="metric_threshold", to="committee_decision",
             on="metric_threshold.threshold_approving_decision = committee_decision key", type="many-to-one"),
        dict(frm="metric_reading", to="sleeve_return",
             on="metric_reading.source_performance_return = sleeve_return.performance_return_id and "
                "metric_reading.source_return_version = sleeve_return.return_version", type="many-to-one"),
        dict(frm="metric_reading", to="benchmark_return",
             on="metric_reading.source_benchmark_return = benchmark_return key", type="many-to-one"),
        dict(frm="metric_reading", to="sleeve_risk", on="metric_reading.source_risk_measure = sleeve_risk key",
             type="many-to-one"),
        dict(frm="sleeve_return", to="DP-140/Portfolio", on="sleeve_return.return_portfolio = portfolio.portfolio_id",
             type="many-to-one"),
        dict(frm="sleeve_risk", to="DP-140/Portfolio", on="sleeve_risk.measured_portfolio = portfolio.portfolio_id",
             type="many-to-one"),
        dict(frm="compliance_certification", to="manager",
             on="compliance_certification.certifying_manager = manager.profiled_manager", type="many-to-one"),
        dict(frm="compliance_certification", to="engagement",
             on="compliance_certification.certifying_engagement = engagement.engagement_id", type="many-to-one"),
        dict(frm="guideline_inclusion", to="guideline_set",
             on="guideline_inclusion.inclusion_guideline_set = guideline_set.guideline_set_id", type="many-to-one"),
        dict(frm="oversight_finding", to="manager", on="oversight_finding.finding_manager = manager.profiled_manager",
             type="many-to-one"),
        dict(frm="oversight_finding", to="oversight_review",
             on="oversight_finding.source_oversight_review = oversight_review.oversight_review_id", type="many-to-one"),
        dict(frm="oversight_finding", to="compliance_certification",
             on="oversight_finding.source_certification = compliance_certification key", type="many-to-one"),
        dict(frm="remediation_action", to="oversight_finding",
             on="remediation_action.remediated_finding = oversight_finding.oversight_finding_id", type="many-to-one",
             warning="A finding has several actions; count findings with count(distinct oversight_finding)."),
        # Hires, renewals and terminations (DP-538)
        dict(frm="renewal_submission", to="engagement", on="renewal_submission.submission_engagement = engagement.engagement_id",
             type="many-to-one"),
        dict(frm="renewal_submission", to="contract_renewal",
             on="renewal_submission.submission_renewal = contract_renewal.renewal_id", type="many-to-one"),
        dict(frm="renewal_submission", to="oversight_review",
             on="renewal_submission.included_oversight_reviews contains oversight_review.oversight_review_id",
             type="many-to-many",
             warning="A submission includes several oversight reviews and a review can support several renewal years. "
                     "Use the join only to test whether a current review was included; never count submissions or "
                     "reviews through it."),
        dict(frm="contract_renewal", to="fund_advisory_agreement",
             on="contract_renewal.renewed_agreement = fund_advisory_agreement.advisory_agreement_id", type="many-to-one"),
        dict(frm="contract_renewal", to="board_resolution",
             on="contract_renewal.renewal_approving_resolution = board_resolution.board_resolution_id", type="many-to-one"),
        dict(frm="termination", to="engagement", on="termination.terminated_engagement = engagement.engagement_id",
             type="many-to-one"),
        dict(frm="termination", to="committee_decision",
             on="termination.deciding_committee_decision = committee_decision key", type="many-to-one"),
        dict(frm="termination", to="transition_event", on="termination.transition_event = transition_event.transition_id",
             type="many-to-one"),
        dict(frm="termination", to="manager_search", on="termination.originating_search = manager_search.manager_search_id",
             type="many-to-one"),
        dict(frm="termination", to="DP-013/Calendar Date",
             on="termination.termination_effective_date = calendar_date.calendar_date", type="many-to-one"),
    ],

    hierarchies=[
        dict(name="Manager and strategy", levels=["manager.research_coverage_status", "manager_strategy.strategy_asset_class",
                                                   "manager_strategy.manager_strategy_name"]),
        dict(name="Engagement", levels=["engagement.engagement_scope", "engagement.engagement_status",
                                        "engagement.engagement_id"]),
        dict(name="Oversight finding", levels=["oversight_finding.finding_severity", "oversight_finding.finding_category"]),
        dict(name="Renewal", levels=["contract_renewal.renewal_year", "renewal_submission.renewal_recommendation"]),
    ],

    metrics=[
        # ================= Certified, owned elsewhere; sliced here by engagement, sleeve or fund ===================
        dict(name="Official Return", ref="SM-08/Official Return",
             note="Read from sleeve_return: the version of record of the engagement's Sleeve Portfolio; the oversight "
                  "reading is a pinned copy tied out by Return Reading Tie-Out."),
        dict(name="Benchmark Return", ref="SM-08/Benchmark Return",
             note="Read from benchmark_return for the benchmark the reading pinned."),
        dict(name="Ex-Ante Tracking Error", ref="SM-10/Ex-Ante Tracking Error",
             note="Read from sleeve_risk for the engagement's Sleeve Portfolio, approved runs only."),
        dict(name="Firm AUM - Own Funds at NAV", ref="SM-11/Firm AUM - Own Funds at NAV",
             note="Sliced by engagement.engaged_fund through DP-004/Investment Product: the net assets of sub-advised "
                  "funds. Not split by sleeve (see cannot_answer)."),
        dict(name="Firm AUM - Institutional & OCIO", ref="SM-11/Firm AUM - Institutional & OCIO",
             note="Sliced by engagement.delegated_mandate through DP-140/Investment Mandate: delegated mandate assets."),
        dict(name="Fund Total Net Assets", ref="SM-11/Fund Total Net Assets",
             note="The engaged fund's net assets at its NAV of record, shown beside the engagement."),

        # ================= DP-306 Manager & Sub-Adviser Master ====================================================
        dict(name="Covered External Managers", aggregation="count_distinct",
             expr="count(distinct manager.profiled_manager) where research_coverage_status in ('Under Review', "
                  "'Approved', 'Watch') (profile effective on the as-of date)",
             source=("DP-306", "Covered External Managers"),
             description="Number of external managers under research coverage on the as-of date."),
        dict(name="Managers With Stale Form ADV Review", aggregation="count_distinct",
             expr="[Covered External Managers] where form_adv_last_reviewed is null or more than 12 months before the "
                  "as-of date",
             source=("DP-306", "Managers With Stale Form ADV Review"),
             description="Covered managers whose Form ADV has not been reviewed in the last 12 months."),
        dict(name="Key Person Departures", aggregation="additive",
             expr="count(key_person) where key_person_flag = 'Y' and key_person_departure_date in range",
             source=("DP-306", "Key Person Departures"),
             description="Departures of designated key persons at any covered manager in the period, by role."),
        dict(name="Late Key Person Notifications", aggregation="additive",
             expr="[Key Person Departures] where key_person_notified_date is null or more than 5 business days after "
                  "key_person_departure_date",
             source=("DP-306", "Late Key Person Notifications"),
             description="Key person departures the manager notified late or not at all."),
        dict(name="Active Sub-Adviser Engagements", aggregation="count_distinct",
             expr="count(distinct engagement.engagement_id) where engagement_status = 'Active' and engagement_start_date "
                  "<= as-of date and (engagement_end_date is null or engagement_end_date > as-of date)",
             source=("DP-306", "Active Sub-Adviser Engagements"),
             description="Number of sub-adviser engagements active on the as-of date, by scope and delegation."),
        dict(name="Engagements Without Active Agreement", aggregation="count_distinct",
             expr="[Active Sub-Adviser Engagements] where (engaged_fund is not null and fund_advisory_agreement is "
                  "missing or advisory_agreement_status <> 'Active') or (delegated_mandate is not null and the governing "
                  "DP-213 contract is missing or its contract_status <> 'Active')",
             source=("DP-306", "Engagements Without Active Agreement"),
             description="Active engagements not covered by an active sub-advisory agreement or contract."),
        dict(name="Fund Engagements Without Board Approval", aggregation="count_distinct",
             expr="[Active Sub-Adviser Engagements] where engaged_fund is not null and (board_approval_date is null or "
                  "board_approval_date > engagement_start_date)",
             source=("DP-306", "Fund Engagements Without Board Approval"),
             description="Active fund engagements with no board approval on or before their start."),
        dict(name="Overdue Information Statements", aggregation="count_distinct",
             expr="count(distinct engagement.engagement_id) where information_statement_due < as-of date and "
                  "information_statement_sent is null",
             source=("DP-306", "Overdue Information Statements"),
             description="Manager-of-managers hires whose information statement is past due and not yet sent."),
        dict(name="Engagements Without Acknowledged Guidelines", aggregation="count_distinct",
             expr="[Active Sub-Adviser Engagements] whose current guideline_set is missing or has "
                  "guideline_delivered_date or guideline_acknowledged_date null",
             source=("DP-306", "Engagements Without Acknowledged Guidelines"),
             description="Active engagements whose current investment guidelines were not delivered and acknowledged."),
        dict(name="Engagements by Watch Status", aggregation="count_distinct",
             expr="[Active Sub-Adviser Engagements] grouped by the watch_status row in force on the as-of date "
                  "(engagements with no watch row shown as 'Not on watch')",
             source=("DP-306", "Engagements by Watch Status"),
             description="Active engagements by their watch status and reason on the as-of date."),
        dict(name="Watch Reviews Past Deadline", aggregation="count_distinct",
             expr="[Engagements by Watch Status] where watch_status in ('Watch', 'Under Review', 'Termination "
                  "Recommended') and watch_review_deadline < as-of date",
             source=("DP-306", "Watch Reviews Past Deadline"),
             description="Engagements on watch whose review deadline has passed."),
        dict(name="Listed Third-Party Products", aggregation="count_distinct",
             expr="count(distinct product_list_status.listed_instrument) by list_scope and product_list_status "
                  "(status in force on the as-of date)",
             source=("DP-306", "Listed Third-Party Products"),
             description="Third-party products on each approved, watch or restricted list on the as-of date.",
             note="An instrument on two list scopes counts once in each scope; the total across scopes is a distinct "
                  "count, not the sum of the scope rows."),
        dict(name="Approved Products Without Current Due Diligence", aggregation="count_distinct",
             expr="[Listed Third-Party Products] where product_list_status = 'Approved' and (deciding_product_review and "
                  "deciding_oversight_review are both null, or no product_due_diligence of the instrument has "
                  "product_next_review_due_date >= as-of date)",
             source=("DP-306", "Approved Products Without Current Due Diligence"),
             description="Approved third-party products whose due diligence is missing or past its next review date."),
        dict(name="Complex Products Approved Without Full Review", aggregation="count_distinct",
             expr="count(distinct product_due_diligence) where complex_product = 'Y' and product_due_diligence_outcome "
                  "in ('Approve', 'Approve with Conditions') and full_due_diligence <> 'Y'",
             source=("DP-306", "Complex Products Approved Without Full Review"),
             description="Complex third-party products approved on a lighter review than full due diligence."),
        dict(name="Own Products on Third-Party List", aggregation="count_distinct",
             expr="[Listed Third-Party Products] where the listed instrument's own_share_class is not null",
             source=("DP-306", "Own Products on Third-Party List"),
             description="The firm's own products found on a third-party list (they belong in product governance).",
             note="A control: should always be zero. Own products are SM-30's product governance."),

        # ================= DP-535 Manager Search, Selection & Due Diligence =======================================
        dict(name="Open Manager Searches", aggregation="count_distinct",
             expr="count(distinct manager_search) where search_status not in ('Resolved / Completed', 'Closed', "
                  "'Canceled'); search age = as-of date - search_opened_date",
             source=("DP-535", "Open Manager Searches"),
             description="Manager searches still open on the as-of date, by search need and target fund or mandate."),
        dict(name="Search Cycle Days", aggregation="non_additive",
             expr="median and maximum of (search_closed_date - search_opened_date) for searches closed in range with a "
                  "selected strategy",
             source=("DP-535", "Search Cycle Days"),
             description="Calendar days from opening a manager search to closing it with a selection.",
             note="A median: recomputed from the search rows for each selection."),
        dict(name="Candidates by Search Stage", aggregation="additive",
             expr="count(search_candidate) by search_stage, and of eliminated candidates by elimination_reason",
             source=("DP-535", "Candidates by Search Stage"),
             description="Candidate strategies in open searches at each stage, and why candidates were eliminated."),
        dict(name="Recommendations Without Committee Approval", aggregation="count_distinct",
             expr="count(distinct manager_search) with recommendation_date in range whose committee_decision is missing, "
                  "or has committee_decision_type <> 'Manager Hire' or committee_decision_outcome not in ('Approved', "
                  "'Approved with Conditions')",
             source=("DP-535", "Recommendations Without Committee Approval"),
             description="Search recommendations made without an approving investment committee hire decision."),
        dict(name="Selected Strategies Without Completed Due Diligence", aggregation="count_distinct",
             expr="count(distinct manager_search) whose selected strategy has no approving dd_review of questionnaire "
                  "type Investment (by strategy) or Operational (by manager) completed on or before recommendation_date",
             source=("DP-535", "Selected Strategies Without Completed Due Diligence"),
             description="Selections made before both investment and operational due diligence were completed."),
        dict(name="Approved Hires Without Engagement", aggregation="count_distinct",
             expr="count(distinct manager_search) approved (not in Recommendations Without Committee Approval) whose "
                  "resulting engagement is missing more than 90 days after recommendation_date",
             source=("DP-535", "Approved Hires Without Engagement"),
             description="Approved manager hires with no sub-adviser engagement set up within 90 days."),
        dict(name="Due Diligence Reviews Overdue", aggregation="count_distinct",
             expr="count(distinct manager) with research_coverage_status in ('Approved', 'Watch') whose latest dd_review "
                  "of a questionnaire type has next_review_due_date < as-of date and no later completed review",
             source=("DP-535", "Due Diligence Reviews Overdue"),
             description="Covered managers whose investment or operational due diligence is overdue for renewal.",
             note="A manager overdue on both questionnaire types counts once in the total and once in each type."),
        dict(name="Questionnaire Turnaround Days", aggregation="non_additive",
             expr="median of (questionnaire_received_date - questionnaire_sent_date) by questionnaire_type; reviews sent "
                  "more than 45 days ago with no response counted as outstanding",
             source=("DP-535", "Questionnaire Turnaround Days"),
             description="How quickly managers return due diligence questionnaires, and how many are outstanding."),
        dict(name="Reviews on Superseded Templates", aggregation="count_distinct",
             expr="count(distinct dd_review) whose questionnaire_template had template_status <> 'Active' or "
                  "template_effective_to < questionnaire_sent_date",
             source=("DP-535", "Reviews on Superseded Templates"),
             description="Due diligence reviews sent on a questionnaire version no longer in force."),
        dict(name="Weighted Due Diligence Score", aggregation="non_additive",
             expr="per review: sum(dd_score.factor_score x dd_score.factor_weight) / sum(dd_score.factor_weight)",
             source=("DP-535", "Weighted Due Diligence Score"),
             description="A review's 1-to-5 due diligence score weighted by factor, shown beside its overall rating.",
             note="Defined per review; not averaged across reviews or managers."),
        dict(name="Operational Reviews Without Onsite Visit", aggregation="count_distinct",
             expr="count(distinct dd_review) completed, questionnaire_type = 'Operational', with no onsite_visit in the "
                  "24 months before review_completed_date (virtual-only visits counted separately)",
             source=("DP-535", "Operational Reviews Without Onsite Visit"),
             description="Completed operational due diligence reviews with no recent onsite visit."),
        dict(name="Key Persons Without Current Background Check", aggregation="count_distinct",
             expr="count(distinct key_person) with key_person_flag = 'Y', no departure, at covered managers, with no "
                  "background_check in the last 36 months with subject_authorization_obtained = 'Y'",
             source=("DP-535", "Key Persons Without Current Background Check"),
             description="Current key persons at covered managers without an authorized background check in 36 months.",
             note="A count by key person role and manager; it shows that a check is missing, never a check result."),
        dict(name="Adverse Background Check Outcomes", aggregation="additive",
             expr="count(background_check) with check_date in range and (background_check_outcome <> 'Clear' or "
                  "regulatory_disclosure_found = 'Y')",
             source=("DP-535", "Adverse Background Check Outcomes"),
             description="Background checks with an adverse outcome or a regulatory disclosure.",
             note="Restricted view (DQ5): by manager only for manager_research_restricted; elsewhere by check type only "
                  "and suppressed below 10 rows."),
        dict(name="Products Approved Despite Failed Criteria", aggregation="count_distinct",
             expr="count(distinct product_due_diligence) approving, effective in range, with at least one "
                  "criterion_result = 'Fail'",
             source=("DP-535", "Products Approved Despite Failed Criteria"),
             description="Third-party product approvals made although a due diligence criterion failed."),
        dict(name="Full Product Reviews Without Committee Decision", aggregation="count_distinct",
             expr="count(distinct product_due_diligence) with full_due_diligence = 'Y' and an approving outcome whose "
                  "committee_decision is missing or not of type 'Third-Party Product Approval'",
             source=("DP-535", "Full Product Reviews Without Committee Decision"),
             description="Fully reviewed third-party products approved without a committee decision."),
        dict(name="Fund of Funds Uses Without Investment Agreement", aggregation="count_distinct",
             expr="count(fund_of_funds_use) with exceeds_12d1_limits = 'Y' and no fund of funds investment agreement",
             source=("DP-535", "Fund of Funds Uses Without Investment Agreement"),
             description="Fund of funds investments above the Section 12(d)(1) limits without the Rule 12d1-4 agreement."),
        dict(name="Fund of Funds Evaluations Incomplete", aggregation="count_distinct",
             expr="count(fund_of_funds_use) with evaluation_findings_date or duplicative_fees_assessment null, or "
                  "evaluation_findings_date more than 12 months before the as-of date",
             source=("DP-535", "Fund of Funds Evaluations Incomplete"),
             description="Fund of funds uses whose evaluation or duplicative fee assessment is missing or stale."),

        # ================= DP-536 Sub-Adviser Oversight Scorecard =================================================
        dict(name="Engagements Under Review", aggregation="count_distinct",
             expr="count(distinct engagement) with engagement_status = 'Active' whose watch_status in force on the as-of "
                  "date is in ('Watch', 'Under Review', 'Termination Recommended')",
             source=("DP-536", "Engagements Under Review"),
             description="Active sub-adviser engagements on watch, under review or recommended for termination.",
             note="Acceptance question 12; shown with watch_reason, watch_effective_from and watch_review_deadline."),
        dict(name="Engagements Placed on Watch in Period", aggregation="additive",
             expr="count(watch_status) with watch_effective_from in range and watch_status in ('Watch', 'Under Review', "
                  "'Termination Recommended')",
             source=("DP-536", "Engagements Placed on Watch in Period"),
             description="Engagements newly placed on watch in the period, with the deciding review's conclusion."),
        dict(name="Watch Status Without Deciding Review", aggregation="count_distinct",
             expr="count(watch_status) in force whose deciding oversight_review is missing, belongs to another "
                  "engagement, or has engagement_review_conclusion <> watch_status",
             source=("DP-536", "Watch Status Without Deciding Review"),
             description="Watch statuses not supported by a matching oversight review."),
        dict(name="Engagements Without Current Oversight Review", aggregation="count_distinct",
             expr="[Active Sub-Adviser Engagements] with no completed oversight_review whose review_period_end falls in "
                  "the last completed calendar quarter",
             source=("DP-536", "Engagements Without Current Oversight Review"),
             description="Active engagements with no completed oversight review for the last quarter."),
        dict(name="Oversight Reviews Completed On Time %", aggregation="ratio",
             numerator="count(oversight_review) with review_period_end in range and oversight_review_completed_date <= "
                       "review_period_end + 45 days",
             denominator="count(oversight_review) with review_period_end in range",
             source=("DP-536", "Oversight Reviews Completed On Time %"),
             description="Share of oversight reviews completed within 45 days of the period end."),
        dict(name="Metric Threshold Breaches", aggregation="additive",
             expr="count(metric_reading) with metric_flag = 'Outside Threshold' in reviews with review_period_end in "
                  "range (readings flagged 'Exception Approved' shown beside them)",
             source=("DP-536", "Metric Threshold Breaches"),
             description="Oversight metric readings outside their approved threshold, by metric and engagement."),
        dict(name="Metric Threshold Warnings", aggregation="additive",
             expr="count(metric_reading) with metric_flag = 'Near Threshold' in reviews of the period",
             source=("DP-536", "Metric Threshold Warnings"),
             description="Readings between the warning value and the threshold, by metric."),
        dict(name="Engagements Without Approved Thresholds", aggregation="count_distinct",
             expr="[Active Sub-Adviser Engagements] missing an effective metric_threshold for any standard metric "
                  "(Excess Return - 3 Years, Tracking Error, Peer Percentile - 3 Years, Breach Count, Style Drift), or "
                  "whose threshold's committee_decision is missing or not approved",
             source=("DP-536", "Engagements Without Approved Thresholds"),
             description="Active engagements whose oversight thresholds are incomplete or not committee-approved."),
        dict(name="Readings Without Pinned Source", aggregation="additive",
             expr="count(metric_reading) whose source reference for its metric_source_domain is blank (52-computed "
                  "metrics need holdings_as_of_date)",
             source=("DP-536", "Readings Without Pinned Source"),
             description="Scorecard readings that do not name the source record they were taken from."),
        dict(name="Return Reading Tie-Out (to DP-145)", aggregation="additive",
             expr="count(metric_reading) with metric_source_domain = '32' whose metric_value differs by more than "
                  "0.0001 from [Official Return] (or [Official Return] - [Benchmark Return] for excess return metrics) "
                  "of the pinned rows, or whose source_return_version is not the highest version",
             source=("DP-536", "Return Reading Tie-Out (to DP-145)"),
             description="Return readings that do not agree with the certified official and benchmark returns.",
             note="The difference per reading is shown at the reading grain; the metric counts readings out of tolerance."),
        dict(name="Risk Reading Tie-Out (to DP-146 and DP-157)", aggregation="additive",
             expr="count(metric_reading) whose metric_value differs by more than 0.0001 from [Ex-Ante Tracking Error] of "
                  "the pinned sleeve_risk row, or from the pinned ex-post statistic (Final or Restated)",
             source=("DP-536", "Risk Reading Tie-Out (to DP-146 and DP-157)"),
             description="Risk readings that do not agree with the certified ex-ante or published ex-post risk numbers."),
        dict(name="Peer and Fee Reading Tie-Out (to DP-014 and DP-506)", aggregation="additive",
             expr="count(metric_reading) of Peer Percentile - 3 Years or Fee versus Peers whose metric_value differs from "
                  "the pinned peer snapshot rank or fee benchmark percentile",
             source=("DP-536", "Peer and Fee Reading Tie-Out (to DP-014 and DP-506)"),
             description="Peer rank and fee readings that do not agree with the peer and fee benchmark products."),
        dict(name="Fund Ratio Reading Tie-Out (to DP-165)", aggregation="additive",
             expr="count(metric_reading) of Turnover whose metric_value differs by more than 0.0001 from the pinned "
                  "audited Portfolio Turnover Rate, or whose highlights share class is not of the engaged fund",
             source=("DP-536", "Fund Ratio Reading Tie-Out (to DP-165)"),
             description="Turnover readings that do not agree with the audited fund financial highlights."),
        dict(name="Breach Count Tie-Out (to DP-163)", aggregation="additive",
             expr="count(metric_reading) of Breach Count whose metric_value differs from the count of listed DP-163 "
                  "breaches of the sleeve portfolio starting in the review period",
             source=("DP-536", "Breach Count Tie-Out (to DP-163)"),
             description="Breach count readings that do not agree with the compliance breach record."),
        dict(name="Key Person Departures at Engaged Managers", aggregation="additive",
             expr="[Key Person Departures] where key_person.key_person_manager is the engaged sub-adviser of an active "
                  "engagement",
             source=("DP-536", "Key Person Departures at Engaged Managers"),
             description="Key person departures at managers the firm currently employs as sub-advisers.",
             note="A subset of Key Person Departures (all covered managers)."),
        dict(name="Certifications Overdue", aggregation="count_distinct",
             expr="count(compliance_certification) with certification_due_date < as-of date and "
                  "certification_received_date null, or received after the due date in range",
             source=("DP-536", "Certifications Overdue"),
             description="Sub-adviser compliance certifications not received, or received late."),
        dict(name="Certified Exceptions Without Linked Breach", aggregation="count_distinct",
             expr="count(compliance_certification) with exceptions_reported = 'Y' whose linked investment breaches name "
                  "no DP-163 breach of the engagement's sleeve portfolio",
             source=("DP-536", "Certified Exceptions Without Linked Breach"),
             description="Certifications reporting exceptions that are not traced to a recorded breach."),
        dict(name="Guideline Inclusions on Superseded Rule Versions", aggregation="additive",
             expr="count(guideline_inclusion) of each current guideline_set whose included_rule_version is not the DP-161 "
                  "compliance rule version in force",
             source=("DP-536", "Guideline Inclusions on Superseded Rule Versions"),
             description="Sub-adviser guideline rules that point at an outdated compliance rule version."),
        dict(name="Open Oversight Findings Past Due", aggregation="count_distinct",
             expr="count(distinct oversight_finding) with finding_status not in ('Resolved / Completed', 'Closed', "
                  "'Canceled') and finding_due_date < as-of date; with the count closed in range",
             source=("DP-536", "Open Oversight Findings Past Due"),
             description="Oversight findings open past their due date, by severity, category and manager."),
        dict(name="Remediation Actions Overdue", aggregation="additive",
             expr="count(remediation_action) with committed_date < as-of date and completed_date null",
             source=("DP-536", "Remediation Actions Overdue"),
             description="Remediation actions past their committed date, by the severity of the finding."),

        # ================= DP-538 Hires, Terminations & Section 15(c) Renewal Evidence ============================
        dict(name="Sub-Adviser Hires in Period", aggregation="count_distinct",
             expr="count(distinct engagement) with engagement_start_date in range; with the count hired under a "
                  "manager-of-managers order (relied_on_exemptive_relief not null)",
             source=("DP-538", "Sub-Adviser Hires in Period"),
             description="Sub-advisers hired in the period, by scope and fund or mandate."),
        dict(name="Hires Without Board-Approved Agreement", aggregation="count_distinct",
             expr="[Sub-Adviser Hires in Period] with engaged_fund not null and (board_approval_date null or after "
                  "engagement_start_date, or the fund_advisory_agreement is effective after the start or not Active)",
             source=("DP-538", "Hires Without Board-Approved Agreement"),
             description="Fund sub-adviser hires made without a board-approved agreement in force at the start."),
        dict(name="Hires Without Exemptive Relief in Force", aggregation="count_distinct",
             expr="count(distinct engagement) with relied_on_exemptive_relief not null and shareholder_approval_required "
                  "<> 'Y' and no Manager of Managers exemptive_relief of the engaged fund in force on engagement_start_date",
             source=("DP-538", "Hires Without Exemptive Relief in Force"),
             description="Hires made without shareholder approval under a manager-of-managers order not in force."),
        dict(name="Information Statements Sent Late", aggregation="count_distinct",
             expr="count(distinct engagement) with information_statement_sent > information_statement_due, plus those "
                  "with information_statement_due passed and information_statement_sent null",
             source=("DP-538", "Information Statements Sent Late"),
             description="Manager-of-managers information statements sent after the 90-day deadline, or not sent.",
             note="The unsent part equals Overdue Information Statements (DP-306); this metric adds those sent late."),
        dict(name="Renewal Submissions by Recommendation", aggregation="additive",
             expr="count(renewal_submission) by contract_renewal.renewal_year, renewal_recommendation and engaged fund",
             source=("DP-538", "Renewal Submissions by Recommendation"),
             description="Section 15(c) renewal submissions by recommendation and renewal year."),
        dict(name="Fund Engagements Without Renewal Submission", aggregation="count_distinct",
             expr="[Active Sub-Adviser Engagements] with engaged_fund not null whose agreement has a contract_renewal for "
                  "the current renewal_year with request_15c_date populated and no renewal_submission for it",
             source=("DP-538", "Fund Engagements Without Renewal Submission"),
             description="Active fund engagements due for renewal with no Section 15(c) submission."),
        dict(name="Sub-Adviser Response Days", aggregation="non_additive",
             expr="median of (sub_adviser_response_received - questionnaire_sent_to_sub_adviser) by renewal_year; "
                  "questionnaires sent more than 30 days ago with no response counted as outstanding",
             source=("DP-538", "Sub-Adviser Response Days"),
             description="How quickly sub-advisers answer the Section 15(c) questionnaire."),
        dict(name="Submissions Delivered After Board Materials", aggregation="additive",
             expr="count(renewal_submission) with submission_delivered_date > contract_renewal.materials_delivered_date, "
                  "or null when materials_delivered_date is populated",
             source=("DP-538", "Submissions Delivered After Board Materials"),
             description="Renewal submissions that missed the board materials delivery."),
        dict(name="Submissions Without Current Oversight Review", aggregation="additive",
             expr="count(renewal_submission) whose included oversight reviews name no completed oversight_review of the "
                  "same engagement with review_period_end in the 12 months before request_15c_date",
             source=("DP-538", "Submissions Without Current Oversight Review"),
             description="Renewal submissions not supported by a current oversight review."),
        dict(name="Continue Recommendations on Engagements Under Review", aggregation="additive",
             expr="count(renewal_submission) with renewal_recommendation in ('Continue', 'Continue with Conditions') "
                  "whose engagement had watch_status in ('Under Review', 'Termination Recommended') on "
                  "submission_delivered_date",
             source=("DP-538", "Continue Recommendations on Engagements Under Review"),
             description="Recommendations to continue a sub-adviser that was under review when the board received them.",
             note="Shown with recommendation_rationale for the fund board; links acceptance question 12's two halves."),
        dict(name="Last Section 15(c) Renewal Evidence", aggregation="non_additive",
             expr="per active fund engagement: the renewal_submission of the highest contract_renewal.renewal_year, with "
                  "renewal_recommendation, submission_delivered_date, request_15c_date, materials_delivered_date and the "
                  "board_resolution outcome and effective date; flagged when the last approved renewal is more than 12 "
                  "months old",
             source=("DP-538", "Last Section 15(c) Renewal Evidence"),
             description="What each fund engagement's latest Section 15(c) renewal showed and whether it is current.",
             note="Acceptance question 12. A listing at the engagement grain; the count of flagged engagements is a "
                  "filter on it, not a separate metric."),
        dict(name="Sub-Adviser Terminations in Period", aggregation="additive",
             expr="count(termination) with termination_effective_date in range, by termination_reason and "
                  "engagement_scope; notice lead time = termination_effective_date - termination_notice_date",
             source=("DP-538", "Sub-Adviser Terminations in Period"),
             description="Sub-advisers terminated in the period, by reason, with the notice lead time.",
             note="DP-306 Manager Terminations counts the same rows; this is the one published terminations count."),
        dict(name="Terminations Without Committee Decision", aggregation="additive",
             expr="[Sub-Adviser Terminations in Period] whose committee_decision is missing, not of type 'Manager "
                  "Termination', not approved, or effective after termination_notice_date",
             source=("DP-538", "Terminations Without Committee Decision"),
             description="Terminations not backed by an approved investment committee decision before notice."),
        dict(name="Terminations Without Replacement or Transition", aggregation="additive",
             expr="[Sub-Adviser Terminations in Period] with replacement engagement and transition event both null",
             source=("DP-538", "Terminations Without Replacement or Transition"),
             description="Terminations with neither a replacement sub-adviser nor a transition event.",
             note="DP-306's count of terminations without a replacement is this metric without the transition test."),
        dict(name="Transition Completion Days", aggregation="non_additive",
             expr="actual_completion_date - termination_effective_date per transition, median by transition_type and "
                  "in_specie; transitions without a post-transition report 30 days after completion flagged",
             source=("DP-538", "Transition Completion Days and Cost"),
             description="Calendar days from a termination's effective date to the completed transition."),
        dict(name="Transition Total Cost", aggregation="additive",
             expr="sum(transition_event.transition_total_cost) of transitions linked to terminations in range",
             source=("DP-538", "Transition Completion Days and Cost"),
             description="Total cost of manager transitions, by transition type and in-specie indicator."),
        dict(name="Terminated Engagements Still Active", aggregation="count_distinct",
             expr="count(distinct termination.terminated_engagement) with termination_effective_date more than 30 days "
                  "before the as-of date whose engagement is still Active or open-ended, or whose fund_advisory_agreement "
                  "is still Active with no termination date",
             source=("DP-538", "Terminated Engagements Still Active"),
             description="Terminated sub-advisers whose engagement or agreement records were not closed."),
    ],

    excluded=[
        ("DP-306", "Manager Terminations",
         "The same Manager Termination rows as DP-538's Sub-Adviser Terminations in Period, which owns the termination "
         "lifecycle; one terminations count is published (one name, one definition). Its no-replacement count is "
         "Terminations Without Replacement or Transition without the transition test."),
        ("DP-538", "Information Statement Record Mismatches",
         "Needs Information Statement Communication, which only DP-538's conformed copy of the engagement carries; the "
         "model reads the DP-306 master, and the mismatch is a record tie-out to DP-382 kept in DP-538's dashboard "
         "(see open decisions)."),
    ],

    access=dict(
        classification=("Confidential - Personal Data (key persons are individuals; background_check is a restricted "
                        "FCRA view; the DP-538 renewal and termination tables are Restricted - Legal)"),
        roles=[
            dict(role="manager_research_restricted",
                 rows="all managers, engagements, searches, reviews and background checks (the DP-535 restricted view, "
                      "for the due diligence leads authorized under the FCRA permissible purpose)",
                 columns="all", hidden=[]),
            dict(role="manager_research",
                 rows="all managers, engagements, searches, reviews, scorecards and renewals; background_check only as "
                      "counts by background_check_type, never by manager, strategy or key person, suppressed below 10 rows",
                 columns="all except background check detail",
                 hidden=[c for c in _BACKGROUND if c != "background_check_type"]),
            dict(role="fund_board_and_legal",       # fund legal, the board secretariat and independent counsel's materials
                 rows="engagements of the funds and mandates in the viewer's board scope, their renewals, hires, "
                      "terminations, oversight reviews and watch status; no searches, due diligence or background checks",
                 columns="all except people, free-text due diligence notes and background checks",
                 hidden=_BACKGROUND + _PEOPLE + ["elimination_reason", "areas_inspected"]),
            dict(role="investment_oversight",        # investment risk, compliance and the investment committee
                 rows="all engagements, scorecards, findings, product lists and committee decisions",
                 columns="aggregates by manager, strategy, engagement, fund and metric",
                 hidden=_BACKGROUND + _PEOPLE + ["conclusion_commentary", "recommendation_rationale"]),
            dict(role="broad_internal",              # product, finance, distribution
                 rows="active engagements, watch status counts and product lists; no searches, due diligence reviews, "
                      "findings or background checks",
                 columns="aggregates by engagement scope, fund, asset class and watch status only",
                 hidden=_BACKGROUND + _PEOPLE + _FREE_TEXT),
        ]),

    verified_questions=[
        dict(question="Which sub-advisers are under review and what did the last Section 15(c) renewal data show?",
             answer="[Engagements Under Review] grouped by DP-240 party name of manager, engagement.engagement_scope, "
                    "watch_status.watch_status and watch_reason (watch period in force on the as-of date), with "
                    "watch_review_deadline; beside it [Last Section 15(c) Renewal Evidence] for the same engagements "
                    "(renewal_year, renewal_recommendation, submission_delivered_date, board_resolution.resolution_outcome) "
                    "and [Continue Recommendations on Engagements Under Review]."),
        dict(question="How many sub-adviser engagements are active by scope, and which lack an active agreement or board "
                      "approval?",
             answer="[Active Sub-Adviser Engagements] by engagement.engagement_scope and DP-004 investment product, with "
                    "[Engagements Without Active Agreement] and [Fund Engagements Without Board Approval]; as-of date today."),
        dict(question="Which oversight metrics breached threshold last quarter, and do the return readings tie out?",
             answer="[Metric Threshold Breaches] by metric_reading.oversight_metric and manager, review_period_end in the "
                    "last quarter, with metric_threshold.threshold_value; [Return Reading Tie-Out (to DP-145)] beside "
                    "[Official Return] and [Benchmark Return] of the pinned sleeve_return and benchmark_return rows."),
        dict(question="Which covered managers are overdue for due diligence?",
             answer="[Due Diligence Reviews Overdue] by questionnaire_template.questionnaire_type and "
                    "manager.external_manager_types, with [Questionnaire Turnaround Days] and "
                    "[Operational Reviews Without Onsite Visit]."),
        dict(question="How many sub-advisers did we terminate this year, why, and what did the transitions cost?",
             answer="[Sub-Adviser Terminations in Period] by termination.termination_reason for the calendar year, with "
                    "[Terminations Without Committee Decision], [Transition Completion Days] and [Transition Total Cost] "
                    "by transition_event.transition_type."),
    ],

    cannot_answer=[
        dict(question="Certified assets managed by each sub-adviser sleeve",
             why="Firm AUM is certified by fund and mandate (SM-11), not by sleeve portfolio, so a fund with two "
                 "sub-advisers cannot be split from certified data. The sub-advisory fee payable per engagement is on "
                 "DP-012 Fee Revenue Record (Sub-Adviser Engagement) and is published by SM-28, not here. No gap is "
                 "registered yet.",
             gap=""),
        dict(question="The board's conclusion on each Section 15(c) factor for a renewal",
             why="35 Board 15(c) Finding has no per-factor conclusion; DP-538 shows the resolution outcome only.",
             gap="GAP-35-005"),
        dict(question="Whether every required Section 15(c) material was in the renewal package",
             why="There is no required-materials reference list per board, so completeness is a secretariat list.",
             gap="GAP-35-002"),
        dict(question="Style drift and active share tied out to the performance book of record",
             why="Both are 52 oversight computations, not 32 records, so the scorecard readings have no certified source "
                 "to tie out to (Readings Without Pinned Source checks only the holdings date).",
             gap="GAP-52-001"),
        dict(question="Adverse background check results by manager or key person for a broad audience",
             why="Background checks are FCRA consumer reports; outside the manager research restricted view they are "
                 "released by check type only and suppressed below 10 rows (DP-535 DQ5).",
             gap=""),
    ],

    open_decisions=[
        "DP-306 Sub-Adviser Engagement lacks Information Statement Communication and Notice and Access Indicator, which "
        "DP-538's conformed copy (Fact Sub-Adviser Hire) adds. The model reads the DP-306 master as its engagement hub and "
        "excludes Information Statement Record Mismatches; either add both columns to DP-306 (preferred: 52 owns them) or "
        "let the model read DP-538's copy as the engagement table.",
        "Three products extend DP-306 entities on their conformed copies: DP-536 Sub-Adviser Watch Status adds Deciding "
        "Oversight Review, DP-538 Manager Termination adds Originating Search and Transition Event, DP-538 Fund Advisory "
        "Agreement adds Advisory Agreement Type. The model reads the extended copies (one table each); the DP-306 owner "
        "should decide whether the master carries the columns so every reader sees one shape.",
        "Investment Committee Decision appears as three non-conformed entities (DP-535: type and outcome; DP-536: outcome "
        "only; DP-538: type, outcome and effective date), none conformed from DP-126, which owns committee decisions. "
        "The model reads DP-538's; the logical models should conform all three from DP-126.",
        "Manager Terminations (DP-306) and Sub-Adviser Terminations in Period (DP-538) count the same rows; the model "
        "publishes DP-538's. DP-306 could drop the measure or restate it as a master-data control.",
        "Overdue Information Statements (DP-306) is the unsent part of Information Statements Sent Late (DP-538); both "
        "are published under distinct names, and the owners may merge them.",
        "Background check suppression (by check type only, below 10 rows) is a row-level rule the BI tool must enforce "
        "for every role except manager_research_restricted; confirm the threshold and who holds the restricted role.",
        "Sub-advisory fees: DP-012 carries Sub-Advisory Fee Payable by Sub-Adviser Engagement (SM-28 reads it). If SM-28 "
        "publishes it as a metric, this model should reference it sliced by engagement for the Section 15(c) cost view.",
        "Official Return by sleeve assumes 32 publishes returns with Return Subject Type 'Portfolio' for each sub-adviser "
        "sleeve portfolio; where a sleeve has no own return, the oversight reading's pinned source is the only return "
        "and Return Reading Tie-Out cannot test it.",
    ],
)
