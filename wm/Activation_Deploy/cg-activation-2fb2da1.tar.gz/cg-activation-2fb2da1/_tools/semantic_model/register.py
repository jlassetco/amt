"""Semantic model register: the subject-area models that publish data products to analytical tools. See CONTRACT.md.

Every product whose spec lists "BI semantic model" as a delivery belongs to exactly one model. SM-00 holds the shared
dimensions every other model joins to; it is built first and is not queried on its own.
"""

# (id, name, owner role, primary functions served, products, one-sentence purpose)
MODELS = [
    ("SM-00", "Shared Dimensions", "Head of Enterprise Data Management", ["FN-17", "FN-49", "FN-50"],
     # WP1 re-point (CW-202): DP-002 retired into DP-001; its advisor tables now read DP-001.
     ["DP-001", "DP-003", "DP-004", "DP-005", "DP-009", "DP-013",
      # Wave E9 (CD-296, CD-315): the enterprise dimension products
      "DP-240", "DP-097", "DP-098", "DP-115", "DP-140", "DP-167", "DP-190", "DP-210", "DP-211", "DP-212", "DP-213",
      # WP2: DP-093 Account Master joins the shared dimensions as Client Account (every wealth model joins to it)
      "DP-093"],
     # DP-192 Employee & Position Master sits in SM-15, which owns the certified headcount and FTE; SM-00 reads its
     # Employee entity as the source of a certified metric (CONTRACT.md, which products a table may read).
     "The conformed dimensions every other model joins to: firms and advisors, institutions, products and share classes, "
     "agreements and shelf, the firm's advisors, coverage teams and household coverage, and calendars and reference data."),
    # W2-W4 (CW-062, CW-064): DP-009 reads the 03 Advisor Organization objects; territories left with 07 (CW-907). DP-001 to
    # DP-003 were re-specified at WP1F on the restored 05 and 12 objects (CW-013).
    # ---- Retired subject-area models (WP2 retirement sweep): rows and definition files deleted; the ids are not reused. ---
    # SM-01 Distribution Performance        CW-209: retired at WP2; SM-20 Client Assets & Flows owns the flow and asset family.
    # SM-02 Advisors & Field Sales          CW-041, CW-209: wholesale model held pending from W1; retired, no successor.
    # SM-03 Partners & Platforms            CW-041, CW-209: as SM-02 (the wealth subject areas SM-20 to SM-31 are new cuts).
    # SM-04 Institutional & Retirement      CW-041, CW-209: as SM-02.
    # SM-05 Marketing                       CW-041, CW-209: as SM-02.
    # SM-06 Product & Market                CW-041, CW-209: as SM-02; its product-range tables were carried into SM-30.
    # SM-07 Finance & Profitability         CW-209: retired at WP2; SM-28 Client Economics owns the client fee revenue family.
    # SM-13 Private Markets                 CW-930 (CW-167): retired with the private markets business (30) and its products.
    # ---- Wave E9 (2026-10-14): the enterprise subject-area models (Data_Products_Expansion_Plan.md §7.2). ----------------
    # WP1 re-point (CW-200): retired function FN-01 replaced by its successor FN-79.
    ("SM-08", "Investment Book, Performance & Stewardship", "Head of Performance Measurement", ["FN-21", "FN-31", "FN-24", "FN-79"],
     ["DP-141", "DP-142", "DP-145", "DP-126", "DP-127", "DP-157", "DP-158", "DP-159", "DP-132", "DP-133", "DP-134", "DP-135",
      "DP-532", "DP-533"],   # WP2: household and account performance views on DP-145
     # W4 (CW-930): DP-160 moved to SM-13 to retire with it at WP0; Private Fund IRR and Multiples is no longer certified.
     "Holdings, transactions and the official returns of every portfolio, attribution and GIPS composites, asset "
     "allocation and investment governance, proxy voting, engagement and sustainability metrics. Owns the certified "
     "return metrics."),
    ("SM-09", "Research, Trading & Investment Operations", "Head of Trading", ["FN-20", "FN-23", "FN-27", "FN-28", "FN-29"],
     ["DP-118", "DP-119", "DP-120", "DP-122", "DP-123", "DP-124", "DP-125", "DP-143", "DP-148", "DP-149", "DP-150", "DP-151", "DP-152", "DP-153",
      "DP-544"],   # WP2: trade rotation and cross-book allocation fairness
     "Research coverage and payments, orders, executions and allocations, best execution, prices and pricing control, "
     "the IBOR, settlement, OTC lifecycle and collateral. Owns the certified commission and research spend."),
    ("SM-10", "Investment Risk & Compliance", "Head of Investment Risk", ["FN-30", "FN-32"],
     ["DP-146", "DP-154", "DP-155", "DP-161", "DP-162", "DP-163"],      # WP1 re-point (CW-207): retired DP-156 removed
     "Ex-ante risk, limits and stress, the liquidity and derivatives programs, product risk indicators, guideline "
     "coding, compliance monitoring and breaches. Owns the certified VaR, tracking error and liquidity classification."),
    ("SM-11", "Fund Accounting, Custody & Fund Governance", "Head of Fund Accounting", ["FN-33", "FN-34", "FN-36"],
     # WP1 re-point (CW-207): retired DP-175 removed (DP-172 keeps the reconciliation runs).
     ["DP-165", "DP-166", "DP-168", "DP-169", "DP-170", "DP-171", "DP-172", "DP-173", "DP-174", "DP-176",
      "DP-182", "DP-183", "DP-184", "DP-185", "DP-186", "DP-241", "DP-246"],
     "NAV and fund financials, the fund ledger, expenses and distributions, custody reconciliations, corporate actions, "
     "securities lending, client assets, fund boards and regulatory filings, and the Firm AUM reconciliation. Owns the "
     "certified Firm AUM, NAV, net assets and expense ratio metrics."),
    ("SM-12", "Transfer Agency & Shareholder Operations", "Head of Transfer Agency", ["FN-35", "FN-15"],
     ["DP-177", "DP-178", "DP-179", "DP-180", "DP-181",
      "DP-580", "DP-408"],   # WP2: the fund share register and proxy pass-through
     "Fund orders and cut-off control, settlement with intermediaries, ETF creations and redemptions, shareholder "
     "identity and fraud alerts, and the transfer agent's daily controls."),
    ("SM-14", "Corporate Finance, Treasury & Tax", "Finance Controller", ["FN-38", "FN-39", "FN-40", "FN-12"],
     ["DP-191", "DP-193", "DP-194", "DP-195", "DP-196", "DP-202", "DP-203", "DP-204", "DP-205", "DP-206", "DP-247"],   # WP1 re-point (CW-206): DP-244 retired into DP-498; WP2: DP-498 is published by SM-28, which takess SM-14 cost-to-serve metrics
     "Journals and balances, close and statements, budget and forecast, payables and receivables, tax, cash and "
     "funding, seed capital, regulatory capital and insurance, cost to serve and the management reporting pack. "
     "Owns the certified revenue, operating expense and operating income."),
    ("SM-15", "People & Workplace", "Chief Human Resources Officer", ["FN-41", "FN-48"],
     ["DP-192", "DP-197", "DP-198", "DP-199", "DP-200", "DP-201", "DP-207", "DP-208", "DP-209"],
     "Workforce movement, pay and benefits, remuneration code, talent and training, diversity and pay equity, real "
     "estate, workplace services and travel and expense. Owns the certified headcount, FTE and compensation paid."),
    ("SM-16", "Risk, Compliance, Legal & Audit", "Head of Operational Risk", ["FN-42", "FN-43", "FN-44", "FN-45", "FN-46"],
     ["DP-214", "DP-215", "DP-216", "DP-217", "DP-219", "DP-221", "DP-222", "DP-224", "DP-248"],
     "Risk profile and KRIs, incidents and losses, remediation, resilience, third-party oversight and supplier spend, "
     "firm authorizations and filings, the compliance program, and the enterprise risk and control view."),
    ("SM-17", "Technology, Data Governance & Communications", "Chief Data Officer", ["FN-50", "FN-51", "FN-47", "FN-49"],
     ["DP-100", "DP-101", "DP-102", "DP-103", "DP-104", "DP-231", "DP-232", "DP-233", "DP-234", "DP-235", "DP-236", "DP-237", "DP-238", "DP-245",
      "DP-044", "DP-515", "DP-518"],   # WP2: third-party data, reference data governance, the restricted-view register
     "The taxonomy and catalog, data quality and certification, AI use cases, IT service, security, access and the "
     "change portfolio, brand, media and public affairs, and the enterprise KPI registry."),
    # ---- WP2 (2026-10-17; CW-209, plan section 8.4): the wealth-manager subject areas. SM-30 and SM-31 added by lead ruling
    # at WP2 like SM-29; the product lists settle the RESERVED candidates onto the live WP1 ids (backlog merges applied).
    # Products whose spec does not list the BI semantic model delivery (DP-094 to DP-096, DP-321, DP-324, DP-329, DP-403,
    # DP-435, DP-447, DP-456, DP-085, DP-585) are not bound to a model; they are read through their foundations or stay
    # operational feeds. DP-005 stays in SM-00; DP-498 moves from SM-14 to SM-28.
    ('SM-20', 'Client Assets & Flows', 'Head of Client & Channel Analytics', ['FN-77', 'FN-79'],
     ['DP-008', 'DP-006', 'DP-007', 'DP-490', 'DP-491', 'DP-492', 'DP-495', 'DP-496'],
     'Certified client assets, net new assets and advised assets by channel, business line, offering, holding type, advisor and campaign, the client flow transactions and asset summaries behind them, the executive scorecard and the counts of accounts, clients and households. Owns the CW-011 client-asset family.'),
    ('SM-21', 'Client & Household 360', 'Head of Client Data', ['FN-62', 'FN-60', 'FN-67'],
     ['DP-320', 'DP-307', 'DP-351'],
     'Households, clients and accounts with their profiles, segments, service tiers and the trust fiduciary record and reviews (authority grants, contact permissions and required minimum distributions stay operational feeds, since DP-321, DP-324 and DP-329 list no BI delivery); reads Client Assets from SM-20 and Personal Rate of Return from SM-08.'),
    ('SM-22', 'Advice & Planning', 'Head of Advice', ['FN-60', 'FN-61', 'FN-68'],
     ['DP-303', 'DP-333', 'DP-334', 'DP-335', 'DP-337', 'DP-385', 'DP-387', 'DP-393'],
     'Engagements, plans, goals and recommendations with their best-interest and PTE 2020-02 evidence, the advice funnel and hand-offs, advisor capacity, goal progress and program reviews.'),
    ('SM-23', 'Managed Portfolios', 'Head of Managed Account Operations', ['FN-63'],
     ['DP-304', 'DP-332', 'DP-341', 'DP-342', 'DP-345', 'DP-530', 'DP-531'],
     'Model assignments, Rule 3a-4 enrollment, drift and rebalancing, tax-loss harvesting and wash-sale control, capital market assumptions and model lineups, and the managed-account assets and composites; supplies the managed-account slice of Firm AUM to DP-241.'),
    ('SM-24', 'Brokerage Activity & Execution Quality', 'Head of Brokerage Operations', ['FN-64', 'FN-65', 'FN-66'],
     ['DP-300', 'DP-301', 'DP-302', 'DP-431', 'DP-432', 'DP-436', 'DP-437', 'DP-445', 'DP-448', 'DP-457'],
     'Client holdings and activity, orders and execution quality (Rules 605 and 606), corrections, settlement, the customer reserve, transfers, money movement, sweep and holds (restricted views where special-category data is read).'),
    ('SM-25', 'Client Service & Digital', 'Head of Client Service', ['FN-67', 'FN-61', 'FN-76'],
     ['DP-010', 'DP-011', 'DP-381', 'DP-382', 'DP-392', 'DP-394', 'DP-405', 'DP-409', 'DP-410', 'DP-412', 'DP-418', 'DP-069'],
     'Contact center operations, service requests and remediation, statements, confirmations and tax documents, digital engagement and experiments, marketing campaigns, audiences and consent, acquisition and dormancy.'),
    ('SM-26', 'Workplace & Participants', 'Head of Workplace Solutions', ['FN-19', 'FN-71'],
     ['DP-430', 'DP-466', 'DP-467', 'DP-514'],
     'Recordkept plans and participants, contributions and distributions, participant outcomes, rollover capture and plan sponsor servicing.'),
    ('SM-27', 'Intermediary & Institutional Channel', 'Head of Intermediary Distribution', ['FN-74', 'FN-75'],
     ['DP-243', 'DP-014', 'DP-486', 'DP-487', 'DP-488', 'DP-493', 'DP-505', 'DP-510', 'DP-511'],
     'Intermediary partners, oversight, payments and shareholder requests; industry flows and market share; institutional and OCIO pipeline, relationships, consultant coverage and reporting.'),
    ('SM-28', 'Client Economics', 'Head of Client Revenue Finance', ['FN-12', 'FN-72'],
     ['DP-012', 'DP-305', 'DP-346', 'DP-349', 'DP-350', 'DP-497', 'DP-498', 'DP-499', 'DP-503', 'DP-480', 'DP-242'],
     'Client fee revenue, fee schedules, billing accuracy and realization, commissions and service charges, invoicing, cost allocation, cost to serve, lifetime value, product P&L and profitability. Owns the certified client fee revenue.'),
    ('SM-29', 'Retail Conduct & Supervision', 'Head of Retail Conduct', ['FN-68', 'FN-73'],
     ['DP-398', 'DP-399', 'DP-400', 'DP-402', 'DP-404', 'DP-414', 'DP-036', 'DP-038', 'DP-039', 'DP-078', 'DP-391', 'DP-390'],
     'Principal review and supervisory approvals, Form CRS and Reg BI disclosure delivery, sales practice surveillance, branch inspections, senior investor holds, conduct risk indicators, complaints, registrations, incentive governance and communications surveillance (CLA-B brief). Reads Client Assets from SM-20 and recommendations from SM-22; special-category data only as aggregates or restricted views (CD-344).'),
    ('SM-30', 'Offering, Product Range & Market', 'Head of Product & Offering Management', ['FN-78', 'FN-77'],
     ['DP-105', 'DP-106', 'DP-107', 'DP-108', 'DP-109', 'DP-383', 'DP-384', 'DP-481', 'DP-506', 'DP-516'],
     'Product proposals, launches, changes, mergers and reviews, the platform shelf and tradable universe, advice service and feature development, competitor offerings and fee benchmarks (lead ruling at WP2: the product-range products of the retired SM-06 and the offering products of CLA-B share one model).'),
    ('SM-31', 'Manager Oversight & Due Diligence', 'Head of Manager Research', ['FN-70'],
     ['DP-306', 'DP-535', 'DP-536', 'DP-538'],
     'External managers and sub-advisers, searches and due diligence, oversight scorecards, hires, terminations and Section 15(c) renewal evidence (lead ruling at WP2).'),
]

# Models registered whose definition file is still being written; the validator warns instead of failing. Empty since
# WP2: every SM-20 to SM-31 definition file has landed.
IN_PROGRESS = set()

# Models pending re-scope or retirement: {id: decision}. A pending model's file stays in models/ but is not validated,
# built or published; a live model that references a metric it defines is an error. From W1 it held SM-02 to SM-06
# (CW-041), SM-13 (CW-930) and, once SM-20 and SM-28 existed, SM-01 and SM-07 (CW-209). Empty since the WP2 retirement
# sweep, which deleted the eight models (see the retired-models comment in MODELS above).
PENDING = {}

# Products a model uses although their spec does not (yet) list the BI semantic model. The validator warns rather
# than fails, so the open decision stays visible. Empty since WP2: the only entry, SM-04 with DP-092, retired with both.
PROPOSED = {}

# Certified metrics: defined once in the owning model and referenced everywhere else as ref="SM-nn/<name>".
# name: (owning model, source product, source measure or attribute in that product's spec)
CERTIFIED = {
    # WP2 (CW-209, CW-011, CW-142, CW-203, CW-204): the client-asset and flow family in SM-20 on DP-008, the client fee
    # revenue family in SM-28 on DP-012 (the SM-01 and SM-07 entries retired with those models; CERTIFIED_WEALTH below is
    # the registration plan these entries apply).
    "Client Assets": ("SM-20", "DP-008", "Ending Client Assets"),
    "Beginning Client Assets": ("SM-20", "DP-008", "Beginning Client Assets"),
    "Average Client Assets": ("SM-20", "DP-008", "Average Client Assets"),
    "Net New Assets": ("SM-20", "DP-008", "Net New Assets"),
    "Advised Assets": ("SM-20", "DP-008", "Advised Assets"),
    "Client Market Movement and Other": ("SM-20", "DP-008", "Client Market Movement and Other"),
    "Net Inter-Channel Transfers": ("SM-20", "DP-008", "Net Inter-Channel Transfers"),
    "Client Organic Growth Rate": ("SM-20", "DP-008", "Client Organic Growth Rate"),
    "Own-Fund Overlap": ("SM-20", "DP-008", "Own-Fund Overlap Amount"),
    "Gross Sales": ("SM-20", "DP-008", "Gross Sales"),
    "Redemptions": ("SM-20", "DP-008", "Redemptions"),
    "Net Flows": ("SM-20", "DP-008", "Net Flows"),
    "Funded Accounts": ("SM-20", "DP-008", "Funded Accounts"),
    "Clients": ("SM-20", "DP-008", "Clients"),
    "Households": ("SM-20", "DP-008", "Households"),
    "Gross Fee Revenue": ("SM-28", "DP-012", "Gross Fee Revenue"),
    "Net Fee Revenue": ("SM-28", "DP-012", "Net Fee Revenue"),
    "Effective Net Fee Rate": ("SM-28", "DP-012", "Effective Net Fee Rate"),
    "Client Fee Revenue": ("SM-28", "DP-012", "Client Fee Revenue"),
    "Personal Rate of Return": ("SM-08", "DP-145", "Personal Return Value"),
    "Firm AUM - Own Funds at NAV": ("SM-11", "DP-241", "Firm AUM Own Funds Slice"),
    "Firm AUM - Managed Accounts": ("SM-11", "DP-241", "Firm AUM Managed Account Slice"),
    "Firm AUM - Institutional & OCIO": ("SM-11", "DP-241", "Firm AUM Institutional Slice"),
    # ---- Enterprise certified families (CD-292, CD-293, CD-320, CD-330, CD-340, CD-341, CD-347, CD-312), Wave E9 ------
    "Firm AUM": ("SM-11", "DP-241", "Firm AUM"),   # WP1 re-point (CW-206): Firm AUM moved from DP-165 to DP-241
    "Fund Total Net Assets": ("SM-11", "DP-165", "Fund Total Net Assets"),
    "Class Net Assets": ("SM-11", "DP-165", "Class Net Assets"),
    "NAV per Share": ("SM-11", "DP-165", "NAV per Share"),
    "Shares Outstanding": ("SM-11", "DP-165", "Shares Outstanding"),
    "Net and Gross Expense Ratio (Trailing)": ("SM-11", "DP-165", "Net and Gross Expense Ratio (Trailing)"),
    "Official Return": ("SM-08", "DP-145", "Official Return"),
    "Benchmark Return": ("SM-08", "DP-145", "Benchmark Return"),
    # "Private Fund IRR and Multiples" (SM-08, DP-145) removed at W4 with the 32 private markets family (CW-930).
    # CW-011 families: registered above from the CERTIFIED_WEALTH plan below (WP0, CW-209; applied at WP2).
    "Ex-Ante VaR": ("SM-10", "DP-146", "Ex-Ante VaR"),
    "Ex-Ante Tracking Error": ("SM-10", "DP-146", "Ex-Ante Tracking Error"),
    "Liquidity Category Percent of Net Assets": ("SM-10", "DP-155", "Liquidity Category Percent of Net Assets"),
    "HLIM Shortfall": ("SM-10", "DP-155", "HLIM Shortfall"),
    "Certified Revenue": ("SM-14", "DP-191", "Certified Revenue"),
    "Certified Operating Expense": ("SM-14", "DP-191", "Certified Operating Expense"),
    "Certified Compensation Expense": ("SM-14", "DP-191", "Certified Compensation Expense"),
    "Certified Operating Income": ("SM-14", "DP-191", "Certified Operating Income"),
    "Certified Headcount": ("SM-15", "DP-192", "Certified Headcount"),
    "Certified FTE": ("SM-15", "DP-192", "Certified FTE"),
    "Gross Pay Paid": ("SM-15", "DP-198", "Gross Pay Paid"),
    "Commission Spend": ("SM-09", "DP-122", "Commission Spend"),
    "Research Spend": ("SM-09", "DP-122", "Research Spend"),
}

# ---- WP0 framing (2026-10-15; CW-209, CW-011, CW-142; Wealth_Manager_Rework_Plan.md sections 4 item 7 and 8.4) ----------
# Applied at WP2: every entry below is in CERTIFIED and the wholesale entries have left; kept as the recorded plan.
# The registration plan of the wealth-manager certified families. CERTIFIED above stays as it is until WP2 (sm_model.py
# validates it against the live models); at WP2 each entry below moves into CERTIFIED when its owning model's definition
# file exists, and the superseded wholesale entries leave. Each certified metric is defined in exactly one model.
# name: (owning model, source product, source measure or attribute in that product's spec, decision)
CERTIFIED_WEALTH = {
    # SM-20 Client Assets & Flows, on DP-008 Client Assets & Net New Assets (re-scoped in place, CW-203)
    "Client Assets": ("SM-20", "DP-008", "Ending Client Assets", "CW-011"),
    "Beginning Client Assets": ("SM-20", "DP-008", "Beginning Client Assets", "CW-142"),
    "Average Client Assets": ("SM-20", "DP-008", "Average Client Assets", "CW-142"),
    "Net New Assets": ("SM-20", "DP-008", "Net New Assets", "CW-011"),
    "Advised Assets": ("SM-20", "DP-008", "Advised Assets", "CW-011"),
    "Client Market Movement and Other": ("SM-20", "DP-008", "Client Market Movement and Other", "CW-142"),
    "Net Inter-Channel Transfers": ("SM-20", "DP-008", "Net Inter-Channel Transfers", "CW-142"),
    "Client Organic Growth Rate": ("SM-20", "DP-008", "Client Organic Growth Rate", "CW-142"),
    "Own-Fund Overlap": ("SM-20", "DP-008", "Own-Fund Overlap Amount", "CW-142"),     # reported here, netted only in DP-241
    "Gross Sales": ("SM-20", "DP-008", "Gross Sales", "CW-203"),                   # own-fund flow family, moves from SM-01
    "Redemptions": ("SM-20", "DP-008", "Redemptions", "CW-203"),
    "Net Flows": ("SM-20", "DP-008", "Net Flows", "CW-203"),
    "Funded Accounts": ("SM-20", "DP-008", "Funded Accounts", "CW-011"),           # counts from DP-093 accounts (06 MSR- codes)
    "Clients": ("SM-20", "DP-008", "Clients", "CW-011"),                           # from DP-240 parties in the client role
    "Households": ("SM-20", "DP-008", "Households", "CW-011"),                     # from DP-240 households (PTY- of type Household)
    # SM-11 Fund Accounting, Custody & Fund Governance: Firm AUM and its slices move from DP-165 to DP-241 (lead ruling)
    "Firm AUM": ("SM-11", "DP-241", "Firm AUM", "CW-011"),
    "Firm AUM - Own Funds at NAV": ("SM-11", "DP-241", "Firm AUM Own Funds Slice", "CW-011"),
    "Firm AUM - Managed Accounts": ("SM-11", "DP-241", "Firm AUM Managed Account Slice", "CW-011"),   # from CLA-A DP-345
    "Firm AUM - Institutional & OCIO": ("SM-11", "DP-241", "Firm AUM Institutional Slice", "CW-011"),
    # SM-08: every certified return stays in one model; DP-145 is extended with 32 Client Account Performance
    "Personal Rate of Return": ("SM-08", "DP-145", "Personal Return Value", "CW-011"),
    # SM-28 Client Economics, on DP-012 Client Fee Revenue (the SM-07 revenue family moves there at WP2)
    "Gross Fee Revenue": ("SM-28", "DP-012", "Gross Fee Revenue", "CW-204"),
    "Net Fee Revenue": ("SM-28", "DP-012", "Net Fee Revenue", "CW-204"),
    "Effective Net Fee Rate": ("SM-28", "DP-012", "Effective Net Fee Rate", "CW-204"),
}
# Leaving CERTIFIED at WP2 with their models: the wholesale AUM family (Ending, Beginning and Average AUM, Market Movement,
# Organic Growth Rate) of SM-01 is replaced by the client-asset family above ("AUM" is reserved for Firm AUM); "Firm AUM" in
# SM-11 changes source from DP-165 to DP-241; DP-165 keeps Fund Total Net Assets, Class Net Assets, NAV per Share, Shares
# Outstanding and the expense ratios.

# Applied at WP2: SM-20 to SM-29 are registered in MODELS (product lists settled there; SM-30 and SM-31 added); kept as the recorded plan.
# Semantic models reserved for WP2 (plan section 8.4; CW-209; SM-29 by the lead's WP0 ruling). (id, name, owner role, primary functions, products, purpose).
# Products are existing ids or WP0 candidate ids (proposals_wp0_*.py, proposals_wdp_*.py); the lead settles the lists at WP2.
RESERVED = [
    ("SM-20", "Client Assets & Flows", "Head of Client & Channel Analytics", ["FN-77", "FN-79"],
     ["DP-008", "DP-006", "DP-007", "DP-490", "DP-491", "DP-492", "DP-495", "DP-496"],
     "Certified client assets, net new assets and advised assets by channel, business line, offering, holding type, advisor "
     "and campaign, the client flow transactions and positions behind them, and the counts of accounts, clients and "
     "households. Owns the CW-011 client-asset family."),
    ("SM-21", "Client & Household 360", "Head of Client Data", ["FN-62", "FN-60", "FN-67"],
     ["DP-320", "DP-321", "DP-323", "DP-324", "DP-325", "DP-326", "DP-327", "DP-328", "DP-329", "DP-330", "DP-307"],
     "Households, clients and accounts with their profiles, authorized persons, segments, service tiers, account features "
     "and lifecycle; reads Client Assets from SM-20 and Personal Rate of Return from SM-08."),
    ("SM-22", "Advice & Planning", "Head of Advice", ["FN-60", "FN-61", "FN-68"],
     ["DP-303", "DP-333", "DP-334", "DP-335", "DP-336", "DP-337", "DP-338", "DP-339", "DP-340"],
     "Engagements, plans, goals and recommendations with their best-interest and PTE 2020-02 evidence, the advice funnel and "
     "goal progress."),
    ("SM-23", "Managed Portfolios", "Head of Managed Account Operations", ["FN-63"],
     ["DP-304", "DP-332", "DP-341", "DP-342", "DP-343", "DP-344", "DP-345", "DP-534"],
     "Model assignments, drift and rebalancing, tax-loss harvesting and wash-sale control, trade proposals and program "
     "composites; supplies the managed-account slice of Firm AUM to DP-241."),
    ("SM-24", "Brokerage Activity & Execution Quality", "Head of Brokerage Operations", ["FN-64", "FN-65", "FN-66"],
     ["DP-300", "DP-301", "DP-302", "DP-431", "DP-432", "DP-435", "DP-436", "DP-437", "DP-445", "DP-447", "DP-448",
      "DP-455", "DP-456", "DP-457"],
     "Client holdings and activity, orders and execution quality (Rules 605 and 606), settlement, customer protection, "
     "transfers, money movement, sweep and holds (restricted views where special-category data is read)."),
    ("SM-25", "Client Service & Digital", "Head of Client Service", ["FN-67", "FN-61", "FN-76"],
     ["DP-011", "DP-381", "DP-382", "DP-392", "DP-394", "DP-395", "DP-396", "DP-397", "DP-405", "DP-406", "DP-407",
      "DP-409", "DP-417", "DP-418", "DP-069", "DP-085"],
     "Contact center operations, service requests and cases, statements, confirmations and tax documents, digital "
     "engagement and experiments, surveys and acquisition engagement (CLA-B brief; ids aligned with the CLA-B candidates "
     "at the WP0 integration: the conduct products DP-414 and DP-415 moved to SM-29, the draft ids DP-419 and DP-421 were "
     "not used)."),
    ("SM-26", "Workplace & Participants", "Head of Workplace Solutions", ["FN-19", "FN-71"],
     ["DP-094", "DP-095", "DP-096", "DP-430", "DP-466", "DP-467", "DP-468"],
     "Recordkept plans and participants, contributions and distributions, participant outcomes and rollover capture."),
    ("SM-27", "Intermediary & Institutional Channel", "Head of Intermediary Distribution", ["FN-74", "FN-75"],
     ["DP-243", "DP-482", "DP-483", "DP-484", "DP-485", "DP-488", "DP-489", "DP-493", "DP-510", "DP-511"],
     "Intermediary partners, placement and channel flows; institutional and OCIO pipeline, relationships and reporting."),
    ("SM-28", "Client Economics", "Head of Client Revenue Finance", ["FN-12", "FN-72"],
     ["DP-012", "DP-305", "DP-346", "DP-347", "DP-348", "DP-497", "DP-498", "DP-499", "DP-500", "DP-501"],
     "Client fee revenue, billing accuracy and realization, revenue yield, cost to serve, lifetime value and profitability. "
     "Owns the certified client fee revenue."),
    # Lead ruling 2026-10-15 (WP0 integration): the retail conduct products get their own model rather than extending SM-16.
    ("SM-29", "Retail Conduct & Supervision", "Head of Retail Conduct", ["FN-68", "FN-73"],
     ["DP-398", "DP-399", "DP-400", "DP-401", "DP-402", "DP-403", "DP-404", "DP-414", "DP-415", "DP-416", "DP-036",
      "DP-038", "DP-039", "DP-078", "DP-391"],
     "Principal review and supervisory approvals, Form CRS and Reg BI disclosure delivery, sales practice surveillance, "
     "options and margin approvals, branch inspections, senior investor holds, conduct risk indicators, complaints, "
     "Marketing Rule substantiation, frequent trading, communications review and surveillance, gifts and registrations "
     "(CLA-B brief, 08 and 03). Reads Client Assets from SM-20 and recommendations from SM-22; special-category data only "
     "as aggregates or restricted views (CD-344)."),
]
# Retirement plan (CW-209), applied at WP2: SM-02 to SM-06 and SM-13 retired with no successor model; SM-01 Distribution
# Performance retired to SM-20 and SM-07 Finance & Profitability to SM-28, their certified entries moving as listed in
# CERTIFIED_WEALTH. The former RETIRE_AT_WP2 register ({"SM-01": ("SM-20", "CW-209"), "SM-07": ("SM-28", "CW-209")}) is
# removed: nothing reads it, and the retired-models comment in MODELS records the decisions.

STATUS = ["Draft", "Confirmed"]
AGGREGATION = {
    "additive": "Sum.",
    "semi_additive": "Sum across dimensions; take the last value over time.",
    "ratio": "Sum of the numerator divided by sum of the denominator, never an average of row ratios.",
    "count_distinct": "Count distinct at query time from detail rows; cannot be summed across groups.",
    "non_additive": "Recompute from detail rows, or show only at the product's own grain.",
}
