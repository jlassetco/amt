"""Prints what a semantic model author needs about data products: the spec (grain, measures, inputs, access) and
the logical model (entities, attributes, relationships), in the exact names sm_model.py checks against.

Usage (from _tools/):  python semantic_model/show_product.py DP-016 [DP-008 ...]
"""
import sys

import sm_model  # sets up paths  # noqa: F401
import dm_model
import framework as fw
import register as rg

if __name__ == "__main__":
    logical, errs, _ = dm_model.validate()
    _, specs, _, _, _ = dm_model.load_all()
    reg = {p[0]: p for p in fw.PRODUCTS}
    home = {pid: m[0] for m in rg.MODELS for pid in m[4]}
    for pid in sys.argv[1:]:
        p, s, m = reg[pid], specs[pid], logical[pid]
        print(f"\n=== {pid} {p[1]} | {p[2]} | {p[3]} | owner: {p[5]} | model: {home.get(pid, '-')}")
        print(f"grain: {s['grain']}")
        print(f"dimensions: {'; '.join(s['dimensions'])}")
        print(f"classification: {s['classification']} | PII: {s['pii']} | delivery: {', '.join(s['delivery'])} | upstream: {', '.join(s['upstream'])}")
        print("measures:")
        for n, d, *_ in s["measures"]:          # (name, definition) or (name, definition, uses)
            print(f"  - {n}: {d}")
        print("inputs:")
        for n, o, al in s["inputs"]:
            print(f"  {n} {o}: {', '.join(al)}")
        if s.get("notes"):
            print(f"notes: {s['notes']}")
        print(f"logical model ({m['style']}):")
        for e in m["entities"]:
            conf = f" conformed from {e['conformed'][0]}/{e['conformed'][1]}" if e["conformed"] else ""
            print(f"  [{e['role']}] {e['name']}{conf}" + (f"  grain: {e['grain']}" if e["grain"] else ""))
            print("     " + "; ".join(a["name"] + ("*" if a["pk"] else "") + (" (measure)" if a["derived"] else "")
                                      + (" [PII]" if a["pii"] else "") for a in e["attrs"]))
        for r in m["relationships"]:
            print(f"  {r['child']} -> {r['parent']} on {', '.join(r['fk'])} ({r['card']}{', optional' if r['optional'] else ''})")
    print("\nLegend: * = primary key; (measure) = product measure held on that entity; [PII] = personal data")
