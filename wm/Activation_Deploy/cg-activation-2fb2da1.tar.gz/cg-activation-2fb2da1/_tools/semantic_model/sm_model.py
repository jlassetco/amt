"""Loads the semantic model register (register.py) and the model definitions (models/sm_*.py), and validates them
against the data product specs, the logical models and the gap register. See CONTRACT.md.

Usage (from _tools/):
  python semantic_model/sm_model.py          validate every model
  python semantic_model/sm_model.py SM-20    validate one model (cross-model checks still see the others)
"""
import importlib, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.path.dirname(HERE)
for p in (TOOLS, HERE, os.path.join(HERE, "models"), os.path.join(TOOLS, "data_models"), os.path.join(TOOLS, "data_products"),
          os.path.join(TOOLS, "consolidation")):
    sys.path.insert(0, p)
sys.dont_write_bytecode = True

import dm_model  # noqa: E402
import dp_model  # noqa: E402
import framework as fw  # noqa: E402
import register as rg  # noqa: E402

PENDING = dict(getattr(rg, "PENDING", {}))      # models pending WP0 re-scope (CW-041): not validated, built or published


HOME = {pid: m[0] for m in rg.MODELS for pid in m[4]}      # product -> its home model


def live_models(models):
    """The models that are not pending WP0 re-scope."""
    return {mid: m for mid, m in models.items() if mid not in PENDING}

SEM = "BI semantic model"
REQUIRED = {"id": str, "status": str, "description": str, "questions": list, "tables": list, "shared": list,
            "relationships": list, "metrics": list, "access": dict, "verified_questions": list}
OPTIONAL = {"hierarchies": list, "excluded": list, "cannot_answer": list, "open_decisions": list}
KINDS = {"Fact", "Dimension", "Bridge"}
JOINS = {"many-to-one", "one-to-one", "many-to-many"}
GAP_ID = re.compile(r"^GAP-\d{2}-\d{3}$")


def load_context():
    """Logical models, specs and gap ids the models are checked against."""
    logical, errs, _ = dm_model.validate()
    if errs:
        raise SystemExit("Logical model validation failed; fix data_models first:\n  " + "\n  ".join(errs[:10]))
    _, specs, _, _, _ = dm_model.load_all()
    try:
        gaps = {g["id"]: g for g in importlib.import_module("gaps_register").GAPS}
    except Exception:          # the register is optional for validation; gap ids are then checked by format only
        gaps = {}
    return logical, specs, gaps


def load_models():
    """{SM id: MODEL dict} from models/sm_*.py, plus errors for duplicates or unreadable files."""
    out, errs = {}, []
    folder = os.path.join(HERE, "models")
    for f in sorted(os.listdir(folder)) if os.path.isdir(folder) else []:
        if not (f.startswith("sm_") and f.endswith(".py")):
            continue
        try:
            m = importlib.import_module(f[:-3]).MODEL
        except Exception as e:
            errs.append(f"{f}: cannot load ({e.__class__.__name__}: {e})"); continue
        mid = m.get("id")
        if mid in out:
            errs.append(f"{mid}: defined in more than one file")
        out[mid] = dict(m, _file=f)
    return out, errs


def entity(logical, pid, name):
    m = logical.get(pid)
    return next((e for e in m["entities"] if e["name"] == name), None) if m else None


def validate(models, logical, specs, gaps, only=None):
    errs, warns = [], []
    models = live_models(models)
    reg = {m[0]: m for m in rg.MODELS}
    for mid in PENDING:
        if mid not in reg:
            errs.append(f"PENDING {mid}: not in register.MODELS")
    # register rows of live models that name a function retired at WP0 (framework.RETIRED_FUNCTIONS): a warning until the
    # register is re-pointed to the successor (register content, not tooling)
    rfn = getattr(fw, "RETIRED_FUNCTIONS", {})
    for mid, m in reg.items():
        if mid in PENDING:
            continue
        for f in m[3]:
            if f in rfn:
                warns.append(f"{mid}: register names retired function {f} ({rfn[f]}); successor "
                             f"{fw.FUNCTION_SUCCESSOR.get(f) or 'none'}")
    # bound products: live and not retired (framework.RETIRED_PRODUCTS)
    _retired = getattr(fw, "RETIRED_PRODUCTS", {})
    for mid, m in reg.items():
        if mid not in PENDING:
            for pid in m[4]:
                if pid in _retired:
                    warns.append(f"{mid}: publishes retired product {pid} ({_retired[pid]}); re-point at WP1")
    # in-progress products have no spec yet; products pending WP0 re-scope (CW-041) are not bound to a model
    bound = [p[0] for p in fw.PRODUCTS if p[0] in specs and SEM in specs[p[0]]["delivery"] and not dp_model.is_pending(p[0])]
    home = {}
    for mid, m in reg.items():
        for pid in m[4]:
            if pid in home:
                errs.append(f"{pid}: in both {home[pid]} and {mid}")
            home[pid] = mid
            if mid in PENDING:
                continue
            if pid not in specs:
                errs.append(f"{mid}: unknown product {pid}")
            elif SEM not in specs[pid]["delivery"]:
                errs.append(f"{mid}: {pid} is in the register but its spec does not list '{SEM}'")
    for pid in bound:
        if home.get(pid) in PENDING:
            warns.append(f"{pid}: its semantic model {home[pid]} is pending WP0 re-scope ({PENDING[home[pid]]}); the product needs a new home at WP0")
        if pid not in home:
            if str(fw.WAVE.get(pid, "")).startswith("Wave E"):     # data products expansion: semantic models come in Phase 2 (E9)
                warns.append(f"{pid}: lists '{SEM}' and awaits its Phase 2 semantic model (Wave E9)")
            elif str(fw.WAVE.get(pid, "")).startswith("Wave WP1") or pid in getattr(fw, "WP1_RESCOPED", {}):
                # wealth model WP1 (CW-041): the semantic layer is re-cut at WP2 (SM-20 to SM-29)
                warns.append(f"{pid}: lists '{SEM}' and awaits its WP2 semantic model (SM-20 to SM-29)")
            else:
                errs.append(f"{pid}: lists '{SEM}' but is in no semantic model")
    for mid, ps in rg.PROPOSED.items():
        if mid in PENDING:
            continue
        for pid in ps:
            warns.append(f"{mid}: uses {pid}, whose spec does not list '{SEM}' (proposed; decision for the product owner)")
    for name, (mid, pid, src) in rg.CERTIFIED.items():
        if pid not in reg[mid][4]:
            errs.append(f"CERTIFIED {name}: source {pid} is not a product of {mid}")
    for mid in reg:
        if mid not in models:
            if mid in PENDING:
                continue
            if mid in getattr(rg, "IN_PROGRESS", set()):      # Wave E9: registered, definition being written
                warns.append(f"{mid}: awaiting its definition file (Wave E9)")
            else:
                (errs if not only else warns).append(f"{mid}: no definition file in models/")
    for mid in models:
        if mid not in reg:
            errs.append(f"{mid}: definition file but not in register.MODELS")

    certified_src = {v[1] for v in rg.CERTIFIED.values()}
    spine = set(reg["SM-00"][4])
    defined = {}                                     # metric name -> model that defines it
    for mid, m in models.items():
        for x in m.get("metrics", []):
            if isinstance(x, dict) and x.get("name") and not x.get("ref"):
                if x["name"] in defined:
                    errs.append(f"metric '{x['name']}' is defined in both {defined[x['name']]} and {mid}; one name, one definition")
                defined.setdefault(x["name"], mid)

    for mid, m in sorted(models.items()):
        if only and mid != only or mid not in reg:
            continue
        e, w = check_model(mid, m, reg[mid], logical, specs, gaps, spine, certified_src, defined, models)
        errs += e; warns += w
    return errs, warns


def check_model(mid, m, regrow, logical, specs, gaps, spine, certified_src, defined, models):
    E, W = [], []
    err = lambda s: E.append(f"{mid}: {s}")
    warn = lambda s: W.append(f"{mid}: {s}")
    for k, t in REQUIRED.items():
        if not isinstance(m.get(k), t) or not m.get(k):
            err(f"missing or empty '{k}' ({t.__name__})")
    for k, t in OPTIONAL.items():
        if k in m and not isinstance(m[k], t):
            err(f"'{k}' must be a {t.__name__}")
    for k in m:
        if k not in REQUIRED and k not in OPTIONAL and k != "_file":
            err(f"unexpected field '{k}'")
    if m.get("status") not in rg.STATUS:
        err(f"status must be one of {rg.STATUS}")
    for k in ("questions", "verified_questions"):
        if isinstance(m.get(k), list) and not 3 <= len(m[k]) <= 6:
            warn(f"'{k}' has {len(m[k])} items; the contract asks for 3-6")

    own = set(regrow[4]) | set(rg.PROPOSED.get(mid, []))
    for pid in sorted(own):
        if dp_model.is_pending(pid):
            warn(f"publishes pending product {pid}; its tables, metrics and measures are skipped; re-point at WP0; {dp_model.PENDING[pid]}")
    own = {p for p in own if not dp_model.is_pending(p)}
    readable = own | spine | certified_src
    names, covered, held = {}, set(), []
    for t in m.get("tables", []):
        n = t.get("name", "")
        if not re.match(r"^[a-z][a-z0-9_]*$", n) or n in names:
            err(f"table name missing, not snake_case or duplicated: {n!r}"); continue
        names[n] = t
        pid = t.get("product")
        if dp_model.is_pending(pid):            # pending WP0 re-scope (CW-041): its logical model is not built
            held.append(f"{n} ({pid})")
            t["_cols"], t["_held"] = set(), True
            continue
        if pid not in readable and HOME.get(pid) in PENDING:      # a live product whose home model is pending (CW-041)
            warn(f"table {n}: depends on {pid}, whose semantic model {HOME[pid]} is pending; re-point at WP0; {PENDING[HOME[pid]]}")
            t["_cols"], t["_held"] = set(), True
            continue
        if pid not in readable:
            err(f"table {n}: product {pid} is not this model's, SM-00's or a certified source"); continue
        ent = entity(logical, pid, t.get("entity"))
        if not ent:
            err(f"table {n}: '{t.get('entity')}' is not an entity in {pid}'s logical model "
                f"(has: {', '.join(e['name'] for e in logical[pid]['entities'])})"); continue
        if t.get("kind") not in KINDS:
            err(f"table {n}: kind must be one of {sorted(KINDS)}")
        if t.get("kind") in ("Fact", "Bridge") and not t.get("grain"):
            err(f"table {n}: a {t.get('kind')} needs a grain")
        attrs = {a["name"] for a in ent["attrs"]}
        cols = set()
        for part in ("dimensions", "facts"):
            for c in t.get(part, []):
                cn, an = c.get("name"), c.get("attr")
                if not cn or not re.match(r"^[a-z][a-z0-9_]*$", cn) or cn in cols:
                    err(f"table {n}: {part} name missing, not snake_case or duplicated: {cn!r}")
                cols.add(cn)
                if an not in attrs:
                    err(f"table {n}.{cn}: attribute '{an}' is not on {pid} '{ent['name']}'")
                covered.add((pid, an))
        for h in t.get("hidden", []):
            if not (isinstance(h, tuple) and len(h) == 2 and h[0] in attrs):
                err(f"table {n}: hidden entry must be (attribute of the entity, reason): {h!r}")
            else:
                covered.add((pid, h[0]))
        if pid == "DP-008" and t.get("kind") == "Fact":
            f = " ".join(t.get("always_filter", [])).lower()
            # the flow book is keyed by Dimension Type since W4 (CW-011, SM-01); dimension_grain is the pre-W4 column name
            for need in (("dimension_type", "dimension_grain"), ("period_type",), ("locked",)):
                if not any(x in f for x in need):
                    err(f"table {n}: reads DP-008 without pinning {need[0]} in always_filter")
        t["_cols"] = cols
    if held:
        warn(f"tables from products pending WP0 re-scope (CW-041), not validated: {', '.join(held)}")

    shared_ok = set()
    for s in m.get("shared", []):
        pid, _, en = s.partition("/")
        if dp_model.is_pending(pid):
            warn(f"shared '{s}': depends on pending product {pid}; re-point at WP0; {dp_model.PENDING[pid]}")
            shared_ok.add(s); continue
        cert_src = {v[1] for v in rg.CERTIFIED.values()}       # a certified metric's source product may lend its dimension (CONTRACT.md)
        if (pid not in spine and pid not in cert_src) or not entity(logical, pid, en):
            err(f"shared '{s}' is not an entity of an SM-00 product's logical model (or of a certified metric's source product)")
        shared_ok.add(s)
    ends = set(names) | shared_ok
    for r in m.get("relationships", []):
        for side in ("frm", "to"):
            if r.get(side) not in ends:
                err(f"relationship {r.get('frm')} -> {r.get('to')}: '{r.get(side)}' is not a table or shared dimension")
        if r.get("type") not in JOINS:
            err(f"relationship {r.get('frm')} -> {r.get('to')}: type must be one of {sorted(JOINS)}")
        if r.get("type") == "many-to-many" and not r.get("warning"):
            err(f"relationship {r.get('frm')} -> {r.get('to')}: many-to-many needs a warning")
        if not r.get("on"):
            err(f"relationship {r.get('frm')} -> {r.get('to')}: 'on' is required")
    for h in m.get("hierarchies", []):
        for lv in h.get("levels", []):
            tn, _, cn = lv.partition(".")
            if tn in names and names[tn].get("_held"):
                continue                        # level on a table skipped as pending (CW-041)
            if tn not in names or cn not in names[tn].get("_cols", set()):
                err(f"hierarchy {h.get('name')}: level '{lv}' is not table.dimension in this model")

    mnames = set()
    for x in m.get("metrics", []):
        n = x.get("name")
        if not n or n in mnames:
            err(f"metric name missing or duplicated: {n!r}"); continue
        mnames.add(n)
        if x.get("ref"):
            rm, _, rn = x["ref"].partition("/")
            if rm in PENDING:
                err(f"metric {n}: live model {mid} reads metric {rn} defined in pending model {rm} (re-point; {PENDING[rm]})")
                continue
            target = models.get(rm)
            ok = (rn in rg.CERTIFIED and rg.CERTIFIED[rn][0] == rm) or \
                 (target and any(y.get("name") == rn and not y.get("ref") for y in target.get("metrics", [])))
            if not ok:
                err(f"metric {n}: ref '{x['ref']}' is not a certified metric or a metric defined in {rm}")
            if rm == mid:
                err(f"metric {n}: refers to its own model")
            continue
        if n in rg.CERTIFIED and rg.CERTIFIED[n][0] != mid:
            err(f"metric {n}: certified metric owned by {rg.CERTIFIED[n][0]}; use ref='{rg.CERTIFIED[n][0]}/{n}'")
        agg = x.get("aggregation")
        if agg not in rg.AGGREGATION:
            err(f"metric {n}: aggregation must be one of {sorted(rg.AGGREGATION)}")
        if agg == "ratio" and not (x.get("numerator") and x.get("denominator")):
            err(f"metric {n}: a ratio needs numerator and denominator")
        if agg and agg != "ratio" and not x.get("expr"):
            err(f"metric {n}: needs expr")
        if agg == "semi_additive" and not x.get("time_rule"):
            err(f"metric {n}: semi_additive needs a time_rule")
        if not x.get("description"):
            err(f"metric {n}: needs a description")
        src = x.get("source")
        if not (isinstance(src, tuple) and len(src) == 2):
            err(f"metric {n}: source must be (product, measure or attribute)"); continue
        pid, sn = src
        if dp_model.is_pending(pid):
            warn(f"metric {n}: depends on pending product {pid}, not validated; re-point at WP0; {dp_model.PENDING[pid]}"); continue
        if pid not in readable and HOME.get(pid) in PENDING:
            warn(f"metric {n}: depends on {pid}, whose semantic model {HOME[pid]} is pending; re-point at WP0; {PENDING[HOME[pid]]}"); continue
        if pid not in readable or pid not in specs:
            err(f"metric {n}: source product {pid} is not this model's, SM-00's or a certified source"); continue
        sp = specs[pid]
        if sn not in {mm[0] for mm in sp["measures"]} and sn not in {a for _, _, al in sp["inputs"] for a in al}:
            err(f"metric {n}: '{sn}' is not a measure or input attribute of {pid}")
        if n in rg.CERTIFIED and rg.CERTIFIED[n][1:] != src:
            err(f"metric {n}: certified source is {rg.CERTIFIED[n][1:]}, not {src}")
        covered.add((pid, sn))

    for ex in m.get("excluded", []):
        if not (isinstance(ex, tuple) and len(ex) == 3 and ex[2]):
            err(f"excluded entry must be (product, measure, reason): {ex!r}"); continue
        if (ex[0], ex[1]) in covered:
            warn(f"{ex[0]} '{ex[1]}' is both published and excluded")
        covered.add((ex[0], ex[1]))
    for pid in sorted(own):
        for mn, _, _ in specs[pid]["measures"]:
            if (pid, mn) not in covered:
                err(f"{pid} measure '{mn}' is not published, used as a dimension or excluded")

    acc = m.get("access", {})
    if not acc.get("classification") or not acc.get("roles"):
        err("access needs a classification and at least one role")
    if any(specs[p]["pii"] == "Y" for p in own) and not any(r.get("hidden") for r in acc.get("roles", [])):
        warn("a product carries personal data but no role hides any column")
    for q in m.get("verified_questions", []):
        if not (q.get("question") and q.get("answer")):
            err(f"verified question needs question and answer: {q.get('question')!r}")
    for c in m.get("cannot_answer", []):
        g = c.get("gap", "")
        if g and not GAP_ID.match(g):
            err(f"cannot_answer '{c.get('question')}': gap '{g}' is not GAP-NN-###")
        elif g and gaps and g not in gaps:
            err(f"cannot_answer '{c.get('question')}': {g} is not in the gap register")
    return E, W


def load():
    """Everything the generator and the explorer need: (models, logical, specs, gaps, errors, warnings). The models
    pending WP0 re-scope (register.PENDING, CW-041) are left out."""
    logical, specs, gaps = load_context()
    models, errs = load_models()
    models = live_models(models)
    e, w = validate(models, logical, specs, gaps)
    return models, logical, specs, gaps, errs + e, w


if __name__ == "__main__":
    only = sys.argv[1] if len(sys.argv) > 1 else None
    logical, specs, gaps = load_context()
    models, errs = load_models()
    held = sorted(mid for mid in models if mid in PENDING)
    models = live_models(models)
    e, w = validate(models, logical, specs, gaps, only)
    errs += e
    for x in w: print("WARN ", x)
    for x in errs: print("ERROR", x)
    if held:
        print(f"{len(held)} model(s) pending WP0 re-scope, not validated (CW-041): {', '.join(held)}")
    dep = [x for x in errs if "defined in pending model" in x]
    if dep:
        print(f"{len(dep)} error(s) are live models that read a metric defined in a pending model")
    wdep = [x for x in w if "pending" in x and "WP0" in x]
    if wdep:
        print(f"{len(wdep)} warning(s) are live models or products that depend on a pending product or model (re-point at WP0)")
    print(f"{len(models)} model(s) loaded{' (checked ' + only + ')' if only else ''}: {len(errs)} error(s), {len(w)} warning(s)")
    sys.exit(1 if errs else 0)
