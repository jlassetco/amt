// Builds 00_Program/Wealth_Manager_Foundational_Talktrack.pptx: the foundational talktrack for the head of distribution
// and the data management team (taxonomy -> data products -> semantic layer -> uses, the wealth-manager pivot, and the
// rollover-into-advice use case). Speaker notes on every slide hold the spoken script.
//
// Run (needs node, pptxgenjs installed in a scratch folder, and the pptx skill's apply_theme.js):
//   mkdir -p /tmp/talktrack && cd /tmp/talktrack && npm init -y && npm install pptxgenjs
//   PPTX_SKILL=<path to the pptx skill folder> OUT_DIR=<repo>/00_Program NODE_PATH=/tmp/talktrack/node_modules \
//     node <repo>/_tools/talktrack/build_talktrack.js
// Counts quoted on the slides (50 domains, 1,583 objects, 13,009 attributes, 4,268 CDEs, 91 shared code lists, 551
// decisions, 237 term conflicts, 271 live products, 58 foundational, 55 functions, 22 semantic models of which the 12
// wealth subject areas SM-20 to SM-31) were checked against snapshot wealth-v1.0 on 2026-10-16; refresh them by hand
// when the model changes. Product, measure and metric names are the register's (data_products/framework.PRODUCTS, the
// spec modules and semantic_model/register.py); PTE 2020-02 documentation is three delivery dates plus the attestation.
// Foundational talktrack deck: taxonomy -> data products -> semantic layer -> uses, then the wealth manager specifically,
// with one end-to-end client & advice use case. Audience: Head of Distribution at a wealth manager and the data team.
const pptxgen = require("pptxgenjs");
const path = require("path");
const { applyTheme } = require(process.env.PPTX_SKILL + "/scripts/apply_theme.js");

const THEME = {
  name: "Wealth Reference Model",
  headFontFace: "Arial",
  bodyFontFace: "Arial",
  colors: {
    dk1: "1A2B3C", lt1: "FFFFFF", dk2: "0C233C", lt2: "EEF1F8",
    accent1: "1E49E2", accent2: "00796F", accent3: "7213EA", accent4: "C8166F", accent5: "0077A8", accent6: "535E6C",
    hlink: "1E49E2", folHlink: "7213EA",
  },
};
const HEX = THEME.colors;
const pres = new pptxgen();
pres.layout = "LAYOUT_WIDE"; // 13.333 x 7.5
pres.theme = { headFontFace: THEME.headFontFace, bodyFontFace: THEME.bodyFontFace };
pres.title = "From definitions to decisions";
pres.author = "Program lead";
pres.subject = "Taxonomy, data products and uses for a wealth manager";
const C = pres.SchemeColor;

const SW = 13.333, LM = 0.6, CW = SW - 2 * LM, TOP = 1.55, BOT = 6.8;
const FOOT = "Wealth Manager Reference Model  |  Draft for rehearsal, October 2026  |  Client, household and dollar figures are illustrative";

// ---------------------------------------------------------------------------------------------------------- layouts
pres.defineSlideMaster({
  title: "DARK",
  background: { color: HEX.dk2 },
  objects: [
    { placeholder: { options: { name: "title", type: "title", x: LM, y: 2.2, w: CW, h: 1.6, fontSize: 40, bold: true, color: C.background1, valign: "bottom", align: "left", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "body", type: "body", x: LM, y: 3.95, w: CW, h: 1.6, fontSize: 18, color: C.background2, valign: "top", margin: 0 }, text: "" } },
  ],
});
pres.defineSlideMaster({
  title: "DIVIDER",
  background: { color: HEX.dk2 },
  objects: [
    { placeholder: { options: { name: "kicker", type: "body", x: LM, y: 2.35, w: CW, h: 0.5, fontSize: 16, color: C.background2, margin: 0 }, text: "" } },
    { placeholder: { options: { name: "title", type: "title", x: LM, y: 2.85, w: CW, h: 1.4, fontSize: 40, bold: true, color: C.background1, valign: "top", align: "left", margin: 0 }, text: "" } },
    { placeholder: { options: { name: "body", type: "body", x: LM, y: 4.4, w: 9.5, h: 1.6, fontSize: 18, color: C.background2, valign: "top", margin: 0 }, text: "" } },
  ],
});
pres.defineSlideMaster({
  title: "CONTENT",
  background: { color: HEX.lt1 },
  objects: [
    { placeholder: { options: { name: "title", type: "title", x: LM, y: 0.45, w: CW, h: 0.95, fontSize: 28, bold: true, color: C.text2, valign: "middle", align: "left", margin: 0 }, text: "" } },
    { text: { text: FOOT, options: { x: LM, y: 7.0, w: 10.5, h: 0.3, fontSize: 9, color: C.accent6, margin: 0 } } },
  ],
  slideNumber: { x: 12.3, y: 7.0, w: 0.45, h: 0.3, fontSize: 9, color: HEX.accent6, align: "right" },
});

// ---------------------------------------------------------------------------------------------------------- helpers
let slideNo = 0;
function content(title, section, notes) {
  const s = pres.addSlide({ masterName: "CONTENT", sectionTitle: section });
  s.addText(title, { placeholder: "title" });
  if (notes) s.addNotes(notes);
  slideNo++;
  return s;
}
function text(s, t, o) {
  s.addText(t, Object.assign({ isTextBox: true, margin: 0, fontSize: 14, color: C.text1, valign: "top", objectName: "text" }, o));
}
function rect(s, x, y, w, h, fill, o) {
  s.addShape(pres.ShapeType.rect, Object.assign({ x, y, w, h, fill: { color: fill }, line: { color: fill, width: 0 }, objectName: "panel" }, o || {}));
}
function rrect(s, x, y, w, h, fill, o) {
  s.addShape(pres.ShapeType.roundRect, Object.assign({ x, y, w, h, fill: { color: fill }, line: { color: fill, width: 0 }, rectRadius: 0.08, objectName: "card" }, o || {}));
}
// A card: tinted panel, colored heading, body text.
function card(s, x, y, w, h, head, body, color, opts) {
  const o = Object.assign({ fill: C.background2, headSize: 14, bodySize: 12, headColor: color || C.accent1, pad: 0.18, bodyColor: C.text1 }, opts || {});
  rrect(s, x, y, w, h, o.fill);
  if (head) text(s, head, { x: x + o.pad, y: y + o.pad - 0.02, w: w - 2 * o.pad, h: 0.45, fontSize: o.headSize, bold: true, color: o.headColor });
  if (body) {
    const by = head ? y + o.pad + 0.45 : y + o.pad;
    if (Array.isArray(body)) {
      const items = body.map((b, i) => ({ text: b, options: { bullet: { indent: 12 }, breakLine: i < body.length - 1, paraSpaceAfter: 4 } }));
      s.addText(items, { x: x + o.pad, y: by, w: w - 2 * o.pad, h: h - (by - y) - o.pad, fontSize: o.bodySize, color: o.bodyColor, valign: "top", margin: 0, isTextBox: true, objectName: "card body" });
    } else {
      text(s, body, { x: x + o.pad, y: by, w: w - 2 * o.pad, h: h - (by - y) - o.pad, fontSize: o.bodySize, color: o.bodyColor });
    }
  }
}
// The motif: a numbered chip (circle + label), used for the five layers.
function chip(s, x, y, n, label, color, opts) {
  const o = Object.assign({ size: 0.42, labelW: 2.2, fontSize: 13, labelColor: C.text1, bold: true, dim: false }, opts || {});
  s.addShape(pres.ShapeType.ellipse, { x, y, w: o.size, h: o.size, fill: { color: o.dim ? C.background2 : color }, line: { color: o.dim ? C.accent6 : color, width: o.dim ? 1 : 0 }, objectName: "chip" });
  text(s, String(n), { x, y, w: o.size, h: o.size, fontSize: 12, bold: true, color: o.dim ? C.accent6 : C.background1, align: "center", valign: "middle" });
  text(s, label, { x: x + o.size + 0.12, y: y - 0.02, w: o.labelW, h: o.size + 0.04, fontSize: o.fontSize, bold: o.bold, color: o.dim ? C.accent6 : o.labelColor, valign: "middle" });
}
const LAYERS = [
  ["Source systems", C.accent6],
  ["Taxonomy", C.accent1],
  ["Foundational products", C.accent2],
  ["Consumer products", C.accent3],
  ["Semantic model and uses", C.accent4],
];
// Left rail for the use-case steps: all five chips, the current one lit.
function rail(s, current) {
  const cur = Array.isArray(current) ? current : [current];
  rrect(s, LM, TOP, 2.6, BOT - TOP, C.background2);
  text(s, "WHERE WE ARE", { x: LM + 0.2, y: TOP + 0.18, w: 2.2, h: 0.3, fontSize: 10, bold: true, color: C.accent6 });
  LAYERS.forEach((l, i) => chip(s, LM + 0.22, TOP + 0.7 + i * 0.92, i + 1, l[0], l[1], { labelW: 1.95, fontSize: 12, dim: !cur.includes(i + 1), bold: cur.includes(i + 1) }));
}
function arrow(s, x, y, w, h, color) {
  s.addShape(pres.ShapeType.rightArrow, { x, y, w, h, fill: { color: color || C.accent6 }, line: { color: color || C.accent6, width: 0 }, objectName: "arrow" });
}
function table(s, rows, x, y, w, colW, opts) {
  const o = Object.assign({ fontSize: 11, headFill: HEX.dk2, headColor: HEX.lt1, rowH: 0.36 }, opts || {});
  const data = rows.map((r, ri) => r.map((c) => ({
    text: c,
    options: ri === 0
      ? { bold: true, color: o.headColor, fill: { color: o.headFill }, fontSize: o.fontSize, valign: "middle" }
      : { color: HEX.dk1, fill: { color: ri % 2 ? HEX.lt1 : HEX.lt2 }, fontSize: o.fontSize, valign: "top" },
  })));
  s.addTable(data, { x, y, w, colW, border: { type: "solid", color: "D5DBE7", pt: 0.5 }, margin: 0.06, fontFace: "Arial", autoPage: false, objectName: "table" });
}

// ============================================================================================================ 0. OPEN
pres.addSection({ title: "Opening" });
{
  const s = pres.addSlide({ masterName: "DARK", sectionTitle: "Opening" });
  s.addText("From definitions to decisions", { placeholder: "title" });
  s.addText("The data taxonomy, the governed data products built on it, and what they do for client and advice at a wealth manager", { placeholder: "body" });
  text(s, "A TALKTRACK FOR THE HEAD OF DISTRIBUTION AND THE DATA MANAGEMENT TEAM", { x: LM, y: 1.55, w: CW, h: 0.4, fontSize: 12, bold: true, color: C.accent4, charSpacing: 2 });
  text(s, "Wealth Manager Reference Model  |  Draft for rehearsal, October 2026", { x: LM, y: 6.6, w: CW, h: 0.35, fontSize: 12, color: C.background2 });
  LAYERS.forEach((l, i) => chip(s, LM + i * 2.45, 5.75, i + 1, l[0], l[1], { labelW: 2.2, fontSize: 12, labelColor: C.background1 }));
  s.addNotes(
    "Good morning. This session has one aim: to show how a data taxonomy becomes something the distribution business can run on, not a dictionary that sits on a shelf.\n\n" +
    "I will do that in four parts. First the foundations: what the taxonomy is and the rules it enforces. Second the management overview: how we build governed data products on it, publish them through a semantic layer, and hand them to dashboards, workflows and control evidence. Third, the wealth manager specifically: where the household, the account, the advice relationship and the brokerage book of record sit in the model. Fourth, one question from your seat, followed end to end through every layer.\n\n" +
    "Two caveats before I start. This is a reference model for a hypothetical direct wealth manager; no real firm's data or systems are in it. And every client name and dollar figure you see is illustrative. The five chips at the bottom are the five layers we will keep coming back to."
  );
}
{
  const s = content("What we will cover, and the one rule behind all of it", "Opening",
    "Four parts, about forty-five minutes with questions. Parts one and two are generic to any asset or wealth manager; three and four are specific to your business.\n\n" +
    "If you remember one sentence from today, make it the rule on the right. Every layer we build applies it. The taxonomy says what a concept means and which domain masters it. A data product assembles those concepts; it never redefines them. A certified number is defined in one product only and read from there everywhere else. When a product needs something the taxonomy does not have, that is a gap for the owning domain to fix, not a field to invent in a report.\n\n" +
    "That rule is why the same number cannot come out differently in two places, and it is what I will test in the use case at the end.");
  const parts = [
    ["1", "Data foundations", "The taxonomy: one hierarchy, one owner per concept, 50 Data Domains, built and validated like code", "10 min", C.accent1],
    ["2", "Management overview", "Data products, certified numbers, logical models, the semantic layer, and the three ways the business uses them", "12 min", C.accent2],
    ["3", "The wealth manager", "A model built for a direct wealth manager: the household, the account, the advice relationship and the brokerage book of record at its center", "12 min", C.accent3],
    ["4", "One question, end to end", "A rollover from a recordkept plan into advice, traced from source system to answer, with the evidence the DOL requires", "10 min", C.accent4],
  ];
  parts.forEach((p, i) => {
    const y = TOP + i * 1.27;
    chip(s, LM, y + 0.1, p[0], p[1], p[4], { labelW: 2.6, fontSize: 16 });
    text(s, p[2], { x: LM + 3.3, y: y + 0.02, w: 4.9, h: 1.0, fontSize: 13, color: C.text1 });
    text(s, p[3], { x: LM + 8.3, y: y + 0.1, w: 0.8, h: 0.4, fontSize: 12, color: C.accent6 });
  });
  rrect(s, 10.0, TOP, 2.73, 4.9, C.text2);
  text(s, "THE ONE RULE", { x: 10.25, y: TOP + 0.25, w: 2.3, h: 0.35, fontSize: 11, bold: true, color: C.accent4 });
  text(s, "A data product assembles what the Data Domains master. It never remasters them.", { x: 10.25, y: TOP + 0.7, w: 2.3, h: 1.6, fontSize: 16, bold: true, color: C.background1 });
  text(s, "A certified number is defined in one product only, and every other product reads it from there.", { x: 10.25, y: TOP + 2.45, w: 2.3, h: 1.4, fontSize: 13, color: C.background2 });
  text(s, "A missing concept is a taxonomy gap for the owning domain, never a field invented in a report.", { x: 10.25, y: TOP + 3.75, w: 2.3, h: 1.0, fontSize: 12, color: C.background2 });
}
{
  const s = content("The problem we are solving: one number, five definitions", "Opening",
    "Here is the situation every distribution head recognizes. Ask five teams for net new assets last quarter and you get five numbers, each defensible, none reconcilable. The figures on the slide are illustrative, but the reasons are real and they recur everywhere: one team counts reinvested income, another does not; one treats a rollover from the firm's own plan as new money, another treats it as a transfer; one uses trade date, another settlement date; one includes intermediary-held fund assets, another does not.\n\n" +
    "The cost is not the arithmetic. It is the month-end hour spent arguing about which number is right, and the fact that no one can tell a regulator or a board which definition a given report used.\n\n" +
    "Notice that every one of the five differences is a definition question, not a technology question. That is exactly what a taxonomy settles.");
  const cards = [
    ["Advice leadership", "$1.42bn", "Counts firm-plan rollovers into advice as new money; trade date", C.accent3],
    ["Finance", "$1.18bn", "Excludes reinvested income; settlement date; net of fees", C.accent2],
    ["Workplace", "$0.96bn", "Counts separated participants' balances only when the IRA funds", C.accent5],
    ["Marketing", "$1.61bn", "Includes intermediary-held own-fund flows attributed to campaigns", C.accent4],
    ["Executive pack", "$1.30bn", "Hand-adjusted from last quarter's method, with two restatements", C.accent1],
  ];
  cards.forEach((c, i) => {
    const x = LM + i * 2.47, w = 2.3;
    rrect(s, x, TOP, w, 3.1, C.background2);
    text(s, c[0], { x: x + 0.18, y: TOP + 0.2, w: w - 0.36, h: 0.35, fontSize: 12, bold: true, color: C.accent6 });
    text(s, c[1], { x: x + 0.18, y: TOP + 0.6, w: w - 0.36, h: 0.8, fontSize: 32, bold: true, color: c[3] });
    text(s, c[2], { x: x + 0.18, y: TOP + 1.5, w: w - 0.36, h: 1.5, fontSize: 12, color: C.text1 });
  });
  text(s, "\"Net new assets, last quarter\"  (illustrative)", { x: LM, y: TOP + 3.3, w: 6, h: 0.35, fontSize: 12, italic: true, color: C.accent6 });
  rrect(s, LM, TOP + 3.85, CW, 1.35, C.text2);
  text(s, "Every difference is a definition question: what counts as a flow, which date, which channel, who owns the rule. None of them is a technology question. A taxonomy settles definitions once, with an owner; data products carry them through without rewriting them.",
    { x: LM + 0.3, y: TOP + 4.0, w: CW - 0.6, h: 1.05, fontSize: 15, color: C.background1, valign: "middle" });
}

// ============================================================================================================ 1. FOUNDATIONS
pres.addSection({ title: "1 Data foundations" });
{
  const s = pres.addSlide({ masterName: "DIVIDER", sectionTitle: "1 Data foundations" });
  s.addText("PART 1", { placeholder: "kicker" });
  s.addText("Data foundations: the taxonomy", { placeholder: "title" });
  s.addText("One hierarchy. One owner per concept. Fifty Data Domains that say what every business term means, built and validated like code.", { placeholder: "body" });
  chip(s, LM, 1.5, 2, "Taxonomy", C.accent1, { labelColor: C.background1, fontSize: 14 });
  s.addNotes("Part one. I will keep this short because the taxonomy is the layer most of you have seen in some form. What matters is the four things it fixes: the hierarchy, the ownership rule, the scope, and the way it is built.");
}
{
  const s = content("One hierarchy, four levels, followed for one attribute", "1 Data foundations",
    "The taxonomy has four levels and only four. A Data Domain is a business area that produces and maintains a set of concepts. Inside it, a Data Family groups related objects. A Data Business Object is one thing with its own identity and a stated grain, what one row represents. And a Data Business Attribute is one field with one definition.\n\n" +
    "Follow one attribute down. Domain 02 Client & Household. Family: Households & Relationships. Object: Household, the Client Household, a party of type Household, and the grain says so. Attribute: Primary Member, the member designated as the household's primary contact. It has a data type, a reference to the party master, an example value, a source we aligned it to, and a personal-data flag.\n\n" +
    "Every one of the thirteen thousand attributes carries that same record. That uniformity is what lets the later layers be validated by machine rather than by meeting.");
  const lv = [
    ["L1", "Data Domain", "02 Client & Household", "Masters the client master: who the client is, who acts for them, who they live and plan with, what they have told the firm, how identity was verified, what they consented to"],
    ["L2", "Data Family", "Households & Relationships", "Client Households, their effective-dated membership and the relationships between parties"],
    ["L3", "Data Business Object", "Household", "The Client Household: a party of type Household, key PTY-HH-. Carried as an attribute group of Party, as Individual and Organization are"],
    ["L4", "Data Business Attribute", "Primary Member", "The member designated as the household's primary contact"],
  ];
  lv.forEach((l, i) => {
    const y = TOP + i * 1.22, ind = i * 0.35;
    rrect(s, LM + ind, y, 7.2 - ind, 1.05, i === 3 ? C.accent1 : C.background2);
    const fg = i === 3 ? C.background1 : C.text2;
    text(s, l[0], { x: LM + ind + 0.2, y: y + 0.15, w: 0.5, h: 0.4, fontSize: 11, bold: true, color: i === 3 ? C.background1 : C.accent1 });
    text(s, l[1], { x: LM + ind + 0.7, y: y + 0.12, w: 2.3, h: 0.4, fontSize: 14, bold: true, color: fg });
    text(s, l[2], { x: LM + ind + 3.0, y: y + 0.12, w: 4.0 - ind, h: 0.4, fontSize: 14, bold: true, color: i === 3 ? C.background1 : C.accent1 });
    text(s, l[3], { x: LM + ind + 0.7, y: y + 0.5, w: 6.3 - ind, h: 0.5, fontSize: 11, color: fg });
  });
  rrect(s, 8.3, TOP, 4.43, 4.85, C.text2);
  text(s, "THE ATTRIBUTE RECORD", { x: 8.55, y: TOP + 0.22, w: 4, h: 0.3, fontSize: 11, bold: true, color: C.accent4 });
  const rec = [
    ["Attribute", "Primary Member"], ["Definition", "Member designated as the household's primary contact"], ["Applies to", "Household"],
    ["Data type", "Reference (Party)"], ["Example", "PTY-104588"], ["Ownership", "Mastered here (02)"], ["Aligned to", "Salesforce FSC household model"],
    ["CDE", "Not a critical data element; the Household key is"], ["Personal data", "PII - identity tier"],
  ];
  rec.forEach((r, i) => {
    const y = TOP + 0.65 + i * 0.45;
    text(s, r[0], { x: 8.55, y, w: 1.3, h: 0.42, fontSize: 11, bold: true, color: C.background2 });
    text(s, r[1], { x: 9.9, y, w: 2.7, h: 0.42, fontSize: 11, color: C.background1 });
  });
}
{
  const s = content("One owner per concept: mastered, referenced or derived", "1 Data foundations",
    "The ownership rule is the heart of the taxonomy. Every attribute is flagged one of three ways. Mastered here: this domain produces and maintains it. Reference: this domain points to a concept another domain masters, by its enterprise ID, and adds only what belongs to the relationship. Derived copy: a value copied from the owner for a stated reason, with the as-of date kept.\n\n" +
    "The advice domain shows all three at once. The investor profile, the client's objectives and risk tolerance, is mastered in 02. A recommendation in 45 references the profile version it relied on; it never copies the objective, because then two versions could disagree. The rollover amount on a rollover analysis is a derived copy of the vested balance that 16 Retirement Plan Administration masters, and the row rule says so.\n\n" +
    "Consumption never changes ownership. A report reading the investor profile does not make the report the owner. That one sentence removes most of the month-end arguments.");
  const cols = [
    ["Mastered here", "The domain that produces and maintains the concept owns its meaning and its quality.", "02 Client & Household masters the Investor Profile: objectives, risk tolerance, time horizon, financial situation, versioned each time it changes.", C.accent1, "11,500+ attributes"],
    ["Reference", "Another domain points to the concept by its enterprise ID and adds only what belongs to the relationship.", "45 Financial Planning & Advice holds, on each Recommendation, the Investor Profile version it relied on. It never copies the objective or the risk score.", C.accent2, "1,100+ references"],
    ["Derived copy", "A value copied from its owner for a stated reason, with the as-of date and the row rule recorded.", "45 Rollover Analysis carries Rollover Amount as a copy of the vested balance mastered in 16 Retirement Plan Administration.", C.accent3, "Flagged per attribute"],
  ];
  cols.forEach((c, i) => {
    const x = LM + i * 4.1, w = 3.9;
    rrect(s, x, TOP, w, 3.6, C.background2);
    rect(s, x, TOP, w, 0.9, c[3]);
    text(s, c[0], { x: x + 0.22, y: TOP + 0.12, w: w - 0.44, h: 0.66, fontSize: 18, bold: true, color: C.background1, valign: "middle" });
    text(s, c[1], { x: x + 0.22, y: TOP + 1.05, w: w - 0.44, h: 1.0, fontSize: 12, color: C.text1 });
    text(s, "In the advice domain", { x: x + 0.22, y: TOP + 2.05, w: w - 0.44, h: 0.3, fontSize: 10, bold: true, color: C.accent6 });
    text(s, c[2], { x: x + 0.22, y: TOP + 2.35, w: w - 0.44, h: 1.2, fontSize: 11.5, color: C.text1 });
  });
  rrect(s, LM, TOP + 3.85, CW, 1.35, C.text2);
  text(s, "The ownership rule", { x: LM + 0.3, y: TOP + 4.0, w: 3, h: 0.35, fontSize: 11, bold: true, color: C.accent4 });
  text(s, "The Data Domain that produces and maintains a concept masters it. Every other domain references it by enterprise ID. Consumption never remasters ownership: a report that reads the investor profile does not become its owner.",
    { x: LM + 0.3, y: TOP + 4.35, w: CW - 0.6, h: 0.8, fontSize: 14, color: C.background1 });
}
{
  const s = content("The landscape: 50 Data Domains in eight areas", "1 Data foundations",
    "This is the whole model on one page. Fifty Data Domains, grouped into eight areas. The areas are a presentation choice, not a second taxonomy; they decide which view of the explorer a team opens.\n\n" +
    "The Client & Advice area is the center of gravity for a wealth manager, and it is where part four lives: the household, the account, planning and advice, managed portfolios, fees, the advisor organization, marketing, service, conduct, and the product and offering reference. Brokerage & Workplace Operations holds the books of record for client assets, orders and money. Foundations runs along the bottom because every other area reads it: reference data, instruments, licensed data and governance.\n\n" +
    "The numbers on the right are the current build. Four thousand of the thirteen thousand attributes are flagged as critical data elements, which is where the quality effort concentrates.");
  const areas = [
    ["Client & Advice", ["01 Investment Product & Service Offering", "02 Client & Household", "03 Advisor Organization, Coverage & Supervision", "04 Marketing, Digital & Client Engagement", "08 Retail Conduct & Supervision", "13 Client Service & Communications", "15 Account", "36 Product Development & Lifecycle", "45 Financial Planning & Advice", "46 Managed Portfolios & Rebalancing", "47 Pricing, Fees & Billing", "51 Trust & Estate Services"], C.accent1],
    ["Brokerage & Workplace", ["16 Retirement Plan Administration", "48 Brokerage Orders & Execution", "49 Clearing, Settlement & Client Asset Custody", "50 Money Movement, Cash & Sweep"], C.accent5],
    ["Distribution & Economics", ["05 Intermediary & Institutional Distribution", "06 Client Assets, Flows & Channel Attribution", "10 Client Revenue, Pricing Economics & Profitability", "11 Market & Competitive Intelligence", "12 Institutional Client Servicing & Reporting"], C.accent3],
    ["Investment", ["23 Investment Research", "24 Portfolio Management & Construction", "25 Portfolio Trading & Execution", "34 Stewardship & Sustainable Investing", "52 External Manager & Sub-Adviser Oversight"], C.accent2],
    ["Investment Operations", ["18 Portfolio & Investment Book of Record", "22 Market Data & Pricing", "26 Trade Operations, Settlement & Collateral", "31 Investment Risk", "32 Performance & Attribution", "33 Investment Compliance"], C.accent2],
    ["Fund Operations", ["27 Fund Accounting & Valuation", "28 Fund Custody & Asset Servicing", "29 Transfer Agency Operations", "35 Fund Governance & Regulatory Reporting"], C.accent2],
    ["Corporate Functions", ["19 Finance & Accounting", "20 Human Capital", "37 Enterprise & Operational Risk", "38 Corporate Compliance & Regulatory Affairs", "39 Legal & Corporate Governance", "40 Procurement & Vendor Management", "41 Technology & Information Security", "42 Corporate Communications & Public Affairs", "43 Corporate Treasury & Capital", "44 Workplace & Corporate Services"], C.accent6],
  ];
  // Five columns; each block's height is estimated from its wrapped lines so nothing overflows.
  const colW = 2.3, gap = 0.16, bandY = TOP + 4.15;
  function est(a) { let lines = 0; a[1].forEach((t) => { lines += Math.ceil(t.length / 36); }); return 0.5 + lines * 0.155 + 0.1; }
  function block(x, y, w, h, a) {
    rrect(s, x, y, w, h, C.background2);
    text(s, a[0], { x: x + 0.14, y: y + 0.1, w: w - 0.28, h: 0.3, fontSize: 11, bold: true, color: a[2] });
    text(s, a[1].join("\n"), { x: x + 0.14, y: y + 0.42, w: w - 0.28, h: h - 0.5, fontSize: 8.5, color: C.text1, lineSpacingMultiple: 1.05 });
  }
  const stacks = [[areas[0]], [areas[1], areas[2]], [areas[3], areas[4]], [areas[5], areas[6]]];
  stacks.forEach((st, ci) => {
    const x = LM + ci * (colW + gap);
    let y = TOP;
    st.forEach((a) => { const h = st.length === 1 ? bandY - TOP - 0.15 : est(a); block(x, y, colW, h, a); y += h + 0.15; });
  });
  rrect(s, LM, bandY, 4 * colW + 3 * gap, 0.95, C.text2);
  text(s, "Foundations (a band every area reads)", { x: LM + 0.14, y: bandY + 0.08, w: 4, h: 0.3, fontSize: 11, bold: true, color: C.background1 });
  text(s, "09 Shared & Enterprise Reference Data   |   14 Third-Party Data & Licensing   |   17 Instrument & Issuer Reference   |   21 Data Governance & Analytics", { x: LM + 0.14, y: bandY + 0.42, w: 10, h: 0.45, fontSize: 10, color: C.background2 });
  const stats = [["50", "Data Domains"], ["1,583", "business objects"], ["13,009", "attributes, each with one definition and one owner"], ["4,268", "critical data elements"]];
  stats.forEach((st, i) => {
    const y = TOP + i * 1.3;
    text(s, st[0], { x: LM + 4 * (colW + gap), y, w: 2.3, h: 0.65, fontSize: 30, bold: true, color: C.accent1 });
    text(s, st[1], { x: LM + 4 * (colW + gap), y: y + 0.62, w: 2.3, h: 0.6, fontSize: 10.5, color: C.accent6 });
  });
}
{
  const s = content("Built like code, so it can be trusted like a product", "1 Data foundations",
    "A taxonomy that lives in a spreadsheet dies in a spreadsheet. Ours is content as code. Every domain is a content module; the workbooks, the explorer and the catalogs are generated from it, never edited by hand. A builder validates each module before it writes anything: duplicate codes, undefined code lists, references that do not resolve, missing grain.\n\n" +
    "Three registers sit alongside. Shared code lists, so that channel, status and frequency mean the same thing in every domain. A decision log, so that every change to an owner or a definition traces to a numbered decision with a rationale. And a term-conflict list, because the same word means different things in different rooms: a plan is a financial plan in advice and a retirement plan in recordkeeping, and the glossary says which is which.\n\n" +
    "Personal data is flagged attribute by attribute with a tier, and every retail-conduct and customer-protection object cites the FINRA or SEC rule by number. For your data team, this is the part that makes the later layers cheap to keep correct.");
  const rows = [
    ["Content as code", "Each Data Domain is a module; workbooks, explorer and catalogs are generated, never hand-edited. A renamed attribute breaks the build instead of leaving a stale report."],
    ["Validated at build", "Tuple shapes, duplicate codes, code lists, references, grain and ownership are checked before anything is written."],
    ["Shared code lists", "91 enterprise code lists shared by every domain, so channel, status and frequency mean the same thing everywhere."],
    ["Decision log", "551 numbered decisions, each with the issue, the resolution, the rationale and the owner role. Every ownership change traces to one."],
    ["Term conflicts", "237 words that mean different things in different rooms, resolved in the glossary: Plan, Order, Holding, Custody, Fee, Program, Transfer."],
    ["Personal data and regulation", "Every attribute carries a PII tier; special-category data is aggregates only; every conduct object cites the rule by number."],
  ];
  rows.forEach((r, i) => {
    const col = i % 2, row = Math.floor(i / 2);
    const x = LM + col * 6.2, y = TOP + row * 1.65, w = 5.95;
    rrect(s, x, y, w, 1.5, C.background2);
    s.addShape(pres.ShapeType.ellipse, { x: x + 0.2, y: y + 0.2, w: 0.5, h: 0.5, fill: { color: [C.accent1, C.accent2, C.accent3, C.accent4, C.accent5, C.accent6][i] }, line: { width: 0 }, objectName: "dot" });
    text(s, String(i + 1), { x: x + 0.2, y: y + 0.2, w: 0.5, h: 0.5, fontSize: 13, bold: true, color: C.background1, align: "center", valign: "middle" });
    text(s, r[0], { x: x + 0.9, y: y + 0.18, w: w - 1.1, h: 0.4, fontSize: 14, bold: true, color: C.text2 });
    text(s, r[1], { x: x + 0.9, y: y + 0.58, w: w - 1.1, h: 0.9, fontSize: 11.5, color: C.text1 });
  });
}

// ============================================================================================================ 2. MANAGEMENT OVERVIEW
pres.addSection({ title: "2 Management overview" });
{
  const s = pres.addSlide({ masterName: "DIVIDER", sectionTitle: "2 Management overview" });
  s.addText("PART 2", { placeholder: "kicker" });
  s.addText("Building on it: products, models and uses", { placeholder: "title" });
  s.addText("The taxonomy says what things mean. It does not say how the business consumes them. Data products, logical models and the semantic layer do that, without ever redefining a term.", { placeholder: "body" });
  LAYERS.slice(2).forEach((l, i) => chip(s, LM + i * 3.2, 1.5, i + 3, l[0], l[1], { labelColor: C.background1, fontSize: 14, labelW: 2.6 }));
  s.addNotes("Part two is the management overview. The question to hold in mind: if the taxonomy fixes meaning, what turns meaning into numbers people trust? The answer is three more layers, each with its own job, and a governance model that keeps them honest.");
}
{
  const s = content("From taxonomy to consumption", "2 Management overview",
    "This is the operating model, drawn the same way it appears in the explorer's guide. Read it twice: data moves left to right, meaning moves top to bottom.\n\n" +
    "The taxonomy is not the first step in a pipeline; it is the plane across the top that governs every layer. Follow the blue arrows down. Source systems are mapped to its attributes. Foundational products trace their lineage to its definitions, and when a product needs something the taxonomy lacks, the gap goes back up to the owning domain, which is the dashed arrow. The semantic layer takes its business names and metric definitions from it. And the business glossary shows it to the people consuming the numbers.\n\n" +
    "Now left to right. Sources are ingested into data products, which have two tiers: foundational products conform a record or a number once, certify it and lock snapshots; consumer-aligned products build on them and are shaped for one function. From there, two paths. Products whose consumer is an analyst are published through the semantic layer, which exposes one governed set of certified metrics, conformed dimensions, hierarchies, synonyms and access rules to dashboards, Excel and AI assistants. Products whose consumer is a system or a process go straight into the workflow or the regulatory output: household and account data into the CRM and the advisor desktop, fee debits to the brokerage book of record, best-interest evidence to the compliance file.\n\n" +
    "The point of the two paths is the last line of the caption: both take their numbers from the same certified products. The semantic layer exposes certified numbers; it never defines them.");
  const k = CW / 1320, X = (x) => LM + x * k, Y = (y) => TOP + y * k, S = (v) => v * k;
  const INK = HEX.dk1, MUTED = HEX.accent6, BLUE = HEX.accent1, MAG = HEX.accent4, LINE = "D5DBE7";
  const box = (x, y, w, h, fill, lineColor, lw, extra) => s.addShape(pres.ShapeType.roundRect, Object.assign({ x: X(x), y: Y(y), w: S(w), h: S(h), fill: fill ? { color: fill } : { color: "FFFFFF", transparency: 100 }, line: { color: lineColor, width: lw || 1 }, rectRadius: 0.05, objectName: "flow box" }, extra || {}));
  const txt = (x, y, t, o) => text(s, t, Object.assign({ x: X(x), y: Y(y), w: S(200), h: S(20), fontSize: 9, color: INK }, o));
  const hline = (x1, x2, y, color, o) => s.addShape(pres.ShapeType.line, Object.assign({ x: X(x1), y: Y(y), w: S(x2 - x1), h: 0, line: { color, width: 1.25, endArrowType: "triangle" }, objectName: "arrow" }, o || {}));
  const vline = (x, y1, y2, color, o) => s.addShape(pres.ShapeType.line, Object.assign({ x: X(x), y: Y(Math.min(y1, y2)), w: 0, h: S(Math.abs(y2 - y1)), flipV: y2 < y1, line: { color, width: 1.25, endArrowType: "triangle" }, objectName: "arrow" }, o || {}));
  const num = (cx, cy, n) => {
    s.addShape(pres.ShapeType.ellipse, { x: X(cx - 11), y: Y(cy - 11), w: S(22), h: S(22), fill: { color: INK }, line: { color: INK, width: 0 }, objectName: "number" });
    text(s, String(n), { x: X(cx - 11), y: Y(cy - 11), w: S(22), h: S(22), fontSize: 8, bold: true, color: HEX.lt1, align: "center", valign: "middle" });
  };
  const prod = (x, y, id, label) => { txt(x, y - 12, id, { fontSize: 8, bold: true, w: S(150), h: S(16) }); txt(x, y + 2, label, { fontSize: 8, color: MUTED, w: S(155), h: S(16) }); };
  const list = (x, y, items, color) => items.forEach((t, i) => txt(x, y + i * 21, t, { color: color || MUTED }));

  // The taxonomy plane across the top
  box(20, 16, 1280, 76, "E3E9FC", BLUE, 1);
  txt(40, 26, "Enterprise Data Taxonomy: meaning and accountability", { fontSize: 11, bold: true, color: BLUE, w: S(900), h: S(24) });
  txt(40, 54, "Data Domains  >  Family  >  Object  >  Attribute, each with an owner; CDEs; shared code lists; certified measure definitions", { color: INK, w: S(1000) });
  num(1278, 38, 1);
  [[130, "mapped to sources"], [420, "traced to definitions"], [904, "business names, metric definitions"], [1190, "glossary"]].forEach(([x, t]) => {
    vline(x, 92, 146, BLUE);
    txt(x + 6, 102, t, { fontSize: 8, color: BLUE, w: S(x === 904 ? 110 : 150), h: S(40) });
  });
  vline(580, 146, 96, BLUE, { line: { color: BLUE, width: 1.25, endArrowType: "triangle", dashType: "dash" } });
  txt(586, 102, "gaps sent back", { fontSize: 8, color: BLUE, w: S(120) });

  // Source systems
  box(20, 150, 220, 250, HEX.lt2, LINE, 1);
  txt(36, 162, "Source systems", { fontSize: 11, bold: true });
  list(36, 192, ["CRM and onboarding", "Brokerage books and records", "Order management", "Money movement hub", "Transfer agent", "Plan recordkeeping", "Planning and billing engines", "Contracts, compliance"]);

  // Data products: two tiers
  box(304, 150, 420, 250, null, MUTED, 1);
  txt(320, 162, "Data products", { fontSize: 11, bold: true }); num(702, 171, 2);
  box(320, 192, 170, 194, HEX.lt1, LINE, 1);
  txt(334, 200, "Foundational", { bold: true }); txt(334, 219, "Conform once, certify, lock", { fontSize: 8, color: MUTED });
  prod(334, 262, "DP-240", "Client & Household Master"); prod(334, 302, "DP-093", "Account Master"); prod(334, 342, "DP-008", "Client Assets & NNA");
  box(538, 192, 170, 194, HEX.lt1, LINE, 1);
  txt(552, 200, "Consumer-aligned", { bold: true }); txt(552, 219, "Shaped for one function", { fontSize: 8, color: MUTED });
  prod(552, 262, "DP-320", "Household 360"); prod(552, 302, "DP-335", "Rollover & PTE Evidence"); prod(552, 342, "DP-241", "Firm AUM Reconciliation");
  hline(490, 536, 289, INK);
  txt(490, 268, "builds", { fontSize: 8, color: MUTED, w: S(46), align: "center" }); txt(490, 293, "on", { fontSize: 8, color: MUTED, w: S(46), align: "center" });

  // Semantic layer and the two uses
  box(794, 150, 220, 160, HEX.lt1, INK, 1.5);
  txt(810, 162, "Semantic layer", { fontSize: 11, bold: true }); num(992, 171, 4);
  list(810, 192, ["Certified metrics", "Conformed dimensions", "Hierarchies", "Synonyms", "Row and column access"]);
  box(1080, 150, 220, 160, HEX.lt2, LINE, 1);
  txt(1096, 162, "Analytical use", { fontSize: 11, bold: true });
  list(1096, 192, ["BI dashboards", "Self-service and Excel", "AI assistants and", "natural-language query"]);
  box(1080, 330, 220, 122, "F9E3EE", MAG, 1);
  txt(1096, 338, "Workflow and regulatory use", { fontSize: 11, bold: true, color: MAG, w: S(200), h: S(40) });
  txt(1096, 380, "CRM, advisor desktop, client statements, billing, regulators", { color: INK, w: S(195), h: S(40) });
  txt(1096, 424, "via API, file, event", { color: MUTED });

  // Data moves left to right
  hline(240, 302, 275, INK); txt(240, 255, "ingest", { fontSize: 8, color: MUTED, w: S(62), align: "center" });
  hline(724, 792, 230, INK); txt(724, 210, "publish", { fontSize: 8, color: MUTED, w: S(68), align: "center" });
  hline(1014, 1078, 230, INK); txt(1014, 210, "query", { fontSize: 8, color: MUTED, w: S(64), align: "center" });
  s.addShape(pres.ShapeType.line, { x: X(724), y: Y(370), w: S(226), h: 0, line: { color: MAG, width: 1.5 }, objectName: "direct delivery" });
  s.addShape(pres.ShapeType.line, { x: X(950), y: Y(370), w: 0, h: S(15), line: { color: MAG, width: 1.5 }, objectName: "direct delivery" });
  hline(950, 1078, 385, MAG, { line: { color: MAG, width: 1.5, endArrowType: "triangle" } });
  txt(740, 350, "direct delivery", { fontSize: 8, color: MAG, w: S(120) }); num(950, 345, 3);

  text(s, "Data moves left to right; meaning moves top to bottom. Products used for analysis are published through the semantic layer. Others go straight into a workflow or a regulatory output, because their consumer is a system or a process rather than an analyst. Both paths take their numbers from the same certified products.",
    { x: LM, y: Y(470) + 0.1, w: CW, h: 0.75, fontSize: 10.5, italic: true, color: C.accent6 });
}
{
  const s = content("A data product: a governed asset with a specification", "2 Management overview",
    "A data product is not a table and not a dashboard. It is a governed, reusable data asset with a named owner, a defined grain, service levels and quality rules, built once for a set of consumers and traced to the exact taxonomy objects and attributes it uses.\n\n" +
    "Every product has the same specification. The left column is the standard. On the right is a real one, condensed: the advice record, DP-303. It belongs to the Head of Advice. Its grain is the recommendation by client by the moment it was presented, with the evidence components underneath. Its measures include recommendation acceptance rate, rollover recommendations without analysis and unattested evidence components, each with a formula that names the attributes it reads. It has six testable quality rules, which become its certification criteria.\n\n" +
    "Two things to notice for the data team. The measures' formulas name attributes, and the build checks that every one of them is among the product's inputs. And the quality rules are written as tests: a recommendation whose profile version was not active when it was presented fails the rule, full stop.");
  const std = [
    ["Identity", "ID, name, tier, type"], ["Accountability", "Owning Data Domain, accountable owner role"],
    ["Consumers", "Primary and supporting functions, the questions it answers"],
    ["Shape", "Grain, dimensions, measures with explicit formulas naming the attributes read"],
    ["Lineage", "The exact objects and attributes, from the mastering domain"], ["Dependencies", "The upstream products it is built from"],
    ["Service levels", "Refresh, timeliness, history"], ["Protection", "Information classification, personal data flag"],
    ["Delivery", "Warehouse table, BI model, CRM embed, API, file, filing"], ["Quality", "3 to 6 testable rules: the certification criteria"],
  ];
  text(s, "THE SPECIFICATION STANDARD", { x: LM, y: TOP, w: 5.5, h: 0.3, fontSize: 11, bold: true, color: C.accent6 });
  std.forEach((r, i) => {
    const y = TOP + 0.4 + i * 0.49;
    rect(s, LM, y + 0.42, 5.6, 0.01, "D5DBE7");
    text(s, r[0], { x: LM, y, w: 1.6, h: 0.42, fontSize: 12, bold: true, color: C.text2, valign: "middle" });
    text(s, r[1], { x: LM + 1.65, y, w: 3.95, h: 0.42, fontSize: 11, color: C.text1, valign: "middle" });
  });
  const px = 6.7, pw = 6.03;
  rrect(s, px, TOP, pw, 5.25, C.background2);
  rect(s, px, TOP, pw, 0.7, C.accent2);
  text(s, "DP-303  Advice Plans & Recommendations", { x: px + 0.22, y: TOP + 0.08, w: pw - 0.44, h: 0.55, fontSize: 15, bold: true, color: C.background1, valign: "middle" });
  const spec = [
    ["Tier, type", "Foundational; Master & Reference. Owner: Head of Advice. Domain 45."],
    ["Grain", "Recommendation x client x presented timestamp, with the best-interest evidence components, rollover analysis and PTE 2020-02 documentation beneath it; plus engagements, goals, plans and versions"],
    ["Measures", "Recommendations Presented; Recommendation Acceptance Rate; Accepted Recommendations Implemented %; Unattested Evidence Components; Rollover Recommendations Without Analysis; Rule 3a-4 Annual Contacts On Time %"],
    ["Reads", "45 Recommendation, Rationale, Alternative, Best Interest Evidence, Rollover Analysis, PTE 2020-02 Documentation; 02 Party and Investor Profile (by version); 03 Advisor; 24 Capital Market Assumption Set"],
    ["Depends on", "DP-240 party and household master, DP-093 account master, DP-004 offerings, DP-009 advisor organization, DP-530 capital market assumptions; nine foundational products in all"],
    ["Quality rule 4", "Type, capacity, source, profile version, presented timestamp and client decision populated on every presented recommendation; fiduciary status basis, reasons and completion date on every completed rollover analysis; the three PTE 2020-02 delivery dates and the attestation on every analysis presented as an acknowledged fiduciary"],
    ["Protection", "Confidential - Personal Data at account and client grain; the BI model carries counts by dimension only"],
  ];
  const rowH = [0.42, 0.72, 0.8, 0.72, 0.5, 0.78, 0.5];
  spec.forEach((r, i) => {
    const y = TOP + 0.85 + rowH.slice(0, i).reduce((a, b) => a + b, 0);
    text(s, r[0], { x: px + 0.22, y, w: 1.25, h: 0.6, fontSize: 10.5, bold: true, color: C.accent2 });
    text(s, r[1], { x: px + 1.5, y, w: pw - 1.72, h: rowH[i], fontSize: 9.5, color: C.text1 });
  });
}
{
  const s = content("Two tiers, five types: the type tells you what the product is for", "2 Management overview",
    "The catalog has two tiers. Foundational products conform one core thing once: a master, a book of record, a certified number. They may depend only on other foundational products, and there are no cycles; the builder enforces both. Consumer products are shaped around one function's decisions and built from the foundational ones.\n\n" +
    "Across both tiers there are five types, and the type tells you what a product is for. Master and reference products are golden records with history. Conformed facts are reconciled transactions and time series. Analytical products carry aggregated measures for management decisions, and they are what dashboards read. Operational products deliver data into a workflow to drive daily action: a call list, an advisor worklist, a billing run, a supervisory queue. Regulatory and control products are evidence: they demonstrate that a rule was followed.\n\n" +
    "The point for this room: the analytical products are not the majority. Most of the value sits in operational and control products that never appear on a dashboard. When we talk about uses later, that is why there are three, not one.");
  rect(s, LM, TOP, CW, 0.55, C.accent2);
  text(s, "FOUNDATIONAL   conform one core thing once; depend only on each other; no cycles", { x: LM + 0.25, y: TOP, w: CW - 0.5, h: 0.55, fontSize: 13, bold: true, color: C.background1, valign: "middle" });
  rect(s, LM, TOP + 2.7, CW, 0.55, C.accent3);
  text(s, "CONSUMER-ALIGNED   shaped around one function's decisions; built from foundational products", { x: LM + 0.25, y: TOP + 2.7, w: CW - 0.5, h: 0.55, fontSize: 13, bold: true, color: C.background1, valign: "middle" });
  const types = [
    ["Master & Reference", "Golden records and hierarchies, with history", "DP-240 Client, Household & Party Master\nDP-093 Account Master\nDP-303 Advice Plans & Recommendations", "Both tiers"],
    ["Conformed Facts", "Reconciled, attributed transactions and time series", "DP-300 Client Holdings, Lots & Cost Basis\nDP-006 Client Flow Transactions\nDP-008 Client Assets & Net New Assets", "Both tiers"],
    ["Analytical", "Aggregated measures, scores and comparisons for management decisions", "DP-320 Household 360\nDP-333 Advice Funnel & Conversion\nDP-491 Net New Assets by Channel, Offering & Advisor", "Dashboards, Excel, AI"],
    ["Operational", "Data delivered into a workflow to drive daily action", "DP-340 Advisor Client Action Worklist\nDP-336 Advice Review Cadence & Plan Currency\nDP-398 Principal Review Queue", "Workflow"],
    ["Regulatory & Control", "Evidence and monitoring that demonstrate compliance or control", "DP-334 Recommendation Evidence (Reg BI File)\nDP-335 Rollover Recommendations & PTE 2020-02 Evidence\nDP-346 Fee Billing Accuracy & Custody-Rule Evidence", "Evidence"],
  ];
  types.forEach((t, i) => {
    const x = i < 2 ? LM + i * 2.55 : LM + (i - 2) * 4.1, w = i < 2 ? 2.4 : 3.9;
    const y = i < 2 ? TOP + 0.7 : TOP + 3.4;
    rrect(s, x, y, w, 1.85, C.background2);
    text(s, t[0], { x: x + 0.15, y: y + 0.12, w: w - 0.3, h: 0.35, fontSize: 13, bold: true, color: C.text2 });
    text(s, t[1], { x: x + 0.15, y: y + 0.47, w: w - 0.3, h: 0.55, fontSize: 10.5, color: C.accent6 });
    text(s, t[2], { x: x + 0.15, y: y + 1.0, w: w - 0.3, h: 0.85, fontSize: 8.5, color: C.text1 });
  });
  rrect(s, LM + 5.2, TOP + 0.7, CW - 5.2, 1.85, C.text2);
  text(s, "HOW TO READ THE CATALOG", { x: LM + 5.45, y: TOP + 0.85, w: 6.5, h: 0.3, fontSize: 10, bold: true, color: C.accent4 });
  text(s, "Master & Reference and Conformed Facts appear in both tiers. Analytical, Operational and Regulatory & Control are consumer-aligned, and the type decides the delivery: Analytical to the BI semantic model, Excel and AI assistants; Operational into CRM, worklists, billing and supervision queues; Regulatory & Control into evidence packs and filings.",
    { x: LM + 5.45, y: TOP + 1.18, w: CW - 5.7, h: 1.3, fontSize: 11, color: C.background1 });
}
{
  const s = content("Certified numbers: defined in one product, read everywhere else", "2 Management overview",
    "A certified number is one the firm will sign its name to: the figure in the board pack, the regulatory filing and the client statement. The rule is simple and strict. Each certified family is defined in exactly one product, owned by one role, and every other product reads it from there and names its source. No consumer product ever recalculates it.\n\n" +
    "For a wealth manager the families are these. Client Assets, Net New Assets, Advised Assets and the household, client and account counts come from one product owned by client and channel analytics. Firm AUM, the manufacturing number, is reconciled against Client Assets in its own product. Personal rate of return belongs to performance measurement, not to the planning tool. Fee revenue reconciles to the general ledger.\n\n" +
    "What this buys you: when the dashboard, the advisor's screen and the finance pack all show net new assets, they show the same figure because none of them owns it. And when the definition has to change, it changes in one place, through a decision, with a restatement trail.");
  const rows = [
    ["Certified family", "Defined once in", "Owner role", "Read by, for example"],
    ["Client Assets (beginning, ending, average); Net New Assets; Advised Assets; Net Inter-Channel Transfers; Households, Clients, Funded Accounts", "DP-008 Client Assets & Net New Assets", "Head of Client & Channel Analytics", "Household 360, executive scorecard, NNA by channel and advisor, rollover capture, cost to serve"],
    ["Firm AUM and its three slices (own funds at NAV, managed accounts, institutional)", "DP-241 Firm AUM & Client Assets Reconciliation", "Head of Fund Accounting", "Board pack, Form ADV, fund board reporting"],
    ["Fund and class net assets, NAV per share, shares outstanding, expense ratios", "DP-165 NAV & Fund Financials", "Head of Fund Accounting", "Fund 360, product P&L, shareholder reports"],
    ["Official and benchmark returns; Personal Rate of Return (time- and money-weighted, account and household)", "DP-145 Official Returns", "Head of Performance Measurement", "Goal progress, household performance view, client statements"],
    ["Gross and net fee revenue; effective net fee rate", "DP-012 Client Fee Revenue (reconciles to DP-191)", "Head of Client Revenue Finance", "Client economics, pricing realization, profitability"],
    ["Revenue, operating expense, operating income; headcount and FTE; pay", "DP-191 General Ledger Journals & Balances; DP-192 Employee & Position Master; DP-198 Pay, Payroll & Benefits", "Finance Controller; Head of HR Data & People Analytics; Head of Reward", "Cost to serve, advisor capacity, management reporting"],
  ];
  table(s, rows, LM, TOP, CW, [4.3, 3.0, 2.2, 2.63], { fontSize: 10 });
  rrect(s, LM, 6.05, CW, 0.65, C.text2);
  text(s, "Rule: a consumer product never recalculates a certified number. It reads it from the owning product and names it. Client Assets and Firm AUM overlap by design and are reconciled in DP-241, never summed.", { x: LM + 0.3, y: 6.05, w: CW - 0.6, h: 0.65, fontSize: 12, color: C.background1, valign: "middle" });
}
{
  const s = content("From a published metric back to its meaning, in four hops", "2 Management overview",
    "This is the trace that makes the whole thing auditable. Start at the top right: a metric someone sees on a dashboard, say Net New Assets by channel. The semantic model defines that metric once and points to the product measure it comes from. The product measure has a formula that names the taxonomy attributes it reads. Each attribute belongs to a Data Domain that masters it and an owner role that answers for it. Four hops, every one of them recorded and validated at build time.\n\n" +
    "Two more things sit underneath. Every product has a logical data model: the foundational ones are normalized entity models that publish the shared dimensions, Household, Client Account, Advisor, Offering and Channel among them; the consumer ones are star schemas that reuse those dimensions, so a household means the same thing in every product. And the semantic layer publishes the products to BI tools, Excel and AI assistants through subject-area models, each metric defined once and each certified metric defined only in the model that owns it.\n\n" +
    "For an AI assistant this is the difference between a plausible answer and a correct one: the assistant resolves the question to a named metric with a known definition, not to a guess over raw tables.");
  const hops = [
    ["Metric", "Net New Assets, by channel", "Semantic model SM-20 Client Assets & Flows: defined once, with the grain, the filters and the access rule", C.accent4],
    ["Measure", "DP-008 Net New Assets", "Product measure with a formula: signed sum of current client-asset flows under the flow treatment rules, by trade date", C.accent3],
    ["Attributes", "06 Transaction: Flow Scope, Flow Direction, Reporting Currency Amount, Trade Date; 06 Measure Definition: Rollover Treatment; 06 Account Channel Assignment (from 15 Program Enrollment)", "Every attribute the formula reads is among the product's inputs; the build fails otherwise", C.accent2],
    ["Data Domain", "06 Client Assets, Flows & Channel Attribution", "Mastering domain and owner role, with the definition and the decision that set it", C.accent1],
  ];
  hops.forEach((h, i) => {
    const y = TOP + i * 1.25;
    rect(s, LM, y, 1.6, 1.05, h[3]);
    text(s, h[0], { x: LM + 0.15, y, w: 1.4, h: 1.05, fontSize: 14, bold: true, color: C.background1, valign: "middle" });
    rrect(s, LM + 1.7, y, 5.4, 1.05, C.background2);
    const two = i === 2;
    text(s, h[1], { x: LM + 1.9, y: y + 0.08, w: 5.0, h: two ? 0.5 : 0.4, fontSize: two ? 11 : 12.5, bold: true, color: C.text2 });
    text(s, h[2], { x: LM + 1.9, y: y + (two ? 0.58 : 0.5), w: 5.0, h: two ? 0.47 : 0.55, fontSize: 10.5, color: C.text1 });
    if (i < 3) s.addShape(pres.ShapeType.downArrow, { x: LM + 0.6, y: y + 1.05, w: 0.4, h: 0.2, fill: { color: C.accent6 }, line: { width: 0 }, objectName: "arrow" });
  });
  const rx = 8.0, rw = 4.73;
  rrect(s, rx, TOP, rw, 2.35, C.background2);
  text(s, "Logical data models", { x: rx + 0.2, y: TOP + 0.15, w: rw - 0.4, h: 0.35, fontSize: 14, bold: true, color: C.accent2 });
  text(s, "One per product. Foundational products are normalized entity models that publish the shared dimensions: Household, Client Account, Advisor, Offering and Program, Channel, Instrument, Calendar. Consumer products are star schemas that reuse them, so the same Household means the same thing in every product. Keys, links and connectivity are checked against the taxonomy at build.", { x: rx + 0.2, y: TOP + 0.55, w: rw - 0.4, h: 1.75, fontSize: 10.5, color: C.text1 });
  rrect(s, rx, TOP + 2.55, rw, 2.7, C.background2);
  text(s, "Semantic layer", { x: rx + 0.2, y: TOP + 2.7, w: rw - 0.4, h: 0.35, fontSize: 14, bold: true, color: C.accent4 });
  text(s, "Subject-area models publish the products to BI tools, Excel and AI assistants. Each metric is defined once. Each certified metric is defined only in the model that owns it and referenced everywhere else. Every model states which questions it cannot answer, and why, as registered gaps. Products that run workflows, filings and files are delivered directly and are not in the layer.", { x: rx + 0.2, y: TOP + 3.1, w: rw - 0.4, h: 2.1, fontSize: 10.5, color: C.text1 });
}
{
  const s = content("Three ways the business uses it: analytical, workflow, evidence", "2 Management overview",
    "People hear 'data product' and picture a dashboard. That is one of three uses, and often the smallest.\n\n" +
    "Analytical use is the semantic layer: dashboards, Excel and AI assistants asking questions in plain English, all resolving to the same named metrics. Access follows the classification on the data, so leadership sees every household, an advisor sees the households they cover, and finance sees totals with no names.\n\n" +
    "Workflow use is operational products delivered into the tools people already work in: the advisor's worklist in the CRM, the rebalancer's trade proposals, the billing run, the supervisor's review queue. The product decides what needs action; the workflow tool is where the action is taken. No one re-keys a number.\n\n" +
    "Evidence use is regulatory and control products: the Reg BI file for every recommendation, the rollover documentation under PTE 2020-02, the daily customer reserve computation, fee billing against the custody rule. They exist so an examiner, a board or an auditor can be shown the control working, from the same data the business runs on.\n\n" +
    "All three read the same products. That is the point: there is no separate compliance copy of the data.");
  const uses = [
    ["Analytical", "Decide and steer", "Dashboards, Excel and AI assistants read the semantic model. Questions resolve to named metrics with known definitions. Access follows the data's classification: leadership sees every household; an advisor sees the households they cover; finance sees totals with no names.",
      ["DP-490 Client Assets & Flows Executive Scorecard", "DP-320 Household 360", "DP-333 Advice Funnel & Conversion", "DP-467 Rollover Capture"], C.accent4],
    ["Workflow", "Act today", "Operational products are delivered into the tools people already work in: CRM, the rebalancer, the billing engine, the supervision platform. The product decides what needs action and carries the facts; the tool is where the action is taken.",
      ["DP-340 Advisor Client Action Worklist", "DP-336 Advice Review Cadence & Plan Currency", "DP-344 Trade Proposals, Cash Raises & Pre-Trade Exceptions", "DP-398 Principal Review Queue & Supervisory Approvals"], C.accent5],
    ["Evidence", "Prove the control", "Regulatory and control products show a rule was followed, from the same data the business runs on. Examiners, boards and auditors see the control working, not a reconstruction.",
      ["DP-334 Plan Quality & Recommendation Evidence (Reg BI File)", "DP-335 Rollover Recommendations & PTE 2020-02 Evidence", "DP-346 Fee Billing Accuracy & Custody-Rule Evidence", "DP-445 Customer Reserve & Possession-and-Control Control Pack"], C.accent1],
  ];
  uses.forEach((u, i) => {
    const x = LM + i * 4.1, w = 3.9;
    rrect(s, x, TOP, w, 5.25, C.background2);
    rect(s, x, TOP, w, 1.0, u[4]);
    text(s, u[0], { x: x + 0.22, y: TOP + 0.1, w: w - 0.44, h: 0.5, fontSize: 20, bold: true, color: C.background1 });
    text(s, u[1], { x: x + 0.22, y: TOP + 0.58, w: w - 0.44, h: 0.35, fontSize: 12, italic: true, color: C.background1 });
    text(s, u[2], { x: x + 0.22, y: TOP + 1.15, w: w - 0.44, h: 2.0, fontSize: 11, color: C.text1 });
    text(s, "PRODUCTS, FOR EXAMPLE", { x: x + 0.22, y: TOP + 3.2, w: w - 0.44, h: 0.3, fontSize: 9, bold: true, color: C.accent6 });
    const items = u[3].map((b, k) => ({ text: b, options: { bullet: { indent: 10 }, breakLine: k < u[3].length - 1, paraSpaceAfter: 3 } }));
    s.addText(items, { x: x + 0.22, y: TOP + 3.5, w: w - 0.44, h: 1.65, fontSize: 10.5, color: C.text1, valign: "top", margin: 0, isTextBox: true, objectName: "examples" });
  });
}
{
  const s = content("Governance: who owns what, and what certified means", "2 Management overview",
    "Four roles. The product owner is accountable for the definition, the quality rules, service levels, access and the roadmap, and certifies each release. Domain data owners own the meaning and quality of the concepts the product consumes, and approve new uses of personal or licensed data. The Data Office keeps the catalog, the specification standard and the build, runs certification and arbitrates overlaps. Compliance and privacy review anything flagged as personal data, licensed or regulatory.\n\n" +
    "A product is certified when its owner signs that its quality rules pass and its service levels are met. The certified-number owners are the anchors; everyone else reads from them.\n\n" +
    "Change control is deliberately boring: edit the specification, rebuild, run the baseline check, log the material change as a decision. And the gap register is where anything the taxonomy cannot yet answer goes, with a priority, a decision owner and the products affected, so a limitation becomes a work item rather than a workaround.\n\n" +
    "For the head of distribution the ask is one thing: name the product owners for the products your function is the primary consumer of. Without a named owner, nothing gets certified.");
  const q = [
    ["Product owner", "Accountable for the product's definition, quality rules, service levels, access and roadmap. Certifies each release against its DQ rules.", C.accent1],
    ["Domain data owners", "Own the meaning and quality of the concepts the product consumes. Approve new uses of personal or licensed data from their domain.", C.accent2],
    ["Data Office", "Maintains the catalog, the specification standard and the build. Runs product certification. Arbitrates where two products overlap.", C.accent3],
    ["Compliance and privacy", "Review products flagged personal data or licensed, and every Regulatory & Control product.", C.accent4],
  ];
  q.forEach((r, i) => {
    const col = i % 2, row = Math.floor(i / 2);
    const x = LM + col * 3.95, y = TOP + row * 1.75, w = 3.8;
    rrect(s, x, y, w, 1.6, C.background2);
    text(s, r[0], { x: x + 0.2, y: y + 0.15, w: w - 0.4, h: 0.35, fontSize: 14, bold: true, color: r[2] });
    text(s, r[1], { x: x + 0.2, y: y + 0.55, w: w - 0.4, h: 1.0, fontSize: 11, color: C.text1 });
  });
  const rx = 8.6, rw = 4.13;
  rrect(s, rx, TOP, rw, 1.6, C.text2);
  text(s, "Certification", { x: rx + 0.2, y: TOP + 0.12, w: rw - 0.4, h: 0.35, fontSize: 14, bold: true, color: C.background1 });
  text(s, "A product is Certified when its owner signs that its DQ rules pass and its service levels are met. The certified-number owners are the anchors every other product reads from.", { x: rx + 0.2, y: TOP + 0.5, w: rw - 0.4, h: 1.05, fontSize: 11, color: C.background2 });
  rrect(s, rx, TOP + 1.75, rw, 1.6, C.text2);
  text(s, "Change control", { x: rx + 0.2, y: TOP + 1.87, w: rw - 0.4, h: 0.35, fontSize: 14, bold: true, color: C.background1 });
  text(s, "1. Edit the specification.  2. Rebuild; run the baseline check.  3. Log any material change (new product, changed grain or measure, new personal data) as a numbered decision.", { x: rx + 0.2, y: TOP + 2.25, w: rw - 0.4, h: 1.05, fontSize: 11, color: C.background2 });
  rrect(s, LM, TOP + 3.6, CW, 1.65, C.background2);
  text(s, "The gap register", { x: LM + 0.25, y: TOP + 3.72, w: 4, h: 0.35, fontSize: 14, bold: true, color: C.accent5 });
  text(s, "Every limitation found while specifying and modeling products is one issue: a category, a change type, a priority, a decision owner and the products affected. Missing dates and statuses, missing links between objects, missing objects for analytical content. A question the model cannot answer becomes a named change to a named domain, never a workaround inside one team's report. Triage views by domain, product and decision owner are the agenda for the workshops.",
    { x: LM + 0.25, y: TOP + 4.1, w: CW - 0.5, h: 1.1, fontSize: 11.5, color: C.text1 });
}

// ============================================================================================================ 3. WEALTH MANAGER
pres.addSection({ title: "3 The wealth manager" });
{
  const s = pres.addSlide({ masterName: "DIVIDER", sectionTitle: "3 The wealth manager" });
  s.addText("PART 3", { placeholder: "kicker" });
  s.addText("The wealth manager", { placeholder: "title" });
  s.addText("A reference model built for a direct wealth manager: the same rules and layers, with the household, the account, the advice relationship and the brokerage book of record at its center.", { placeholder: "body" });
  s.addNotes("Part three. Parts one and two apply to any firm that runs this model. Now the wealth manager specifically. The reference model was built for a direct wealth manager, and this part shows where your business lives in it: the firm it assumes, the four things it is built around, the Client & Advice domains, the books of record and certified numbers, the advice domain, and the products and semantic models on top.");
}
{
  const s = content("The target firm: direct, advice-led, own funds, US only", "3 The wealth manager",
    "The reference firm is hypothetical but deliberately shaped. It serves investors directly, gives advice digitally and through people, manufactures the funds it recommends, recordkeeps workplace plans, and sells through intermediaries only as a secondary channel. It is US only.\n\n" +
    "Eight business lines, and each is a tailoring lever. Drop personal trust if you do not run a trust company. Thicken the intermediary channel if your advisor business is large. Every lever is a named change to a register, not a rebuild.\n\n" +
    "The legal entities and operating assumptions matter because they decide which books of record exist: a self-clearing broker-dealer means the firm keeps the brokerage book of record itself. If you clear through someone else, that book becomes oversight data received from the provider, and the specifications say how each product changes under that model.");
  const lines = [
    ["DB", "Direct brokerage and self-directed", "Brokerage accounts, client orders, cash sweep, margin, fully paid lending", C.accent5],
    ["DA", "Digital advice", "Algorithmic advice at scale, goals-based planning, digital onboarding, Rule 3a-4 programs", C.accent1],
    ["HA", "Human and hybrid advice", "Financial plans, advisor relationships, ongoing advice fees, household-level management, tax-aware strategies", C.accent1],
    ["PF", "Proprietary funds and ETFs", "Own mutual funds, ETFs and CITs; in-house and sub-advised management; the fund complex", C.accent2],
    ["WR", "Workplace retirement recordkeeping", "DC plan recordkeeping, participant services, sponsor relationships, rollover capture into the direct business", C.accent3],
    ["IA", "Institutional advisory", "OCIO and institutional advice; mandates in own funds and separate accounts", C.accent6],
    ["IC", "Intermediary channel", "Own funds, ETFs and models through third-party advisors and platforms; secondary, kept thin", C.accent6],
    ["TR", "Personal trust services (optional)", "Trust and estate administration through a trust company", C.accent6],
  ];
  lines.forEach((l, i) => {
    const col = i % 2, row = Math.floor(i / 2);
    const x = LM + col * 4.15, y = TOP + row * 1.1, w = 4.0;
    rrect(s, x, y, w, 0.98, C.background2);
    rect(s, x, y, 0.75, 0.98, l[3]);
    text(s, l[0], { x, y, w: 0.75, h: 0.98, fontSize: 16, bold: true, color: C.background1, align: "center", valign: "middle" });
    text(s, l[1], { x: x + 0.9, y: y + 0.1, w: w - 1.05, h: 0.32, fontSize: 12, bold: true, color: C.text2 });
    text(s, l[2], { x: x + 0.9, y: y + 0.42, w: w - 1.05, h: 0.55, fontSize: 9.5, color: C.text1 });
  });
  const rx = 9.1, rw = 3.63;
  rrect(s, rx, TOP, rw, 4.35, C.text2);
  text(s, "REFERENCE DEFAULTS", { x: rx + 0.2, y: TOP + 0.18, w: rw - 0.4, h: 0.3, fontSize: 10, bold: true, color: C.accent4 });
  const defs = ["Parent; an RIA; a self-clearing broker-dealer; fund adviser and trusts; transfer agent; recordkeeper; trust company (optional). No bank charter.",
    "Advice, clearing, custody of client assets, transfer agency and recordkeeping in house; part of the active range sub-advised.",
    "Out of scope: private markets manufacturing, annuities, a bank balance sheet, RIA custody for third-party advisors, EU and UK distribution.",
    "Every assumption is a tailoring lever: an outsourced function keeps its products as oversight data received from the provider."];
  const items = defs.map((d, k) => ({ text: d, options: { bullet: { indent: 10 }, breakLine: k < defs.length - 1, paraSpaceAfter: 6 } }));
  s.addText(items, { x: rx + 0.2, y: TOP + 0.55, w: rw - 0.4, h: 3.7, fontSize: 10.5, color: C.background2, valign: "top", margin: 0, isTextBox: true, objectName: "defaults" });
}
{
  const s = content("Built around four things", "3 The wealth manager",
    "The model is built around four things, and everything in part four follows from them. The client household: the party master is the client, with members, authorized agents, trusted contacts and the versioned investor profile. The account: the brokerage and advisory account, with its registration types, features, agreements, beneficiaries and program enrollment. The advice relationship: goals, plans, recommendations and the best-interest evidence behind each one, as data in its own domain. And the brokerage book of record: what each client account owns, with tax lots, cost basis, cash and sweep, separate from the fund book.\n\n" +
    "Around them sit eight design rules, each a numbered decision with a rationale and a tailoring lever. Managed accounts and client orders are their own domains, distinct from fund portfolio management and the fund trading desk. Fees are an operational domain. Retail conduct is the compliance core. The intermediary and institutional business is a channel, kept thin by default. And the certified numbers are the wealth manager's: Client Assets as the headline, Firm AUM as the manufacturing number, reconciled and never summed.\n\n" +
    "If your firm differs on any of these, the lever is named: thicken the intermediary channel, drop trust, add a bank balance sheet. None of them is a rebuild.");
  const anchors = [
    ["The client household", "02 Client & Household", "The party master is the client: individuals, joint owners, households as parties, entities, authorized agents, trusted contacts, and the versioned investor profile that Reg BI and the Advisers Act require.", C.accent1],
    ["The account", "15 Account", "The brokerage and advisory account: registration types (IRA, Roth, 529, UTMA, trust, entity), features (margin, options, sweep), agreements, beneficiaries, program enrollment, cost-basis election.", C.accent2],
    ["The advice relationship", "45 Financial Planning & Advice", "Engagements, goals, plans and versions, recommendations with rationale and alternatives, best-interest evidence, rollover analyses and PTE 2020-02 documentation.", C.accent3],
    ["The brokerage book of record", "49 Clearing, Settlement & Client Asset Custody", "What each client account owns: securities, tax lots and cost basis, cash and sweep, pending activity; Rule 15c3-3 custody. Distinct from the fund book (18) and the shareholder register (06).", C.accent5],
  ];
  anchors.forEach((a, i) => {
    const x = LM + i * 3.06, w = 2.9;
    rrect(s, x, TOP, w, 2.95, C.background2);
    rect(s, x, TOP, w, 0.7, a[3]);
    text(s, a[0], { x: x + 0.18, y: TOP, w: w - 0.36, h: 0.7, fontSize: 14, bold: true, color: C.background1, valign: "middle" });
    text(s, a[1], { x: x + 0.18, y: TOP + 0.82, w: w - 0.36, h: 0.5, fontSize: 10, bold: true, color: a[3] });
    text(s, a[2], { x: x + 0.18, y: TOP + 1.35, w: w - 0.36, h: 1.55, fontSize: 10.5, color: C.text1 });
  });
  rrect(s, LM, TOP + 3.1, CW, 2.15, C.text2);
  text(s, "DESIGN RULES AROUND THEM, EACH A NUMBERED DECISION WITH A TAILORING LEVER", { x: LM + 0.25, y: TOP + 3.22, w: CW - 0.5, h: 0.3, fontSize: 10, bold: true, color: C.accent4 });
  const rules = [
    "Managed accounts (46) and client orders (48) are their own domains, distinct from fund portfolio management (24) and the fund trading desk (25)",
    "Fees and billing are an operational domain (47); revenue recognition and profitability stay in 10",
    "Retail conduct and supervision (08) is the compliance core: Reg BI, Form CRS, FINRA 3110, senior investor protection",
    "The intermediary and institutional business is a channel (05), kept thin by default; the lever restores depth",
    "Client Assets is the headline certified number and Firm AUM the manufacturing number: reconciled, never summed",
    "US only; personal data tiered on every attribute; every conduct object cites the rule by number",
  ];
  rules.forEach((r, i) => {
    const col = i % 2, row = Math.floor(i / 2);
    text(s, r, { x: LM + 0.25 + col * 6.05, y: TOP + 3.6 + row * 0.52, w: 5.8, h: 0.5, fontSize: 10.5, color: C.background1, bullet: { indent: 10 } });
  });
}
{
  const s = content("Client & Advice: the twelve Data Domains your business runs on", "3 The wealth manager",
    "These are the twelve domains of the Client & Advice area: the client and the account at the center, planning and advice and managed portfolios beside them, then fees, the advisor organization, marketing, service, conduct, the product and offering reference, product development and trust.\n\n" +
    "I want to point at three boundaries, because they are where arguments usually start. The investor profile is on the client in 02; what one account is for is on the account in 15; what the client wants to achieve is a goal in 45. Three records, three owners, and a recommendation references the profile version it relied on rather than copying it. Advice programs and service tiers are offerings in 01; enrolling an account in one is a 15 fact; the recommendation that led to it is 45. And fees are an operational domain, 47, with the revenue view staying in 10.\n\n" +
    "If your data team takes one thing from this slide, it is those boundary rules. They are the difference between a household view that reconciles and one that does not.");
  const doms = [
    ["02", "Client & Household", "Party master as the client: individuals, households, entities, agents, trusted contacts, the versioned investor profile, KYC, consent"],
    ["15", "Account", "Brokerage and advisory account: registration types, features, agreements, beneficiaries, program enrollment, cost-basis election"],
    ["45", "Financial Planning & Advice", "Engagements, goals, plans and versions, assumptions, scenarios, recommendations, best-interest evidence, rollover analyses"],
    ["46", "Managed Portfolios & Rebalancing", "Model assignment per account and household, targets, drift, rebalancing, tax-loss harvesting, trade proposals"],
    ["47", "Pricing, Fees & Billing", "Fee schedules, householding and breakpoints, calculation runs, debits, waivers, custody-rule conditions"],
    ["03", "Advisor Organization, Coverage & Supervision", "Own advisors and representatives, teams, branches and OSJs, client assignment and capacity, incentive plans"],
    ["01", "Investment Product & Service Offering", "Own funds, ETFs, CITs and share classes; advice programs, service tiers, the brokerage platform offering"],
    ["04", "Marketing, Digital & Client Engagement", "Acquisition funnel, onboarding events, campaigns, digital identity and app events, personalization, NPS"],
    ["13", "Client Service & Communications", "Interactions and cases across channels, statements, confirmations, tax documents, e-delivery, escheatment"],
    ["08", "Retail Conduct & Supervision", "Reg BI and Form CRS, suitability surveillance, FINRA 3110 supervision, complaints, senior investor protection, licensing"],
    ["36", "Product Development & Lifecycle", "Advice-service and platform-feature development, product reviews and change"],
    ["51", "Trust & Estate Services", "Trust instruments and roles, discretionary distributions, trust accounting, estate settlement (optional)"],
  ];
  doms.forEach((d, i) => {
    const col = i % 3, row = Math.floor(i / 3);
    const x = LM + col * 4.1, y = TOP + row * 1.3, w = 3.9;
    rrect(s, x, y, w, 1.22, C.background2);
    text(s, d[0], { x: x + 0.15, y: y + 0.1, w: 0.5, h: 0.35, fontSize: 14, bold: true, color: C.accent1 });
    text(s, d[1], { x: x + 0.6, y: y + 0.1, w: w - 0.75, h: 0.5, fontSize: 11, bold: true, color: C.text2 });
    text(s, d[2], { x: x + 0.15, y: y + 0.6, w: w - 0.3, h: 0.6, fontSize: 9.5, color: C.text1 });
  });
}
{
  const s = content("Three books of record, and the certified numbers that sit on them", "3 The wealth manager",
    "A wealth manager that clears its own trades keeps three books of record, and the taxonomy names them distinctly so a holding is never confused with a position. The fund book in 18 holds what the funds own. The brokerage book in 49 holds what each client account owns, with tax lots, cost basis, cash and sweep. The fund shareholder position in 06 holds who owns the funds: for brokerage accounts a view of the brokerage book, for directly registered accounts a view of the 29 transfer agency register.\n\n" +
    "The certified numbers follow. Client Assets, the headline, is the market value of every client account at the firm, by channel and holding type, built from the brokerage book and the register. Firm AUM, the manufacturing number, is own-fund net assets plus managed and institutional assets. They overlap by design: an own fund held in a client account is in both. So they are reconciled in one product and never summed. Net New Assets, Advised Assets, the household and client counts and personal rate of return round out the family.\n\n" +
    "The decision that matters for the head of distribution: Client Assets is the headline number. Firm AUM is what the fund business reports. If your firm defines the headline differently, the change is made in the owning product, once.");
  const books = [
    ["18", "Portfolio Holding", "Portfolio & Investment Book of Record", "What the funds and institutional portfolios own. Fund IBOR.", C.accent2],
    ["49", "Client Holding", "Clearing, Settlement & Client Asset Custody", "What each client account owns: securities, tax lots, cost basis, cash and sweep, pending activity. Rule 15c3-3 custody.", C.accent5],
    ["06", "Fund Shareholder Position", "Client Assets, Flows & Channel Attribution", "Who owns the funds: built from 49 Client Holding for brokerage accounts and the 29 register for directly registered accounts; intermediary look-through as delivered.", C.accent3],
  ];
  books.forEach((b, i) => {
    const x = LM + i * 2.75, w = 2.6;
    rrect(s, x, TOP, w, 2.1, C.background2);
    rect(s, x, TOP, w, 0.55, b[4]);
    text(s, b[0] + "   " + b[1], { x: x + 0.15, y: TOP, w: w - 0.3, h: 0.55, fontSize: 12.5, bold: true, color: C.background1, valign: "middle" });
    text(s, b[2], { x: x + 0.15, y: TOP + 0.65, w: w - 0.3, h: 0.5, fontSize: 10, bold: true, color: C.text2 });
    text(s, b[3], { x: x + 0.15, y: TOP + 1.1, w: w - 0.3, h: 1.0, fontSize: 9.5, color: C.text1 });
  });
  text(s, "Three names, three owners, three regulations. 'Holding', 'Position' and 'Custody' are logged term conflicts; the glossary says which is which.", { x: LM, y: TOP + 2.2, w: 8.1, h: 0.4, fontSize: 10, italic: true, color: C.accent6 });
  // Overlap diagram on the right
  const cx = 9.15;
  s.addShape(pres.ShapeType.ellipse, { x: cx + 0.2, y: TOP, w: 1.9, h: 1.9, fill: { color: C.accent1, transparency: 25 }, line: { width: 0 }, objectName: "client assets" });
  s.addShape(pres.ShapeType.ellipse, { x: cx + 1.35, y: TOP, w: 1.9, h: 1.9, fill: { color: C.accent2, transparency: 25 }, line: { width: 0 }, objectName: "firm aum" });
  text(s, "Client Assets", { x: cx + 0.1, y: TOP + 0.7, w: 1.3, h: 0.5, fontSize: 12, bold: true, color: C.background1, align: "center" });
  text(s, "Firm AUM", { x: cx + 2.05, y: TOP + 0.7, w: 1.3, h: 0.5, fontSize: 12, bold: true, color: C.background1, align: "center" });
  text(s, "own funds held by clients", { x: cx + 1.3, y: TOP + 0.8, w: 0.85, h: 0.6, fontSize: 8, bold: true, color: C.background1, align: "center" });
  text(s, "Reconciled in DP-241, never summed", { x: cx - 0.2, y: TOP + 2.0, w: 4.1, h: 0.35, fontSize: 10.5, bold: true, color: C.text2, align: "center" });
  const rows = [
    ["Certified family", "What it is", "Owner"],
    ["Client Assets (the headline)", "Market value of every client account at the firm, by channel and holding type", "Client & Channel Analytics (DP-008)"],
    ["Firm AUM", "Own funds at NAV plus managed-account and institutional assets at market value; the manufacturing number", "Fund Accounting (DP-241)"],
    ["Net New Assets; Advised Assets; Net Inter-Channel Transfers", "External flows under the flow treatment rules; fee-based assets; moves between channels (a firm-plan to firm-IRA rollover is a transfer, not NNA)", "Client & Channel Analytics (DP-008)"],
    ["Households, Clients, Funded Accounts", "Counts from the party and account masters, published as certified measures", "Client & Channel Analytics (DP-008)"],
    ["Personal Rate of Return", "Time- and money-weighted returns at account and household grain; planning never computes returns", "Performance Measurement (DP-145)"],
  ];
  table(s, rows, LM, TOP + 2.65, CW, [3.4, 6.3, 2.43], { fontSize: 9 });
}
{
  const s = content("Advice is data: what was recommended, and why", "3 The wealth manager",
    "This is the domain your business cannot run without. 45 Financial Planning & Advice masters the record of what a client is trying to achieve, the plan built to get there, what the firm recommended, and why that recommendation was in the client's best interest.\n\n" +
    "It is service data and regulated evidence at the same time. Regulation Best Interest requires the care obligation to be met and recorded for each recommendation to a retail customer; the Advisers Act fiduciary duty applies to every advisory relationship; a rollover from a workplace plan needs the DOL PTE 2020-02 documentation: the fiduciary acknowledgment, the services and conflicts disclosure, the reasons, the impartial conduct attestation.\n\n" +
    "The boundary rules are what keep it clean. Digital and human advice are one domain with delivery channel as an attribute, so a robo recommendation and an advisor's recommendation carry the same evidence. The recommendation is mastered once here; supervision in 08 reviews it and holds no rationale of its own; enrollment in 15 and model assignment in 46 implement it and reference it. And the domain never computes a return and never copies a profile.");
  const fam = [
    ["Advice Engagement", "Who is advised, in what scope, through which channel, by whom; advice reviews including the Rule 3a-4 annual contact"],
    ["Financial Goal", "Goal, priority, target, funding accounts, retirement-income and education detail, progress snapshots"],
    ["Client Financial Plan and versions", "Cash-flow and balance-sheet inputs, assumption sets, aggregated outside accounts, scenarios and projection results"],
    ["Recommendation", "Type, capacity (Reg BI or adviser), source (advisor or engine), the investor profile version relied on, client decision"],
    ["Rationale, alternatives, Best Interest Evidence", "Basis, profile factors considered, costs compared, the alternatives considered, evidence per obligation component"],
    ["Rollover Analysis and PTE 2020-02 Documentation", "Source plan, amount, options compared, fiduciary status basis, the three delivery dates and the impartial conduct attestation"],
  ];
  fam.forEach((f, i) => {
    const y = TOP + i * 0.78;
    rrect(s, LM, y, 7.6, 0.68, C.background2);
    text(s, f[0], { x: LM + 0.2, y: y + 0.06, w: 2.6, h: 0.58, fontSize: 11.5, bold: true, color: C.accent1, valign: "middle" });
    text(s, f[1], { x: LM + 2.85, y: y + 0.06, w: 4.6, h: 0.58, fontSize: 9.5, color: C.text1, valign: "middle" });
  });
  const rx = 8.5, rw = 4.23;
  rrect(s, rx, TOP, rw, 2.5, C.text2);
  text(s, "Three records, three owners", { x: rx + 0.2, y: TOP + 0.15, w: rw - 0.4, h: 0.35, fontSize: 13, bold: true, color: C.accent4 });
  const three = ["Investor Profile (02): who the client is", "Account Investment Profile (15): what one account is for", "Financial Goal (45): what the client wants to achieve", "A recommendation references the profile version it relied on; it never copies objective, risk tolerance or horizon"];
  s.addText(three.map((t, k) => ({ text: t, options: { bullet: { indent: 10 }, breakLine: k < three.length - 1, paraSpaceAfter: 4 } })), { x: rx + 0.2, y: TOP + 0.55, w: rw - 0.4, h: 1.9, fontSize: 10.5, color: C.background1, valign: "top", margin: 0, isTextBox: true, objectName: "three records" });
  rrect(s, rx, TOP + 2.65, rw, 2.0, C.background2);
  text(s, "Who else touches a recommendation", { x: rx + 0.2, y: TOP + 2.78, w: rw - 0.4, h: 0.35, fontSize: 13, bold: true, color: C.accent2 });
  const who = ["08 reviews it and holds alerts, never the rationale", "15 Program Enrollment and 46 Model Assignment implement it and reference it", "01 names the program, model or share class recommended", "16 holds the plan facts and the rollover transaction itself"];
  s.addText(who.map((t, k) => ({ text: t, options: { bullet: { indent: 10 }, breakLine: k < who.length - 1, paraSpaceAfter: 4 } })), { x: rx + 0.2, y: TOP + 3.15, w: rw - 0.4, h: 1.45, fontSize: 10.5, color: C.text1, valign: "top", margin: 0, isTextBox: true, objectName: "who" });
}
{
  const s = content("The wealth product set: foundations and Client & Advice", "3 The wealth manager",
    "The product set on the taxonomy. Fifty-eight foundational products conform the masters, the books of record and the certified numbers. The ones your business runs on are listed on the left: the party master with the household as its primary role, the account master, the offering reference, client holdings, client orders, money movement, the advice record, model assignments, fee schedules and billing runs, the certified Client Assets and Net New Assets product, client fee revenue, official returns with personal rate of return, service interactions, the client document record, and the recordkept plan and participant books.\n\n" +
    "On the right, a selection of the Client & Advice consumer products, grouped by the three uses. You will recognize the acceptance questions in them: which recommendations lack evidence, which rollovers lack documentation, which households are due a review, what tax-loss harvesting saved.\n\n" +
    "Scale, for the data team: 271 live products, each specified to attribute level; 55 business functions, from Financial Planning & Advice through Client & Channel Analytics; 22 semantic models, twelve of them wealth subject areas, from Client Assets & Flows to Manager Oversight.");
  const stats = [["58", "foundational products"], ["271", "live products, specified to attribute level"], ["55", "business functions"], ["22", "semantic models, twelve wealth subject areas"]];
  stats.forEach((st, i) => {
    const x = LM + i * 3.1;
    rrect(s, x, TOP, 2.95, 0.95, C.text2);
    text(s, st[0], { x: x + 0.2, y: TOP + 0.05, w: 1.0, h: 0.85, fontSize: 28, bold: true, color: C.background1, valign: "middle" });
    text(s, st[1], { x: x + 1.2, y: TOP + 0.1, w: 1.7, h: 0.75, fontSize: 10.5, color: C.background2, valign: "middle" });
  });
  const fx = LM, fw = 5.9, fy = TOP + 1.15;
  rrect(s, fx, fy, fw, 4.1, C.background2);
  text(s, "FOUNDATIONAL: masters, books of record, certified numbers", { x: fx + 0.2, y: fy + 0.12, w: fw - 0.4, h: 0.3, fontSize: 10, bold: true, color: C.accent2 });
  const fnd = ["DP-240 Client, Household & Party Master (the household as a party of type Household)", "DP-093 Account Master (brokerage and advisory account)", "DP-004 Product, Offering & Share Class Reference", "DP-300 Client Holdings, Lots & Cost Basis (brokerage book of record)", "DP-301 Client Orders & Executions   |   DP-302 Money Movement Transactions", "DP-303 Advice Plans & Recommendations", "DP-304 Managed Account Model Assignments", "DP-305 Fee Schedules & Billing Runs", "DP-006 Client Flow Transactions  >  DP-008 Client Assets & Net New Assets (certified)", "DP-012 Client Fee Revenue (certified)   |   DP-145 Official Returns (+ Personal Rate of Return)", "DP-381 Client Service Interactions & Requests   |   DP-382 Client Document & Delivery Record", "DP-094 Recordkept Plan & Participant Core   |   DP-430 Participant Balances & Ledger"];
  s.addText(fnd.map((t, k) => ({ text: t, options: { bullet: { indent: 10 }, breakLine: k < fnd.length - 1, paraSpaceAfter: 3 } })), { x: fx + 0.2, y: fy + 0.45, w: fw - 0.4, h: 3.6, fontSize: 9.5, color: C.text1, valign: "top", margin: 0, isTextBox: true, objectName: "foundational" });
  const groups = [
    ["Analytical", ["DP-320 Household 360", "DP-325 Service Tier Qualification & Client Segments", "DP-326 Client Base Movement & Attrition", "DP-333 Advice Funnel & Conversion", "DP-337 Goal Progress & Funded Status", "DP-338 Held-Away Assets & Consolidation Opportunity", "DP-342 Rebalance & Tax-Loss Harvest Effectiveness"], C.accent4],
    ["Workflow", ["DP-327 Account Opening & Good Order Pipeline", "DP-336 Advice Review Cadence & Plan Currency", "DP-340 Advisor Client Action Worklist", "DP-341 Drift & Rebalance Monitor", "DP-344 Trade Proposals, Cash Raises & Pre-Trade Exceptions", "DP-347 Fee Waivers, Adjustments & Billing Disputes"], C.accent5],
    ["Evidence", ["DP-322 Client Protection Flags & Senior Investor Register", "DP-323 Investor Profile Currency & Suitability Inputs", "DP-332 Advisory Program Enrollment & Rule 3a-4 Compliance", "DP-334 Plan Quality & Recommendation Evidence (Reg BI File)", "DP-335 Rollover Recommendations & PTE 2020-02 Evidence", "DP-346 Fee Billing Accuracy & Custody-Rule Evidence"], C.accent1],
  ];
  groups.forEach((g, i) => {
    const x = LM + 6.1 + i * 2.05, w = 1.95;
    rrect(s, x, fy, w, 4.1, C.background2);
    rect(s, x, fy, w, 0.4, g[2]);
    text(s, g[0], { x: x + 0.12, y: fy, w: w - 0.24, h: 0.4, fontSize: 11, bold: true, color: C.background1, valign: "middle" });
    text(s, g[1].join("\n\n"), { x: x + 0.12, y: fy + 0.5, w: w - 0.24, h: 3.55, fontSize: 8, color: C.text1 });
  });
}
{
  const s = content("Twelve subject-area models, tested by twelve questions", "3 The wealth manager",
    "The wealth business is published through twelve subject-area models, SM-20 to SM-31, alongside the ten shared and enterprise models for the investment book, fund operations and the corporate functions: twenty-two in all, with 44 certified metrics, each defined in the one model that owns it. The first, Client Assets & Flows, owns the certified client-asset family. Client & Household 360, Advice & Planning and Managed Portfolios serve the advice business. Client Economics owns fee revenue. Retail Conduct & Supervision gives the conduct evidence a home of its own. Offering, Product Range & Market and Manager Oversight & Due Diligence complete the set; question twelve resolves in the last of them.\n\n" +
    "On the right are the twelve acceptance questions. The model is accepted when each of them resolves, in the explorer, from a metric to a product measure to attributes to the mastering domain. They were chosen to cut across the business: assets and flows, advice evidence, managed accounts, execution quality, customer protection, cash holds, fee billing, personal returns, rollover capture, cost to serve and manager oversight.\n\n" +
    "Question three and question ten are the ones I will follow in part four, because they are the ones that sit on the head of distribution's desk: did the rollover come in, and is the file complete.");
  const sms = [["SM-20", "Client Assets & Flows (certified)"], ["SM-21", "Client & Household 360"], ["SM-22", "Advice & Planning"], ["SM-23", "Managed Portfolios"], ["SM-24", "Brokerage Activity & Execution Quality"], ["SM-25", "Client Service & Digital"], ["SM-26", "Workplace & Participants"], ["SM-27", "Intermediary & Institutional Channel"], ["SM-28", "Client Economics (certified fee revenue)"], ["SM-29", "Retail Conduct & Supervision"], ["SM-30", "Offering, Product Range & Market"], ["SM-31", "Manager Oversight & Due Diligence"]];
  rrect(s, LM, TOP, 4.6, 5.25, C.background2);
  text(s, "THE TWELVE WEALTH SUBJECT-AREA MODELS", { x: LM + 0.2, y: TOP + 0.15, w: 4.2, h: 0.3, fontSize: 10, bold: true, color: C.accent4 });
  sms.forEach((m, i) => {
    const y = TOP + 0.55 + i * 0.385;
    text(s, m[0], { x: LM + 0.2, y, w: 0.8, h: 0.38, fontSize: 10.5, bold: true, color: C.accent4, valign: "middle" });
    text(s, m[1], { x: LM + 1.0, y, w: 3.4, h: 0.38, fontSize: 10.5, color: C.text1, valign: "middle" });
  });
  const qs = ["Total client assets by channel and holding type, reconciled to Firm AUM", "Net new assets this quarter by channel, advisor and campaign", "Recommendations lacking best-interest evidence; rollovers lacking PTE 2020-02 documentation", "Managed accounts outside drift tolerance; what tax-loss harvesting saved", "Execution quality by venue and order type; orders corrected", "Today's customer reserve requirement; client securities out of possession and control", "Cash movements on hold for fraud or elder-exploitation review", "Advisory fee runs that failed reconciliation; accounts billed outside their schedule", "Each household's personal rate of return, and how it is computed", "Plan participants who separated this quarter and the share that rolled into the direct business", "Cost to serve each client segment; lifetime value by acquisition channel", "Sub-advisers under review and the last Section 15(c) renewal data"];
  const qx = LM + 4.8;
  text(s, "THE TWELVE ACCEPTANCE QUESTIONS", { x: qx, y: TOP, w: 7, h: 0.3, fontSize: 10, bold: true, color: C.accent1 });
  qs.forEach((q, i) => {
    const col = i % 2, row = Math.floor(i / 2);
    const x = qx + col * 3.7, y = TOP + 0.4 + row * 0.82, w = 3.55;
    const hot = i === 2 || i === 9;
    rrect(s, x, y, w, 0.72, hot ? C.accent1 : C.background2);
    text(s, String(i + 1), { x: x + 0.1, y: y + 0.05, w: 0.4, h: 0.62, fontSize: 14, bold: true, color: hot ? C.background1 : C.accent1, valign: "middle" });
    text(s, q, { x: x + 0.5, y: y + 0.05, w: w - 0.6, h: 0.62, fontSize: 9.5, color: hot ? C.background1 : C.text1, valign: "middle" });
  });
}

// ============================================================================================================ 4. USE CASE
pres.addSection({ title: "4 One question, end to end" });
{
  const s = pres.addSlide({ masterName: "DIVIDER", sectionTitle: "4 One question, end to end" });
  s.addText("PART 4", { placeholder: "kicker" });
  s.addText("One question, end to end: a rollover into advice", { placeholder: "title" });
  s.addText("From the recordkeeping system to the head of distribution's dashboard, the advisor's worklist and the examiner's file, with the same definition at every step.", { placeholder: "body" });
  LAYERS.forEach((l, i) => chip(s, LM + i * 2.45, 1.5, i + 1, l[0], l[1], { labelW: 2.2, fontSize: 12, labelColor: C.background1 }));
  s.addNotes("Part four. One question from your seat, followed down through every layer and back up. I will use the rail on the left of each slide to show where we are.");
}
{
  const s = content("The question, and the household we will follow", "4 One question, end to end",
    "The question comes from the head of distribution, and it sounds like one number: of the participants who left a plan we recordkeep this quarter, how much rolled into our advice business, and is every one of those rollover recommendations backed by the evidence the Department of Labor requires?\n\n" +
    "It is really four ideas, and each belongs to a different part of the business. A separated participant is a workplace fact in 16. A rollover recommendation and its documentation is advice in 45. The IRA it funded and its enrollment in an advice program is an account fact in 15. The money that moved, and whether it counts as new assets or a transfer between channels, is a certified measure in 06. The taxonomy gives each one definition and one owner, and everything I show next is those definitions carried through the layers without being rewritten.\n\n" +
    "We will follow one household. The Okafor household: Dana Okafor, fifty-eight, a participant in a 401(k) plan the firm recordkeeps, separating from her employer in April with a vested balance of six hundred and forty thousand dollars. Every figure is illustrative.");
  rrect(s, LM, TOP, CW, 1.15, C.text2);
  text(s, "\"Of the participants who left a plan we recordkeep this quarter, how much rolled into our advice business, and is every rollover recommendation backed by the evidence the DOL requires?\"", { x: LM + 0.3, y: TOP + 0.1, w: CW - 0.6, h: 0.95, fontSize: 16, bold: true, color: C.background1, valign: "middle" });
  const rows = [
    ["In the question", "Taxonomy object and attribute", "Data Domain that masters it"],
    ["\"participants who left a plan we recordkeep\"", "Participant Plan Membership; Separation Date; Distribution Request", "16 Retirement Plan Administration"],
    ["\"rolled into our advice business\"", "Account (IRA registration); Program Enrollment in an advice offering", "15 Account (offering defined in 01)"],
    ["\"how much\"", "Net Inter-Channel Transfers; Advised Assets; Net New Assets (certified measures)", "06 Client Assets, Flows & Channel Attribution"],
    ["\"rollover recommendation ... evidence the DOL requires\"", "Recommendation; Rollover Analysis; PTE 2020-02 Documentation (three delivery dates, impartial conduct attestation)", "45 Financial Planning & Advice"],
    ["\"the household\"", "Household (party of type Household); Household Membership", "02 Client & Household"],
  ];
  table(s, rows, LM, TOP + 1.35, 8.0, [2.7, 3.2, 2.1], { fontSize: 9.5 });
  const hx = 8.85, hw = 3.88;
  rrect(s, hx, TOP + 1.35, hw, 3.9, C.background2);
  text(s, "THE HOUSEHOLD WE FOLLOW (illustrative)", { x: hx + 0.2, y: TOP + 1.5, w: hw - 0.4, h: 0.3, fontSize: 10, bold: true, color: C.accent4 });
  text(s, "The Okafor household", { x: hx + 0.2, y: TOP + 1.85, w: hw - 0.4, h: 0.4, fontSize: 16, bold: true, color: C.text2 });
  const hh = [["Dana Okafor, 58", "Participant in a 401(k) plan the firm recordkeeps; household primary member"], ["Separated April 2026", "Vested balance $640,000; a Participant Retail Hand-Off opened on separation"], ["Recommendation", "Roll over to a firm IRA enrolled in the hybrid advice program; presented by phone, advisor of record assigned"], ["Rollover received May 2026", "$640,000 into the IRA; model assigned; first advisory fee billed in July"]];
  hh.forEach((r, i) => {
    const y = TOP + 2.35 + i * 0.72;
    text(s, r[0], { x: hx + 0.2, y, w: hw - 0.4, h: 0.28, fontSize: 11, bold: true, color: C.accent1 });
    text(s, r[1], { x: hx + 0.2, y: y + 0.27, w: hw - 0.4, h: 0.45, fontSize: 9.5, color: C.text1 });
  });
}
{
  const s = content("Step 1. Source systems: the target every source maps to", "4 One question, end to end",
    "The four ideas start in five different systems. Dana's separation and vested balance are in the recordkeeping system. Her household and advisor of record are in the CRM. The recommendation, the rollover analysis and the PTE documentation are in the planning tool, or in the advice engine if it was digital. The new IRA and its program enrollment are in account opening and the brokerage account master. The money and the holdings are in clearing and the books-and-records platform; the fee is in the billing engine. And the supervisor's review is in the surveillance platform.\n\n" +
    "None of these systems agrees on what to call her. The recordkeeper has a participant number; the CRM has its own record; the brokerage account master has an account number. The taxonomy settles three things before any data moves. What each field means: a rollover amount is a copy of the vested balance, and the PTE 2020-02 documentation is four named attributes, three delivery dates and the attestation, each citing the exemption. Who is right when sources disagree: 02 masters the party, so Dana is one PTY identifier across every system, and the participant who opens a direct account keeps the same identifier and gains client roles. And how to keep the trail: source identifiers travel with the resolved one.\n\n" +
    "One thing to say plainly: the systems here are named by type. Mapping them to your actual systems is the Phase D work, and each product's lineage is the list of attributes to map.");
  rail(s, [1, 2]);
  const x0 = LM + 2.85, w0 = CW - 2.85;
  const src = [
    ["Recordkeeping system", "Participant, plan membership, separation date, vested balance, distribution request", "16"],
    ["CRM and client master", "Household, members, advisor of record, contact and consent", "02, 03"],
    ["Planning tool and advice engine", "Recommendation, rationale, alternatives, rollover analysis, PTE 2020-02 documentation", "45"],
    ["Account opening and account master", "IRA registration, agreements, disclosures delivered, program enrollment", "15"],
    ["Clearing, books and billing engine", "Rollover contribution received, holdings and lots, cash; fee schedule and first billing run", "49, 50, 47"],
    ["Surveillance platform", "Principal review of the recommendation; supervisory review of the rollover", "08"],
  ];
  src.forEach((r, i) => {
    const y = TOP + i * 0.6;
    rrect(s, x0, y, 5.6, 0.52, C.background2);
    text(s, r[0], { x: x0 + 0.15, y, w: 2.3, h: 0.52, fontSize: 10.5, bold: true, color: C.text2, valign: "middle" });
    text(s, r[1], { x: x0 + 2.45, y, w: 2.6, h: 0.52, fontSize: 8.5, color: C.text1, valign: "middle" });
    text(s, r[2], { x: x0 + 5.05, y, w: 0.5, h: 0.52, fontSize: 10, bold: true, color: C.accent1, valign: "middle", align: "right" });
  });
  text(s, "Named by type. Mapping to the firm's actual systems is Phase D; each product's lineage is the list of attributes to map.", { x: x0, y: TOP + 3.65, w: 5.6, h: 0.5, fontSize: 9.5, italic: true, color: C.accent6 });
  const rx = x0 + 5.85, rw = w0 - 5.85;
  rrect(s, rx, TOP, rw, 5.25, C.text2);
  text(s, "WHAT THE TAXONOMY SETTLES FIRST", { x: rx + 0.2, y: TOP + 0.15, w: rw - 0.4, h: 0.3, fontSize: 9.5, bold: true, color: C.accent4 });
  const settle = [
    ["What each field means", "Rollover Amount is a derived copy of the 16 vested balance, row rule stated. The PTE 2020-02 documentation is four named attributes: three delivery dates (acknowledgment, services and conflicts disclosure, reasons) and the impartial conduct attestation, each citing the exemption."],
    ["Who is right when sources disagree", "02 masters the party. Dana is one PTY- identifier in every system; the participant who opens a direct account keeps it and gains client roles. The recordkeeper and the CRM do not get a vote each month."],
    ["How to keep the trail", "Source identifiers (participant number, CRM record, account number) travel alongside the resolved ID, with the feed and the load each record came from."],
  ];
  settle.forEach((r, i) => {
    const y = TOP + 0.55 + i * 1.55;
    text(s, r[0], { x: rx + 0.2, y, w: rw - 0.4, h: 0.35, fontSize: 12, bold: true, color: C.background1 });
    text(s, r[1], { x: rx + 0.2, y: y + 0.37, w: rw - 0.4, h: 1.15, fontSize: 10, color: C.background2 });
  });
}
{
  const s = content("Step 2. Foundational products: each core thing cleaned up once", "4 One question, end to end",
    "Foundational products clean up each core thing once, so nobody downstream does it again. Our question needs eight of them.\n\n" +
    "The party master gives the Okafor household one record and Dana one identifier with her participant and client roles. The recordkept plan products give the separation event, the balance and the hand-off record that starts the rollover. The advice record holds the recommendation with its rationale, the rollover analysis and the PTE documentation, and one of its quality rules says the three delivery dates and the attestation must be populated on every rollover analysis presented as an acknowledged fiduciary; a missing date fails the rule rather than hiding. The account master holds the IRA and its enrollment in the hybrid advice program. The brokerage book of record holds what the IRA now owns.\n\n" +
    "Then the money. The client flow product records the rollover contribution. The certified client-assets product applies the measure definitions, and here is the rule that matters most to this room: under the rollover treatment, a rollover from a plan the firm recordkeeps into a firm IRA is an inter-channel transfer, not net new assets. The firm's total did not grow; six hundred and forty thousand dollars moved from the workplace channel to the advice channel, and the advised-assets figure went up by that amount. That is decided once, in one product, and every report inherits it.");
  rail(s, 3);
  const x0 = LM + 2.85;
  const fp = [
    ["DP-240", "Client, Household & Party Master", "One Okafor household; Dana one PTY- with participant and client roles, effective-dated", C.accent2],
    ["DP-094 / DP-430", "Recordkept Plan & Participant Core; Participant Balances & Ledger", "Separation event, vested balance $640,000, the Participant Retail Hand-Off and the distribution request", C.accent2],
    ["DP-303", "Advice Plans & Recommendations", "Recommendation, rationale, alternatives; Rollover Analysis; PTE 2020-02 Documentation. DQ rule 4: three delivery dates and the attestation populated on every presented analysis", C.accent2],
    ["DP-093", "Account Master", "The IRA (registration type IRA), agreements and disclosures delivered, Program Enrollment in the hybrid advice offering", C.accent2],
    ["DP-300", "Client Holdings, Lots & Cost Basis", "What the IRA owns after the model is assigned; cash during transit", C.accent2],
    ["DP-006", "Client Flow Transactions", "The rollover contribution: Flow Scope Inter-Channel Transfer, from workplace to advised, same owner", C.accent2],
    ["DP-008", "Client Assets & Net New Assets (certified)", "Net Inter-Channel Transfers +$640,000 into the advice channel; Advised Assets +$640,000; Net New Assets at firm total unchanged", C.accent4],
  ];
  fp.forEach((r, i) => {
    const y = TOP + i * 0.75;
    rrect(s, x0, y, 6.6, 0.66, C.background2);
    rect(s, x0, y, 0.1, 0.66, r[3]);
    text(s, r[0], { x: x0 + 0.22, y, w: 1.25, h: 0.66, fontSize: 10, bold: true, color: r[3], valign: "middle" });
    text(s, r[1], { x: x0 + 1.5, y: y + 0.04, w: 2.2, h: 0.6, fontSize: 9.5, bold: true, color: C.text2, valign: "middle" });
    text(s, r[2], { x: x0 + 3.75, y: y + 0.03, w: 2.75, h: 0.62, fontSize: 8.5, color: C.text1, valign: "middle" });
  });
  const rx = x0 + 6.85, rw = CW - 2.85 - 6.85;
  rrect(s, rx, TOP, rw, 5.25, C.text2);
  text(s, "THE DECIDING RULE", { x: rx + 0.2, y: TOP + 0.15, w: rw - 0.4, h: 0.3, fontSize: 9.5, bold: true, color: C.accent4 });
  text(s, "Rollover Treatment (06 Flow Treatment Rule, read by DP-008):", { x: rx + 0.2, y: TOP + 0.5, w: rw - 0.4, h: 0.5, fontSize: 11, bold: true, color: C.background1 });
  text(s, "A rollover from a plan the firm recordkeeps into a firm IRA is an inter-channel transfer. It moves assets from the workplace channel to the advice channel and raises Advised Assets. It is not Net New Assets at the firm total.", { x: rx + 0.2, y: TOP + 1.05, w: rw - 0.4, h: 1.5, fontSize: 10.5, color: C.background2 });
  text(s, "A rollover from an external plan is Net New Assets.", { x: rx + 0.2, y: TOP + 2.6, w: rw - 0.4, h: 0.5, fontSize: 10.5, color: C.background2 });
  text(s, "Decided once, in one product, under one owner. Every consumer product, dashboard and AI answer inherits it; none may recalculate it.", { x: rx + 0.2, y: TOP + 3.3, w: rw - 0.4, h: 1.2, fontSize: 10.5, bold: true, color: C.background1 });
  text(s, "Daily flash, then the monthly locked snapshot; changes after lock arrive only as an approved restatement.", { x: rx + 0.2, y: TOP + 4.5, w: rw - 0.4, h: 0.6, fontSize: 9.5, italic: true, color: C.background2 });
}
{
  const s = content("Step 3. Consumer products: where the four ideas first meet", "4 One question, end to end",
    "Consumer products are shaped around one team's decisions and built from the foundational ones. This is where the four ideas first meet, and each product uses them for a different job.\n\n" +
    "The rollover evidence product belongs to workplace services. It joins every rollover recommendation to its analysis, the options compared, the PTE documentation and the receiving IRA, and defines one flag: the documentation gap, set when the analysis is missing, any of the three delivery dates is missing or late, or the attestation or the reasons are absent. Rollover Capture belongs to the same team and answers the other half of the question: how many participants separated, how much rolled out, and what share landed in the direct business. Those are operational funnel values, never labeled net new assets; the certified inter-channel transfer is read from the client-assets product and shown beside them, with the residual between the two published as its own measure rather than hidden. Household 360 puts the Okafor picture in front of the advisor: members, accounts, advised assets, personal return, protection flags, the open recommendation.\n\n" +
    "Then the workflow products. The advisor worklist takes the documentation gap and the review due date and puts them in the CRM as actions. The principal review queue puts the recommendation in front of the supervisor. The advice review cadence schedules the Rule 3a-4 annual contact that the program now owes Dana.\n\n" +
    "Notice what none of them does. None recalculates the transfer amount, none decides what 'documented' means, none copies the profile. They take all of it as given. So the workplace report, the advisor's screen and the supervisor's queue cannot disagree.");
  rail(s, 4);
  const x0 = LM + 2.85, w0 = CW - 2.85;
  const cp = [
    ["DP-335", "Rollover Recommendations & PTE 2020-02 Evidence", "Evidence", "Every rollover recommendation with its analysis, options compared, fiduciary status basis, the three PTE delivery dates, the attestation and the receiving IRA. Defines PTE Documentation Gap Flag, once. Supplies the population of the 08 annual retrospective review.", C.accent1],
    ["DP-467", "Rollover Capture", "Analytical", "Separations, Rollovers Into the Direct Business and Direct Business Rollover Share, by plan and receiving line: operational funnel values. Reads Net Inter-Channel Transfers from DP-008 and publishes the residual, never a second certified number.", C.accent4],
    ["DP-320", "Household 360", "Analytical", "The Okafor household for the advisor: members and roles, accounts and enrollments, Client Assets and Advised Assets (certified), Personal Rate of Return by reference, protection flags, open recommendations.", C.accent4],
    ["DP-340", "Advisor Client Action Worklist", "Workflow", "Puts the documentation gap, the review due and the profile confirmation in the CRM as dated actions for the advisor of record.", C.accent5],
    ["DP-398", "Principal Review Queue & Supervisory Approvals", "Workflow", "The recommendation and the rollover in the supervisor's queue under FINRA Rule 3110; the decision is written back to 08, not to 45.", C.accent5],
    ["DP-336", "Advice Review Cadence & Plan Currency", "Workflow", "Schedules the Rule 3a-4 annual contact the hybrid program owes Dana, and flags the plan if its assumptions go stale.", C.accent5],
  ];
  cp.forEach((r, i) => {
    const col = i % 2, row = Math.floor(i / 2);
    const x = x0 + col * (w0 / 2 + 0.05), y = TOP + row * 1.45, w = w0 / 2 - 0.1;
    rrect(s, x, y, w, 1.32, C.background2);
    text(s, r[0], { x: x + 0.15, y: y + 0.08, w: 0.85, h: 0.3, fontSize: 10.5, bold: true, color: r[4] });
    text(s, r[2], { x: x + w - 1.0, y: y + 0.1, w: 0.85, h: 0.28, fontSize: 9, bold: true, color: r[4], align: "right" });
    text(s, r[1], { x: x + 0.15, y: y + 0.36, w: w - 0.3, h: 0.3, fontSize: 10.5, bold: true, color: C.text2 });
    text(s, r[3], { x: x + 0.15, y: y + 0.66, w: w - 0.3, h: 0.66, fontSize: 8.5, color: C.text1 });
  });
  rrect(s, x0, TOP + 4.45, w0, 0.8, C.text2);
  text(s, "None of them recalculates the transfer, decides what 'documented' means, or copies the investor profile. They assemble; they never redefine. So the workplace report, the advisor's screen and the supervisor's queue cannot disagree, because none of them owns the number.", { x: x0 + 0.25, y: TOP + 4.45, w: w0 - 0.5, h: 0.8, fontSize: 11, color: C.background1, valign: "middle" });
}
{
  const s = content("Step 4. Semantic model: one definition, rules for adding up", "4 One question, end to end",
    "Products answer questions about one household or one team. The head of distribution's question is across all participants and all households, so the numbers have to add up correctly, and that is the semantic model's job. Three models are involved.\n\n" +
    "Workplace & Participants publishes Separations, Rollovers Into the Direct Business and the Direct Business Rollover Share, with Rollover Capture as its source. Advice & Planning publishes Rollovers Without PTE 2020-02 Documentation and the gap rate; supervision and advice leadership see the rows, everyone else sees aggregates by channel, offering and month with small cells suppressed. Client Assets & Flows owns the certified metrics, Net Inter-Channel Transfers and Advised Assets, defined once there and referenced by the other two.\n\n" +
    "Then the rules that stop a number being added wrongly. Only locked monthly rows at the channel grain are read, so the same money cannot be counted in two channels. Transfers are not summed across months into a stock figure. The rollover share is lined up by participant, not joined row to row, or a participant with two distributions would be double counted. And at the firm total, inter-channel transfers net to zero by definition, so a dashboard that filters to the total and sees nothing is correct, not broken.\n\n" +
    "Access follows the classification: leadership sees every household; the advisor sees the households they cover; finance and marketing see totals with no names.");
  rail(s, 5);
  const x0 = LM + 2.85, w0 = CW - 2.85;
  const sm = [
    ["SM-26", "Workplace & Participants", "Separations; Rollovers Into the Direct Business; Direct Business Rollover Share", "Source: DP-467. Net Inter-Channel Transfers referenced from SM-20; the residual between the two is published as its own measure.", C.accent3],
    ["SM-22", "Advice & Planning", "Rollovers Without PTE 2020-02 Documentation; PTE Documentation Gap Rate %", "Source: DP-335 (the flag is defined there, once) and DP-303. Rows for supervision and advice leadership; aggregates with cells under 10 suppressed for everyone else.", C.accent3],
    ["SM-20", "Client Assets & Flows", "Net Inter-Channel Transfers; Advised Assets; Net New Assets (certified)", "Source: DP-008. Defined once here; every other model references them.", C.accent4],
  ];
  sm.forEach((r, i) => {
    const y = TOP + i * 1.2;
    rrect(s, x0, y, 5.3, 1.08, C.background2);
    text(s, r[0], { x: x0 + 0.15, y: y + 0.08, w: 0.8, h: 0.3, fontSize: 11, bold: true, color: r[4] });
    text(s, r[1], { x: x0 + 0.95, y: y + 0.08, w: 4.2, h: 0.3, fontSize: 11, bold: true, color: C.text2 });
    text(s, r[2], { x: x0 + 0.15, y: y + 0.4, w: 5.0, h: 0.35, fontSize: 9.5, bold: true, color: C.text1 });
    text(s, r[3], { x: x0 + 0.15, y: y + 0.72, w: 5.0, h: 0.35, fontSize: 8.5, color: C.accent6 });
  });
  rrect(s, x0, TOP + 3.7, 5.3, 1.55, C.text2);
  text(s, "Access follows the classification", { x: x0 + 0.2, y: TOP + 3.8, w: 4.9, h: 0.3, fontSize: 11, bold: true, color: C.accent4 });
  text(s, "Confidential - Personal Data. Leadership sees every household. An advisor sees the households they cover. Finance and marketing see totals by channel and segment, with no names. An AI assistant inherits the same scope as the person asking.", { x: x0 + 0.2, y: TOP + 4.12, w: 4.9, h: 1.1, fontSize: 9.5, color: C.background2 });
  const rx = x0 + 5.55, rw = w0 - 5.55;
  text(s, "RULES THAT STOP THE NUMBER BEING ADDED WRONGLY", { x: rx, y: TOP, w: rw, h: 0.3, fontSize: 9.5, bold: true, color: C.accent1 });
  const rules = [
    ["Locked, monthly, channel-grain rows only", "DP-008 holds the same money at several grains and in preliminary and locked versions. Fixed filters stop a dashboard counting a transfer in two channels."],
    ["Transfers are flows, not stocks", "A transfer is never summed across months into an asset figure; Advised Assets is taken at the last locked month-end."],
    ["Line up by participant, not row to row", "The rollover share joins the quarter's separated participants to their rollovers by participant. A row-to-row join would double count a participant with two distributions."],
    ["The firm total is zero by definition", "Net Inter-Channel Transfers at Dimension Type Total is zero. A dashboard that filters to the total and shows nothing is right, not broken."],
  ];
  rules.forEach((r, i) => {
    const y = TOP + 0.4 + i * 1.22;
    rrect(s, rx, y, rw, 1.1, C.background2);
    text(s, r[0], { x: rx + 0.15, y: y + 0.08, w: rw - 0.3, h: 0.3, fontSize: 10.5, bold: true, color: C.text2 });
    text(s, r[1], { x: rx + 0.15, y: y + 0.38, w: rw - 0.3, h: 0.7, fontSize: 8.5, color: C.text1 });
  });
}
{
  const s = content("Step 5. The answer: on the dashboard, in the worklist, in the file", "4 One question, end to end",
    "Now the head of distribution opens the dashboard, or asks an AI assistant in plain English. Either way the question resolves to the same named metrics with a filter on the quarter. The figures are illustrative.\n\n" +
    "Four thousand one hundred and twenty participants separated. One point four six billion dollars of their balances were paid out as rollovers, and six hundred and ten million of that landed in our direct business: a direct business rollover share of forty-two percent. Beside it sits the certified figure: five hundred and ninety-eight million of net inter-channel transfers from the workplace channel into the direct channels, three hundred and eighty of it into advice. The twelve million residual is timing and indirect rollovers in transit, and the model publishes it as its own measure rather than hiding it. One thousand nine hundred and forty rollover recommendations were presented; thirty-seven are missing at least one PTE 2020-02 element, a gap rate of one point nine percent. The Okafor rollover is in the six hundred and ten million, in the five hundred and ninety-eight, in the advised three hundred and eighty, and its file is complete.\n\n" +
    "Three things make the number usable. It shows its dates: assets as of the last locked month-end, the evidence flag as of last night's run. Anyone can click from the metric to the product, to the definition, to the owner. And the same thirty-seven appear, that morning, in each advisor's worklist and in the supervisor's queue, so the gap is being closed by the people who can close it, not read about in a report.\n\n" +
    "That is the three uses on one screen: the analytical answer, the workflow action and the evidence file, from the same products.");
  rail(s, 5);
  const x0 = LM + 2.85, w0 = CW - 2.85;
  rrect(s, x0, TOP, w0, 2.3, C.text2);
  text(s, "ROLLOVERS INTO ADVICE, Q2 2026  (illustrative)", { x: x0 + 0.25, y: TOP + 0.15, w: 6, h: 0.3, fontSize: 10, bold: true, color: C.accent4 });
  text(s, "Assets as of 30 Jun 2026 (locked)  |  Evidence flag as of last night's run", { x: x0 + 5.0, y: TOP + 0.15, w: w0 - 5.25, h: 0.3, fontSize: 9, color: C.background2, align: "right" });
  const kp = [["4,120", "participants separated", "Separations, by plan (SM-26)"], ["$610m", "rolled into the direct business", "42% of $1.46bn paid out: Direct Business Rollover Share"], ["$598m", "certified workplace-to-direct transfers", "Net Inter-Channel Transfers (SM-20); $380m into the advice channel"], ["1,940", "rollover recommendations", "presented in the quarter (SM-22)"], ["37", "without PTE 2020-02 documentation", "PTE Documentation Gap Rate 1.9%"]];
  kp.forEach((k, i) => {
    const x = x0 + 0.25 + i * (w0 - 0.5) / 5, w = (w0 - 0.5) / 5 - 0.1;
    text(s, k[0], { x, y: TOP + 0.5, w, h: 0.7, fontSize: 26, bold: true, color: i === 4 ? C.accent4 : C.background1 });
    text(s, k[1], { x, y: TOP + 1.2, w, h: 0.5, fontSize: 10, bold: true, color: C.background1 });
    text(s, k[2], { x, y: TOP + 1.6, w, h: 0.6, fontSize: 9, color: C.background2 });
  });
  const uses = [
    ["Analytical", "Dashboard or AI assistant", "\"What share of this quarter\'s separated participants rolled into us, and how many rollover files are incomplete?\" resolves to SM-26 Direct Business Rollover Share and SM-22 Rollovers Without PTE 2020-02 Documentation, both traced to their products and owners in two clicks.", C.accent4],
    ["Workflow", "Advisor worklist and supervisor queue", "The same 37 land that morning in each advisor of record's CRM worklist (DP-340) with the missing document named, and in the principal review queue (DP-398). Cleared items drop out the next day.", C.accent5],
    ["Evidence", "The Okafor file", "DP-335 shows the recommendation, the analysis, the three options compared, the fiduciary status basis, the three PTE 2020-02 delivery dates and the impartial conduct attestation. The annual retrospective review reads the same rows.", C.accent1],
  ];
  uses.forEach((u, i) => {
    const x = x0 + i * (w0 / 3 + 0.03), w = w0 / 3 - 0.08, y = TOP + 2.5;
    rrect(s, x, y, w, 2.75, C.background2);
    rect(s, x, y, w, 0.45, u[3]);
    text(s, u[0] + "   |   " + u[1], { x: x + 0.15, y, w: w - 0.3, h: 0.45, fontSize: 10.5, bold: true, color: C.background1, valign: "middle" });
    text(s, u[2], { x: x + 0.15, y: y + 0.55, w: w - 0.3, h: 2.15, fontSize: 9.5, color: C.text1 });
  });
}
{
  const s = content("Closing the loop: an unanswerable question becomes a gap", "4 One question, end to end",
    "The natural next question is: which campaign or nudge prompted Dana's hand-off into advice, so we can spend more on what works? The honest answer is: approximately, not exactly. The flow product attributes the funding flow to a campaign under the campaign-window rule, and the advice model matches a marketing lead to the engagement by party within ninety days. The exact link is missing twice over, and the model says so in both places. Advice & Planning lists the lead-to-engagement link among the questions it cannot answer, because 04 Lead Conversion has no reference to an advice engagement. And the engagement event, the click or the nudge, cannot be joined to its campaign or tracking code at all: that is a registered gap in the marketing domain, GAP-04-001, high priority, owned by the head of marketing operations, with the six products it affects listed.\n\n" +
    "That is the last thing the taxonomy does. When a question cannot be answered, the reason shows up as a named change to a named domain, rather than as a workaround inside one team's report. Your marketing team does not build a side table; the owning domain adds the reference, the products read it, and every consumer inherits it.\n\n" +
    "The table is the summary of the whole journey. Keep it; it is the one-page version of this talk.");
  rrect(s, LM, TOP, 5.3, 2.4, C.background2);
  text(s, "The next question", { x: LM + 0.2, y: TOP + 0.15, w: 4.9, h: 0.3, fontSize: 11, bold: true, color: C.accent4 });
  text(s, "\"Which campaign or nudge prompted the rollover?\"", { x: LM + 0.2, y: TOP + 0.5, w: 4.9, h: 0.6, fontSize: 14, bold: true, color: C.text2 });
  text(s, "Approximately, not exactly. The funding flow is attributed to a campaign under the campaign-window rule; the marketing lead is matched to the advice engagement by party within 90 days. The exact link is missing twice, and the model says so: Advice & Planning lists lead-to-engagement among the questions it cannot answer, and the click-to-campaign join is registered gap GAP-04-001 (04, high, Head of Marketing Operations, six products affected). No side table: the owning domain adds the reference once.", { x: LM + 0.2, y: TOP + 1.15, w: 4.9, h: 1.2, fontSize: 10, color: C.text1 });
  rrect(s, LM, TOP + 2.55, 5.3, 2.7, C.text2);
  text(s, "What the taxonomy did, end to end", { x: LM + 0.2, y: TOP + 2.7, w: 4.9, h: 0.3, fontSize: 11, bold: true, color: C.accent4 });
  const did = ["Gave the four ideas in the question one definition and one owner each", "Made the rollover treatment a rule in one certified product, inherited everywhere", "Let the evidence file, the capture rate and the household view be built without any of them redefining a term", "Published the metrics once, with the filters and the access rule", "Turned the unanswerable question into a named change to a named domain"];
  s.addText(did.map((t, k) => ({ text: t, options: { bullet: { indent: 10 }, breakLine: k < did.length - 1, paraSpaceAfter: 4 } })), { x: LM + 0.2, y: TOP + 3.05, w: 4.9, h: 2.1, fontSize: 10, color: C.background1, valign: "top", margin: 0, isTextBox: true, objectName: "did" });
  const rows = [
    ["Layer", "In our example", "What the taxonomy does there"],
    ["Source systems", "Recordkeeper, CRM, planning tool, account master, clearing and billing, surveillance", "Mapping target: one meaning per field, one master per concept, source IDs kept"],
    ["Foundational products", "DP-240 household, DP-094 participant, DP-430 hand-off, DP-303 advice record, DP-093 IRA, DP-300 holdings, DP-006 flow, DP-008 certified transfer", "Bill of materials: exact attributes used, validated at build; the rollover treatment decided once"],
    ["Consumer products", "DP-335 evidence, DP-467 capture, DP-320 Household 360, DP-340 worklist, DP-398 review queue, DP-336 review cadence", "Safe joins across domains; assemble, never redefine"],
    ["Semantic model", "SM-26 rollover share, SM-22 rollovers without PTE documentation, SM-20 certified transfers and advised assets", "Glossary: one name, one definition, traced to its source; grain and access rules"],
    ["Uses", "Dashboard or AI answer; advisor and supervisor worklists; the examiner's file", "Trust and traceability; unanswerable questions become registered gaps"],
  ];
  table(s, rows, LM + 5.5, TOP, CW - 5.5, [1.55, 3.0, 2.08], { fontSize: 9 });
}

// ============================================================================================================ 5. CLOSE
pres.addSection({ title: "5 What this means for you" });
{
  const s = content("Applying the reference model: the levers are deliberate", "5 What this means for you",
    "Everything you have seen is a reference model for a hypothetical firm. Applying it means tailoring, and the levers are deliberate, so that a change is a named edit to a register rather than a rebuild.\n\n" +
    "Business lines: a line you do not run removes the products and inputs that serve only it. Operating model: an outsourced function keeps its products as oversight data received from the provider, and each affected specification already says how its grain changes. Certified numbers: if you define Client Assets, Advised Assets or personal return differently, the change is made in the owning product, never in a consumer. Systems of record: the Phase D mapping decides which inputs exist and at what grain. Areas and functions: where the lines sit between client service, workplace and advice is a presentation choice. The register: products are dropped, merged or added by decision, and the baseline check reports every difference.\n\n" +
    "The rule that holds through every lever is the one I opened with. A product assembles what the domains master and never remasters it, and a certified number is defined in one product only.");
  const lev = [
    ["Business lines", "A line you do not run removes the products and inputs that serve only it: trust, intermediary, workplace, digital advice.", "Capability map lines; the product register"],
    ["Operating model", "An outsourced function (clearing, recordkeeping, transfer agency, advice delivery) keeps its products as oversight data from the provider; each spec states how its grain changes.", "The operating-model note in each spec"],
    ["Certified numbers", "Define Client Assets, Advised Assets, Net New Assets or Personal Rate of Return your way, in the owning product, once. Never in a consumer.", "DP-008, DP-241, DP-145, DP-012"],
    ["Systems of record", "Phase D source mapping decides which inputs exist and at what grain; a product whose master system does not exist becomes a gap or is dropped.", "Phase D workshops; the gap register"],
    ["Areas and functions", "Where client service ends and advice begins; whether trust is kept; which functions are outsourced.", "Areas, functions, optional domains"],
    ["The register", "Drop a product by removing its row and spec; merge by moving measures into the survivor; add by registering before the spec; every change traces to a decision.", "Product register, decision log, baseline check"],
  ];
  lev.forEach((l, i) => {
    const col = i % 3, row = Math.floor(i / 3);
    const x = LM + col * 4.1, y = TOP + row * 2.1, w = 3.9;
    rrect(s, x, y, w, 1.95, C.background2);
    chip(s, x + 0.18, y + 0.18, i + 1, l[0], [C.accent1, C.accent2, C.accent3, C.accent4, C.accent5, C.accent6][i], { labelW: 3.0, fontSize: 13 });
    text(s, l[1], { x: x + 0.18, y: y + 0.72, w: w - 0.36, h: 0.85, fontSize: 10, color: C.text1 });
    text(s, l[2], { x: x + 0.18, y: y + 1.58, w: w - 0.36, h: 0.3, fontSize: 8.5, italic: true, color: C.accent6 });
  });
  rrect(s, LM, TOP + 4.3, CW, 0.9, C.text2);
  text(s, "The rule that holds through every lever: a product assembles what the Data Domains master and never remasters it, and a certified number is defined in one product only.", { x: LM + 0.3, y: TOP + 4.3, w: CW - 0.6, h: 0.9, fontSize: 13, bold: true, color: C.background1, valign: "middle" });
}
{
  const s = content("What we need from this room, and what happens next", "5 What this means for you",
    "Four decisions sit with the head of distribution, and three pieces of work sit with the data team.\n\n" +
    "Decisions. Confirm that Client Assets is the headline number and Firm AUM the manufacturing number, reconciled and never summed. Rule on the rollover treatment: a firm-plan to firm-IRA rollover as an inter-channel transfer is the reference default, and it changes your net new assets story, so it should be a conscious choice. Name the product owners for the products your function consumes first: the executive scorecard, net new assets by channel and advisor, rollover capture, Household 360. And confirm the business lines and which functions are outsourced, because they decide which products exist.\n\n" +
    "Work. Validate the foundational products first, with their certified-number owners; the review pack is the agenda. Run the Phase D source-mapping workshops, one per domain, using each product's lineage as the list of attributes to map. And triage the gap register, high items first, through the owning domains.\n\n" +
    "Then we come back with the same twelve questions answered from your systems rather than from the reference model.");
  rrect(s, LM, TOP, 6.0, 5.25, C.text2);
  text(s, "DECISIONS FOR THE HEAD OF DISTRIBUTION", { x: LM + 0.25, y: TOP + 0.2, w: 5.5, h: 0.3, fontSize: 10, bold: true, color: C.accent4 });
  const dec = [["Confirm the headline number", "Client Assets as the headline; Firm AUM as the manufacturing number; reconciled in one product, never summed."], ["Rule on the rollover treatment", "A firm-plan to firm-IRA rollover is an inter-channel transfer, not Net New Assets, by default. It changes the NNA story, so choose it consciously."], ["Name product owners", "For the products your function consumes first: executive scorecard, NNA by channel and advisor, rollover capture, Household 360, advice funnel."], ["Confirm lines and operating model", "Which business lines you run and which functions are outsourced decide which products exist and in what form."]];
  dec.forEach((d, i) => {
    const y = TOP + 0.6 + i * 1.15;
    chip(s, LM + 0.25, y + 0.02, i + 1, d[0], C.accent4, { labelW: 4.9, fontSize: 13, labelColor: C.background1 });
    text(s, d[1], { x: LM + 0.8, y: y + 0.47, w: 5.0, h: 0.65, fontSize: 10, color: C.background2 });
  });
  const rx = LM + 6.2, rw = CW - 6.2;
  rrect(s, rx, TOP, rw, 3.5, C.background2);
  text(s, "WORK FOR THE DATA MANAGEMENT TEAM", { x: rx + 0.25, y: TOP + 0.2, w: rw - 0.5, h: 0.3, fontSize: 10, bold: true, color: C.accent2 });
  const work = [["Validate the foundational products first", "With their certified-number owners; the foundational review pack is the agenda for keep, re-scope, merge or drop."], ["Map lineage to source systems (Phase D)", "One workshop per domain; each product's lineage is the list of attributes to map; unmapped inputs become gaps."], ["Triage the gap register", "High items first, through the owning domain; scores and forecasts stay product-owned and registered in the model inventory."]];
  work.forEach((w, i) => {
    const y = TOP + 0.6 + i * 0.95;
    chip(s, rx + 0.25, y + 0.02, i + 1, w[0], C.accent2, { labelW: 5.5, fontSize: 12.5 });
    text(s, w[1], { x: rx + 0.8, y: y + 0.45, w: rw - 1.05, h: 0.5, fontSize: 9.5, color: C.text1 });
  });
  rrect(s, rx, TOP + 3.65, rw, 1.6, C.background2);
  text(s, "Then", { x: rx + 0.25, y: TOP + 3.78, w: 2, h: 0.3, fontSize: 11, bold: true, color: C.accent1 });
  text(s, "We come back with the same twelve acceptance questions answered from your systems rather than from the reference model, and with the first certified products signed off by their owners.", { x: rx + 0.25, y: TOP + 4.1, w: rw - 0.5, h: 1.1, fontSize: 11, color: C.text1 });
}
{
  const s = content("Questions you are likely to be asked", "5 What this means for you",
    "A short list of the questions this talk tends to draw, with the honest answers. Keep this slide in reserve rather than presenting it.");
  const qa = [
    ["\"Are these our real systems?\"", "No. Sources are named by type until the Phase D mapping is done. Each product's lineage is the list of attributes to map, so the mapping is a finite, listed job."],
    ["\"Why does a rollover from our own plan not count as net new assets?\"", "Because the firm's total assets did not change; money moved between channels. The channel view shows the move, Advised Assets shows the growth, and the firm total is honest. If you want it counted as new money, that is a change to the flow treatment rule in one product, with a decision."],
    ["\"Why are there two dates on the number?\"", "Assets are certified monthly and locked; the evidence flag runs nightly. Showing both is more honest than pretending they match."],
    ["\"Is this a dashboard project?\"", "Dashboards are one of three uses, and the smallest. Most of the value is in the operational products that drive worklists and billing, and the control products that hold the evidence."],
    ["\"What does the data team actually maintain?\"", "Content modules and specifications, under validation and a baseline check. Not the workbooks, not the explorer, not the catalog: those are generated."],
    ["\"How is this different from our data dictionary?\"", "Ownership flags on every attribute, products that are validated against it at build, and certified numbers with one owner each. A dictionary describes; this one is enforced."],
  ];
  qa.forEach((q, i) => {
    const col = i % 2, row = Math.floor(i / 2);
    const x = LM + col * 6.2, y = TOP + row * 1.75, w = 5.95;
    rrect(s, x, y, w, 1.6, C.background2);
    text(s, q[0], { x: x + 0.2, y: y + 0.12, w: w - 0.4, h: 0.4, fontSize: 12, bold: true, color: C.text2 });
    text(s, q[1], { x: x + 0.2, y: y + 0.55, w: w - 0.4, h: 1.0, fontSize: 10, color: C.text1 });
  });
}
{
  const s = pres.addSlide({ masterName: "DARK", sectionTitle: "5 What this means for you" });
  s.addText("One definition. One owner. Every layer.", { placeholder: "title" });
  s.addText("The taxonomy says what things mean. The products carry it through. The number on the dashboard, in the worklist and in the examiner's file is the same number, because nobody downstream owns it.", { placeholder: "body" });
  LAYERS.forEach((l, i) => chip(s, LM + i * 2.45, 5.75, i + 1, l[0], l[1], { labelW: 2.2, fontSize: 12, labelColor: C.background1 }));
  s.addNotes("Close on the sentence. One definition, one owner, every layer. Thank you; questions.");
}

(async () => {
  const out = path.join(process.env.OUT_DIR, "Wealth_Manager_Foundational_Talktrack.pptx");
  await pres.writeFile({ fileName: out });
  await applyTheme(out, THEME);
  console.log("wrote", out, "slides", slideNo);
})();
