"""Shared builder for the CG reference data taxonomy workbooks.

Each business domain has a content module in _tools/content/ that defines:

  META = {
    "title":     workbook title,
    "subtitle":  one-line scope / version line,
    "output":    path relative to the CG Taxonomy root, e.g. "03_Sales/Sales_Data_Taxonomy.xlsx",
    "overview":  [(heading, text), ...]   rows for the Overview tab,
  }
  T   = [(domain_name, domain_code, domain_definition,
          [(subdomain_name, subdomain_definition,
            [(concept_name, [attribute_tuple, ...]), ...]), ...]), ...]
        attribute_tuple = (name, definition, applies_to, data_type, code_list, example,
                           primary_ref, secondary_ref, cde[, notes])
  CL  = {code_list_name: (source_alignment, [(value, description), ...])}
  REL = [(from_concept, relationship, to_concept, cardinality, notes), ...]
  SRC = [(source, owner, url, license, coverage, used_in, [primary_ref_labels_to_count]), ...]
        labels may end in * as a COUNTIF wildcard.

Usage:  python taxonomy_builder.py content_sales          (one module)
        python taxonomy_builder.py --all                  (every content_*.py)
        --raw            build the authored v0.1 content without the consolidation layer
        --strict-shared  shared-list warnings (validate_shared) fail the run; errors always do
"""
import importlib, os, re, sys
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONTENT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "content")
sys.path.insert(0, CONTENT)

# Code List / Format values that are formats or externally maintained lists, not entries in CL
EXTERNAL_FORMATS = {"Firm-defined", "MM-DD", "HH:MM", "HH:MM + time zone", "T+n", "Days", "Months", "Years",
                    "1-7", "URI", "IANA Time Zone", "ISO 8601", "Email", "E.164", "Free text", "Basis points"}

def is_external(code_list):
    c = code_list.strip()
    return (not c or c in EXTERNAL_FORMATS or c.startswith("ISO") or c.startswith("External")
            or "firm-defined" in c.lower())

NAVY = "1F3864"; MID = "D9E2F3"; LIGHT = "F2F2F2"; WHITE = "FFFFFF"
FONT = "Arial"
HDR_FONT = Font(name=FONT, bold=True, color=WHITE, size=10)
HDR_FILL = PatternFill("solid", fgColor=NAVY)
BODY = Font(name=FONT, size=10)
BOLD = Font(name=FONT, size=10, bold=True)
THIN = Side(style="thin", color="BFBFBF")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
WRAP = Alignment(wrap_text=True, vertical="top")
CENTER = Alignment(horizontal="center", vertical="top")


CONSOLIDATION = os.path.join(os.path.dirname(os.path.abspath(__file__)), "consolidation")


from domains import DD_NAMES, L1_CODE  # noqa: E402  (one register of Data Domains 01-44)
dd_label = lambda n: f"{n} {DD_NAMES.get(n, '')}".strip()
LEVELS = ("L1 Data Domain", "L2 Data Family", "L3 Data Business Object", "L4 Data Business Attribute")
STRUCTURE_TEXT = ("Four levels: L1 Data Domain (this workbook) > L2 Data Family > L3 Data Business Object > L4 Data Business "
                  "Attribute. 'Object Group' is a label that groups closely related objects within a family; it is not a level. "
                  "Each object states its grain (what one row represents) and whether it is a Business Object or an Attribute "
                  "Group describing a parent object.")
OWNERSHIP_TEXT = ("Every attribute is flagged 'Mastered here' (this Data Domain produces and maintains it), 'Reference' (it holds "
                  "the enterprise ID of a concept mastered in the named Data Domain) or 'Derived copy' (it holds a copied value "
                  "mastered elsewhere). Consumption never remasters ownership.")
TABS_TEXT = ("Hierarchy: Data Families and Data Business Objects with definitions, grain and live counts | Taxonomy: every Data "
             "Business Attribute with ownership (filterable) and, where rows are mastered in different Data Domains, the Row Ownership Rule | Code Lists: controlled vocabularies | Relationships: object-level "
             "cardinalities for the logical model | Sources: standards used, owners, licenses and links.")


def model(m):
    """Data Family > Data Business Object > Data Business Attribute view of a (Consolidated) module, with grain and ownership."""
    import ownership as ow
    n = m.__name__.split("_")[1]
    enr = getattr(m, "enr", None)
    grain = getattr(enr, "GRAIN", {}) if enr else {}
    row_rules = getattr(enr, "ROW_OWNERSHIP", {}) if enr else {}   # optional (CD-289): which rows are mastered where
    fams = []
    for dn, dc, dd, subs in m.T:
        objs, i, k = [], 0, 0
        for sn, sd, concepts in subs:
            for cn, attrs in concepts:
                k += 1
                g = grain.get((dn, cn), ("", "", ""))
                rows = []
                for a in attrs:
                    i += 1
                    flag, owner = ow.resolve(n, dn, cn, a, enr)
                    rows.append({"id": f"{dc}-{i:03d}", "a": a, "flag": flag, "owner": owner,
                                 "row_rule": row_rules.get((dn, cn, a[0]), "")})
                objs.append({"code": f"{dc}.{k:02d}", "name": cn, "group": sn, "group_def": sd,
                             "group_size": len(concepts), "grain": g[0], "kind": g[1], "parent": g[2], "attrs": rows})
        fams.append({"code": dc, "name": dn, "def": dd, "objects": objs})
    return fams


def shared_entry(s):
    """Code List tab entry of an enterprise shared list, as every workbook shows it ("Shared: <name>")."""
    return (f"Enterprise shared list - steward {s['steward']} - {s['source']}",
            [(label, f"[{code}] {desc}".strip()) for code, label, desc in s["values"]])


def _direct_shared(c, bd, scl, registered_only=True):
    """Add the shared lists that attributes cite directly as 'Shared: <name>' (no local member list). Domains drafted after
    the harmonization pass (17+) do this; shared_code_lists.py registers them in each list's 'direct_users'. A domain that
    cites a shared list it is not registered for gets no entry, so validate() reports the list as undefined."""
    if scl is None:
        return
    used = {a[4] for d in c.T for s in d[3] for cc in s[2] for a in cc[1] if a[4].startswith("Shared: ")}
    for s in scl.SHARED:
        key = "Shared: " + s["name"]
        if key in used and key not in c.CL and (not registered_only or bd in s.get("direct_users", [])):
            c.CL[key] = shared_entry(s)


class Consolidated:
    """A content module with the consolidation layer (shared code lists, list renames) and enrichment (grain, ownership) applied."""

    def __init__(self, mod, scl):
        bd = mod.__name__.split("_")[1]
        self.__name__, self.REL, self.SRC = mod.__name__, mod.REL, mod.SRC
        import ownership as ow
        self.enr = ow.load_enrichment(bd)
        if scl is None:
            self.T, self.CL, self.replaced, self.META = mod.T, dict(mod.CL), [], dict(mod.META)
            _direct_shared(self, bd, load_consolidation(), registered_only=False)
            self._meta(bd)
            return
        shared = {(d, l): s for s in scl.SHARED for d, l in s["members"]}
        renames = {old: new for d, old, new, _ in scl.LOCAL_RENAMES if d == bd}
        lmap = {l: "Shared: " + s["name"] for (d, l), s in shared.items() if d == bd and l in mod.CL}
        lmap.update({o: n for o, n in renames.items() if o in mod.CL})
        self.replaced = sorted(l for l in lmap if l not in renames)
        self.T = [(dn, dc, dd, [(sn, sd, [(cn, [a[:4] + (lmap.get(a[4], a[4]),) + a[5:] for a in attrs])
                                            for cn, attrs in concepts]) for sn, sd, concepts in subs])
                  for dn, dc, dd, subs in mod.T]
        self.CL = {renames.get(k, k): v for k, v in mod.CL.items() if k not in lmap or k in renames}
        for s in scl.SHARED:
            if any(d == bd and l in mod.CL for d, l in s["members"]):
                self.CL["Shared: " + s["name"]] = shared_entry(s)
        _direct_shared(self, bd, scl)
        m = dict(mod.META)
        m["subtitle"] = m["subtitle"].replace("Draft v0.1", "Draft v0.2 (consolidated)")
        m["overview"] = list(m["overview"]) + [(
            "Consolidation (v0.2)",
            f"{len(self.replaced)} local code list(s) replaced by enterprise shared lists (shown as 'Shared: <name>', stewarded "
            f"via the 09 code list registry){'; ' + str(len(renames)) + ' list(s) renamed to disambiguate' if renames else ''}. "
            "Cross-domain decisions, concept ownership and the ID prefix register are in "
            "00_Program/Enterprise_Data_Taxonomy.xlsx.")]
        self.META = m
        self._meta(bd)

    def _exclude(self):
        """Drop excluded objects (consolidation/exclusions.py), then empty object groups and families, then unused code lists."""
        try:
            sys.path.insert(0, CONSOLIDATION)
            excluded = importlib.import_module("exclusions").EXCLUDED_OBJECTS
        except ModuleNotFoundError:
            excluded = {}
        if not excluded:
            return
        T = []
        for dn, dc, dd, subs in self.T:
            subs2 = [(sn, sd, [c for c in cs if c[0] not in excluded]) for sn, sd, cs in subs]
            subs2 = [s for s in subs2 if s[2]]
            if subs2:
                T.append((dn, dc, dd, subs2))
        self.T = T
        used = {a[4] for d in T for s in d[3] for c in s[2] for a in c[1] if a[4]}
        self.CL = {k: v for k, v in self.CL.items() if k in used}

    def _meta(self, bd):
        self._exclude()
        m = self.META
        m["subtitle"] = re.sub(r"Business domain (\d\d)", r"Data Domain \1", m["subtitle"]).replace(
            "Draft v0.2 (consolidated)", "Draft v0.3").replace("Draft v0.1", "Draft v0.3")
        rows, S = [], getattr(self.enr, "SUMMARY", {}) if self.enr else {}
        for k, v in m["overview"]:
            if k == "Structure":
                v = STRUCTURE_TEXT
            elif k == "Tabs":
                v = TABS_TEXT
            rows.append((k, v))
            if k == "Scope" and S:
                rows += [("Masters", S.get("masters", "")), ("References", S.get("references", "")), ("Ownership", OWNERSHIP_TEXT)]
        m["overview"] = rows


def load_consolidation():
    path = os.path.join(CONSOLIDATION, "shared_code_lists.py")
    if not os.path.exists(path):
        return None
    sys.path.insert(0, CONSOLIDATION)
    return importlib.import_module("shared_code_lists")


def validate(mod):
    errors, codes, ids = [], set(), set()
    used = set()
    for d in mod.T:
        if len(d) != 4:
            errors.append(f"Domain tuple wrong length: {d[0]}")
            continue
        dname, dcode, _, subs = d
        if dcode in codes:
            errors.append(f"Duplicate domain code {dcode}")
        codes.add(dcode)
        seen = set()
        for s in subs:
            if len(s) != 3:
                errors.append(f"Subdomain tuple wrong length in {dname}: {s[0]}")
                continue
            for c in s[2]:
                if len(c) != 2:
                    errors.append(f"Concept tuple wrong length in {dname}/{s[0]}: {c[0]}")
                    continue
                for a in c[1]:
                    if len(a) not in (9, 10):
                        errors.append(f"Attribute tuple len {len(a)} in {dname}/{s[0]}/{c[0]}: {a[0]}")
                        continue
                    key = (s[0], c[0], a[0])
                    if key in seen:
                        errors.append(f"Duplicate attribute {key}")
                    seen.add(key)
                    if a[8] not in ("Y", ""):
                        errors.append(f"CDE must be 'Y' or '': {a[0]}")
                    if a[4]:
                        used.add(a[4])
    for cl in sorted(used):
        if cl not in mod.CL and not is_external(cl):
            errors.append(f"Code list referenced but not defined: '{cl}'")
    for name, v in mod.CL.items():
        if len(v) != 2 or not v[1]:
            errors.append(f"Code list malformed or empty: {name}")
    for r in mod.REL:
        if len(r) != 5:
            errors.append(f"Relationship tuple wrong length: {r}")
    for s in mod.SRC:
        if len(s) != 7:
            errors.append(f"Source tuple wrong length: {s[0]}")
    return errors


def validate_shared(scl, mods, only=None):
    """Check shared_code_lists.py against the authored content modules (consolidation/CONTRACT.md, "Validation"). mods maps a
    Data Domain number to its raw content module; only (a set of numbers) limits the report to lists that involve those
    domains. Returns (errors, warnings). Errors: a 'Shared: <name>' citation of a list that does not exist, and a citing domain
    that is neither a member nor a registered direct user (the builder gives it no entry, so validate() would fail it as an
    undefined list). Everything else is a warning: a value_map entry that maps to a code the list does not hold, a value_map
    key that is not a registered member or not in the member's local list, a member value with no value_map entry, a member
    in a retired or missing domain or without its local list, a direct user that does not cite the list, a list below two
    values, duplicate codes or labels, a steward outside the wealth domains, and stale LOCAL_RENAMES rows."""
    import domains as dom
    retired = set(getattr(dom, "RETIRED_DOMAINS", {}))
    live = set(getattr(dom, "WEALTH_DOMAINS", dom.DD_NAMES))
    errs, warns = [], []
    concerns = lambda *ds: only is None or any(d in only for d in ds)
    cites = {}
    for d, m in mods.items():
        for dn, dc, dd, subs in m.T:
            for sn, sd, cs in subs:
                for cn, at in cs:
                    for a in at:
                        if len(a) > 4 and a[4].startswith("Shared: "):
                            cites.setdefault(a[4][8:], set()).add(d)
    byname = {}
    for x in scl.SHARED:
        n = x["name"]
        if n in byname:
            errs.append(f"duplicate shared list name '{n}'")
        byname[n] = x
        mem, du, vm = x["members"], x.get("direct_users", []), x.get("value_map", {})
        if not concerns(x["steward"], *[d for d, _ in mem], *du):
            continue
        codes = [v[0] for v in x["values"]]
        for label, vals in (("code", codes), ("label", [v[1] for v in x["values"]])):
            dupl = sorted({v for v in vals if vals.count(v) > 1})
            if dupl:
                warns.append(f"{n}: duplicate {label}(s) {dupl}")
        if len(codes) < 2:
            warns.append(f"{n}: {len(codes)} value(s), below the two-value floor")
        if x["steward"] not in live:
            warns.append(f"{n}: steward {x['steward']} is not a live Data Domain")
        for (d, l, v), code in vm.items():
            if not concerns(d):
                continue
            if code is not None and code not in codes:
                warns.append(f"{n}: value_map ({d}, {l}, {v!r}) -> {code}, not a code of the list")
            if (d, l) not in mem:
                warns.append(f"{n}: value_map key ({d}, {l}, {v!r}) is not a registered member")
        for d, l in mem:
            if not concerns(d):
                continue
            if d in retired or d not in mods:
                warns.append(f"{n}: member ({d}, {l}) is in a retired or missing Data Domain"); continue
            if l not in mods[d].CL:
                warns.append(f"{n}: member ({d}, {l}) has no local list in content_{d}"); continue
            local = [v[0] for v in mods[d].CL[l][1]]
            missing = [v for v in local if (d, l, v) not in vm]
            if missing:
                warns.append(f"{n}: member ({d}, {l}) values without a value_map entry: {missing}")
            stale = [v for (dd, ll, v) in vm if (dd, ll) == (d, l) and v not in local]
            if stale:
                warns.append(f"{n}: member ({d}, {l}) value_map keys not in the local list: {stale}")
        for d in du:
            if concerns(d) and (d in retired or d not in mods):
                warns.append(f"{n}: direct user {d} is a retired or missing Data Domain")
            elif concerns(d) and d not in cites.get(n, set()):
                warns.append(f"{n}: direct user {d} does not cite 'Shared: {n}'")
    for n, ds in sorted(cites.items()):
        for d in sorted(ds):
            if not concerns(d):
                continue
            if n not in byname:
                errs.append(f"'Shared: {n}' cited by {d}, but no shared list has that name"); continue
            x = byname[n]
            if d not in x.get("direct_users", []) and not any(dd == d and ll in mods[d].CL for dd, ll in x["members"]):
                errs.append(f"'Shared: {n}' cited by {d}, which is neither a member nor a registered direct user")
    for d, old, new, why in scl.LOCAL_RENAMES:
        if concerns(d) and (d in retired or d not in mods or old not in mods[d].CL):
            warns.append(f"LOCAL_RENAMES ({d}, {old!r} -> {new!r}): no such list in the live module")
    return errs, warns


def header(ws, row, headers, widths):
    for i, (h, w) in enumerate(zip(headers, widths), 1):
        c = ws.cell(row=row, column=i, value=h)
        c.font = HDR_FONT; c.fill = HDR_FILL; c.border = BORDER
        c.alignment = Alignment(wrap_text=True, vertical="center")
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.row_dimensions[row].height = 30


def cell(ws, r, c, v, font=BODY, fill=None, align=WRAP):
    x = ws.cell(row=r, column=c, value=v)
    x.font = font; x.alignment = align; x.border = BORDER
    if fill:
        x.fill = PatternFill("solid", fgColor=fill)
    return x


def title(ws, text, sub):
    ws["A1"] = text; ws["A1"].font = Font(name=FONT, size=14, bold=True, color=NAVY)
    ws["A2"] = sub; ws["A2"].font = Font(name=FONT, size=10, italic=True)


def build(mod):
    errs = validate(mod)
    if errs:
        raise SystemExit(f"[{mod.__name__}] validation failed:\n  " + "\n  ".join(errs))
    M = mod.META
    wb = Workbook()
    ov = wb.active; ov.title = "Overview"
    hier = wb.create_sheet("Hierarchy"); tax = wb.create_sheet("Taxonomy")
    cls = wb.create_sheet("Code Lists"); rel = wb.create_sheet("Relationships"); src = wb.create_sheet("Sources")

    fams = model(mod)
    n_dd = mod.__name__.split("_")[1]
    # Taxonomy (L4 Data Business Attributes)
    TH = ["Attribute ID", "Data Family (L2)", "Data Business Object (L3)", "Data Business Attribute (L4)", "Definition",
          "Ownership", "Mastered In", "Applies To", "Data Type", "Code List / Format", "Example", "Primary Reference",
          "Secondary Reference", "CDE", "Object Group", "Notes", "Row Ownership Rule"]
    header(tax, 1, TH, [13, 24, 26, 30, 55, 14, 26, 18, 18, 24, 30, 24, 22, 6, 24, 30, 40])
    r = 2
    for fi, f in enumerate(fams):
        fill = WHITE if fi % 2 == 0 else LIGHT
        for o in f["objects"]:
            for x in o["attrs"]:
                a = x["a"]
                vals = [x["id"], f["name"], o["name"], a[0], a[1], x["flag"], dd_label(x["owner"] or n_dd), a[2], a[3], a[4],
                        a[5], a[6], a[7], a[8], o["group"], a[9] if len(a) > 9 else "", x["row_rule"]]
                for ci, v in enumerate(vals, 1):
                    cell(tax, r, ci, v, BOLD if ci == 4 else BODY, fill)
                r += 1
    last = r - 1
    tax.freeze_panes = "E2"
    tax.auto_filter.ref = f"A1:Q{last}"
    rng = lambda col: f"Taxonomy!${col}$2:${col}${last}"

    # Hierarchy (L2 Data Families and L3 Data Business Objects)
    title(hier, f"{M['title']} - Hierarchy",
          "L2 Data Family > L3 Data Business Object, with grain and kind. Attribute, CDE and reference counts are live formulas "
          "over the Taxonomy tab.")
    header(hier, 4, ["Level", "Code", "Data Family", "Data Business Object", "Object Group", "Definition",
                     "Grain (one row =)", "Kind", "Parent Object", "# Attributes", "# CDEs", "# References Out"],
           [12, 14, 28, 30, 26, 60, 34, 16, 24, 11, 9, 11])
    r = 5
    for f in fams:
        cnt = lambda extra="": f'=COUNTIFS({rng("B")},C{r}{extra})'
        for ci, v in enumerate(["L2 Family", f["code"], f["name"], "", "", f["def"], "", "", "",
                                cnt(), cnt(f',{rng("N")},"Y"'), cnt(f',{rng("F")},"<>Mastered here"')], 1):
            cell(hier, r, ci, v, BOLD, MID, CENTER if ci > 9 else WRAP)
        r += 1
        for o in f["objects"]:
            cnt = lambda extra="": f'=COUNTIFS({rng("B")},C{r},{rng("C")},D{r}{extra})'
            grp = o["group"] if (o["group_size"] > 1 or o["group"] != o["name"]) else ""
            for ci, v in enumerate(["L3 Object", o["code"], f["name"], o["name"], grp, o["group_def"], o["grain"], o["kind"],
                                    o["parent"], cnt(), cnt(f',{rng("N")},"Y"'), cnt(f',{rng("F")},"<>Mastered here"')], 1):
                cell(hier, r, ci, v, BOLD if ci == 4 else BODY, None, CENTER if ci > 9 else WRAP)
            r += 1
    hier.freeze_panes = "A5"; hier.auto_filter.ref = f"A4:L{r-1}"

    # Code Lists
    title(cls, "Code Lists (Reference Values)",
          "Starter values for the controlled vocabularies referenced in the Taxonomy tab. Extend or replace with "
          "firm-specific values; ISO and external (vendor) lists are maintained by their owners and not reproduced here.")
    header(cls, 4, ["Code List", "Value", "Description", "Source / Alignment", "Used By (# attributes)"], [32, 36, 46, 34, 14])
    r = 5
    for li, (lname, (lsrc, vals)) in enumerate(sorted(mod.CL.items())):
        fill, first = (WHITE if li % 2 == 0 else LIGHT), r
        for v, d in vals:
            cell(cls, r, 1, lname, BOLD, fill); cell(cls, r, 2, v, BODY, fill)
            cell(cls, r, 3, d, BODY, fill); cell(cls, r, 4, lsrc, BODY, fill)
            cell(cls, r, 5, f'=COUNTIF({rng("J")},A{r})' if r == first else "", BODY, fill, CENTER)
            r += 1
    cls.freeze_panes = "A5"; cls.auto_filter.ref = f"A4:E{r-1}"

    # Relationships
    title(rel, "Object Relationships", "Core relationships between Data Business Objects, including references to other Data "
          "Domains. Use these as the basis for the logical data model.")
    header(rel, 4, ["From Object", "Relationship", "To Object", "Cardinality", "Notes"], [38, 22, 44, 14, 55])
    for i, row in enumerate(mod.REL, 5):
        for ci, v in enumerate(row, 1):
            cell(rel, i, ci, v, BOLD if ci in (1, 3) else BODY)
    rel.freeze_panes = "A5"

    # Sources
    title(src, "Reference Sources", "Standards and sources stitched together in this taxonomy. Check license terms "
          "and current versions before relying on any source.")
    header(src, 4, ["Source", "Owner", "URL", "License / Access", "Coverage", "Used In This Taxonomy",
                    "# Attributes (Primary)"], [42, 26, 32, 22, 46, 46, 14])
    for i, row in enumerate(mod.SRC, 5):
        for ci, v in enumerate(row[:6], 1):
            cell(src, i, ci, v, BOLD if ci == 1 else BODY)
        keys = row[6]
        f = "=" + "+".join(f'COUNTIF({rng("L")},"{k}")' for k in keys) if keys else "n/a"
        cell(src, i, 7, f, BODY, None, CENTER)
    src.freeze_panes = "A5"

    # Overview
    ov.column_dimensions["A"].width = 30; ov.column_dimensions["B"].width = 95
    ov.column_dimensions["C"].width = 14; ov.column_dimensions["D"].width = 12
    ov["A1"] = M["title"]; ov["A1"].font = Font(name=FONT, size=16, bold=True, color=NAVY)
    ov["A2"] = M["subtitle"]; ov["A2"].font = Font(name=FONT, size=10, italic=True)
    r = 4
    for k, v in M["overview"]:
        cell(ov, r, 1, k, BOLD, MID); cell(ov, r, 2, v); r += 1
    r += 1
    ov.column_dimensions["E"].width = 12; ov.column_dimensions["F"].width = 14
    ov.cell(row=r, column=1, value="Data Family Summary").font = Font(name=FONT, size=12, bold=True, color=NAVY)
    r += 1
    for ci, h in enumerate(["Data Family (L2)", "Definition", "Objects (L3)", "Attributes (L4)", "CDEs", "References Out"], 1):
        x = ov.cell(row=r, column=ci, value=h); x.font = HDR_FONT; x.fill = HDR_FILL; x.border = BORDER
    r += 1; first = r
    for f in fams:
        cell(ov, r, 1, f"{f['name']} ({f['code']})", BOLD); cell(ov, r, 2, f["def"])
        cell(ov, r, 3, len(f["objects"]), BODY, None, CENTER)
        cell(ov, r, 4, f'=COUNTIFS({rng("B")},"{f["name"]}")', BODY, None, CENTER)
        cell(ov, r, 5, f'=COUNTIFS({rng("B")},"{f["name"]}",{rng("N")},"Y")', BODY, None, CENTER)
        cell(ov, r, 6, f'=COUNTIFS({rng("B")},"{f["name"]}",{rng("F")},"<>Mastered here")', BODY, None, CENTER)
        r += 1
    cell(ov, r, 1, "Total", BOLD, MID); cell(ov, r, 2, "", BODY, MID)
    for ci, col in ((3, "C"), (4, "D"), (5, "E"), (6, "F")):
        cell(ov, r, ci, f"=SUM({col}{first}:{col}{r-1})", BOLD, MID, CENTER)
    r += 2
    ov.cell(row=r, column=1, value="References to Other Data Domains").font = Font(name=FONT, size=12, bold=True, color=NAVY)
    r += 1
    for ci, h in enumerate(["Mastered In", "What this domain uses from it", "References", "Derived Copies"], 1):
        x = ov.cell(row=r, column=ci, value=h); x.font = HDR_FONT; x.fill = HDR_FILL; x.border = BORDER
    r += 1
    used = {}
    for f in fams:
        for o in f["objects"]:
            for x in o["attrs"]:
                if x["flag"] in ("Reference", "Derived copy"):
                    used.setdefault(x["owner"], set()).add(re.sub(r"^Reference \(?|\)?( \(multi\))?$", "", x["a"][3]) if x["flag"] == "Reference" else x["a"][0])
    for o in sorted(used):
        cell(ov, r, 1, dd_label(o), BOLD); cell(ov, r, 2, ", ".join(sorted(used[o]))[:900])
        cell(ov, r, 3, f'=COUNTIFS({rng("G")},A{r},{rng("F")},"Reference")', BODY, None, CENTER)
        cell(ov, r, 4, f'=COUNTIFS({rng("G")},A{r},{rng("F")},"Derived copy")', BODY, None, CENTER)
        r += 1

    for ws in wb.worksheets:
        ws.sheet_view.showGridLines = False
    wb.calculation.fullCalcOnLoad = True
    out = os.path.join(ROOT, M["output"])
    os.makedirs(os.path.dirname(out), exist_ok=True)
    wb.save(out)
    objs = [o for f in fams for o in f["objects"]]
    xs = [x for o in objs for x in o["attrs"]]
    print(f"[{mod.__name__}] OK -> {M['output']}: {len(fams)} families, {len(objs)} objects "
          f"({sum(o['kind'] == 'Attribute Group' for o in objs)} attribute groups, {sum(not o['grain'] for o in objs)} without grain), "
          f"{len(xs)} attributes, {sum(x['a'][8] == 'Y' for x in xs)} CDEs, {sum(x['flag'] == 'Reference' for x in xs)} references, "
          f"{sum(x['flag'] == 'Derived copy' for x in xs)} derived, {sum(x['flag'].startswith('Unres') for x in xs)} unresolved, "
          f"{len(mod.CL)} code lists")
    return out


if __name__ == "__main__":
    sys.dont_write_bytecode = True
    args = sys.argv[1:]
    raw = "--raw" in args          # --raw: build the authored v0.1 content without the consolidation layer
    args = [a for a in args if a != "--raw"]
    strict = "--strict-shared" in args   # --strict-shared: shared-list warnings fail the run (consolidation/CONTRACT.md)
    args = [a for a in args if a != "--strict-shared"]
    if args == ["--all"]:
        args = sorted(f[:-3] for f in os.listdir(CONTENT) if f.startswith("content_") and f.endswith(".py"))
    scl = None if raw else load_consolidation()
    mods = {n.split("_")[1]: importlib.import_module(n.replace(".py", "")) for n in args}
    if scl is not None:
        allm = {f.split("_")[1]: importlib.import_module(f[:-3]) for f in sorted(os.listdir(CONTENT))
                if f.startswith("content_") and f.endswith(".py")}
        errs, warns = validate_shared(scl, allm, None if len(mods) == len(allm) else set(mods))
        for w in warns: print("WARN  shared list:", w)
        for e in errs: print("ERROR shared list:", e)
        print(f"shared lists: {len(scl.SHARED)} checked; {len(errs)} error(s), {len(warns)} warning(s)")
        if errs or (strict and warns):
            raise SystemExit("shared-list validation failed")
    for name in args:
        build(Consolidated(mods[name.split("_")[1]], scl))
